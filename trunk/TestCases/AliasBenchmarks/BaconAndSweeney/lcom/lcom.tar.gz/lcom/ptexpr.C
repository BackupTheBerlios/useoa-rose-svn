
// FILE: PTEXPR.C - PARSE TREE EXPRESSION NODES

#include <stdio.h>
#include "ptexpr.h"
#include "build.h"
#include "globals.h"
#include "subexpr.h"

class DF_Entry;

extern DataFlowGraph *CurrentDFG;

// CLASS PTBinOptr
// CLASS PTUnaryOptr
// CLASS PTIdent
// CLASS PT_Lvalue
// CLASS PT_Rvalue
// CLASS PTDataStor
// CLASS PTConst
// CLASS PT_Cond

#ifndef lint
static char *sccsid = "@(#)ptexpr.C	1.16 (University of Guelph, VLSI Dept.) 93/06/09";
#endif /* lint */

//------------ function prototypes -------------------------
OpndEntry *storeOptrInTempOpnd(OptrEntry *optr, int stepnum, char *prefix);

//------------------------------------------------------------------------
// CLASS PTBinOptr()
//------------------------------------------------------------------------

PTBinOptr::PTBinOptr(int optrToken, int start_lineno) 
          : PTNode(ptreeBinOptr, start_lineno)
{
   operationToken = optrToken;
	operationStr = getTokenStr(operationToken);
//   leftChild = (PTNode *)0;
//   rightChild = (PTNode *)0;	

	argmax = 4;
	argcount = 0;
	args = new PTNodePtr[argmax];
   
};

PTBinOptr::~PTBinOptr(void)
{ 
	if(args)
		delete args;

};


void 
PTBinOptr::printMe(void)
{
   char *str = operationStr;
   dumpLine("%s\n",str);
};
void 
PTBinOptr::dumpTree(void)
{
   incDumpIndent();
   leftChild->dumpTree();
   decDumpIndent();
   printMe();
   incDumpIndent();
   rightChild->dumpTree();
   decDumpIndent();
   if(nextStmt) nextStmt->dumpTree();// should never happen ?
   
};

void
PTBinOptr::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();

//	if(isCommutativeOptr(operationToken) && 
//		(leftChild->isConstant() ==  False) && (rightChild->isConstant() == True))
//	{
//		PTNode *temp = rightChild;
//		rightChild = leftChild;
//		leftChild = temp;
//	};

//	leftChild->semanticCheck();
//	rightChild->semanticCheck();

	for(int i=0; i<argcount; i++)
	{
		args[i]->semanticCheck();
	}
	
	setStepNum();	// don't get the step number until l & r have finished.
	if(nextStmt)
	{
		Compiler_Error("Not sure that a binary optr can have a 'nextStmt'?\n");
	}


};

// Produce the dataflow tables for this binary operation.
// If message == 1, store the result in a temporary variable.

DF_Entry *
PTBinOptr::dataflow(int msg)
{
	DATAFLOW_INIT();
	
//	DF_Entry *l = leftChild->dataflow(1);
//	DF_Entry *r = rightChild->dataflow(1);
	DF_Entry *result = NULL;
	
//	if(l->isConstant() || r->isConstant())
//	{
//		// result is NULL if no folding or algebraic identity done.
//		result = evalConstBinary(l,r,operationToken,getSourceLineNum());
//	}

	if((isCommAssocOptr(operationToken) == False) && (argcount > 2))
	{
		Compiler_Error("Too many opnds for a binary operation (%s)\n",	
							operationStr);
	}
	
	df = new DF_EntryPtr[argcount];
	for(int j = 0; j < argcount; j++)
	{
		df[j] = args[j]->dataflow(1);
	}
	
	result = foldArgs();
	
	if(!result)	// if a result has not yet been found, create the expression.
	{   
		OptrEntry *me = new OptrEntry(operationToken,getSourceLineNum());
   
		//me->setSourceList(l);
		//me->setSourceList(r);
		
		for(int i = 0; i<argcount; i++)
		{
			if(df[i])
				me->setSourceList(df[i]);
		}
		
		//me->setResultType(getDataType(l,r),getPathWidth());
		me->setResultType(getDataType(),getPathWidth());
 	   
 	   // before adding this operation to the data flow graph,
 	   // see if a common subexpression can be found!
 	   
 	   if(CLFlags.CommonSubExpr)
 	   {
 	   	result = CurrentDFG->commSubExpr(me);
 	   }
 	   if(result)
 	   { 	   
	   	if(result->getType() == Entry_optr)
			{	
 	   		// the operation now has another result!
   			if(msg == 1)
   			{
   				OptrEntry *result_optr = (OptrEntry *)result;
   				result = storeOptrInTempOpnd(result_optr,getStepStartNum(),"");
   			}
 	   	}
 	   
 	   	delete me; 	   
 	   }
		else
		{
			if(CLFlags.CommonSubExpr)
				divideIntoSubexpressions(me);
			CurrentDFG->addToDBLK(me);
			// if the message is set to 1, store the result in a temporary 
			// operand, and return that.
   
                        if(msg == 1)
                                result = storeOptrInTempOpnd(me,getStepStartNum(),"");
                        else
                                result = me;
			
		}

	}
	return(result);
};

PTNode *
PTBinOptr::cfold(void)
{
//  leftChild = leftChild->cfold();

//  rightChild = rightChild->cfold();

    PTNode *node;
//  if(leftChild->isConstant() && rightChild->isConstant())
//  {
//     node = evalConstBinary(leftChild, rightChild,
//         operationToken, getSourceLineNum());   
//     if(sem_count.get() != 0)
//     	node->semanticCheck();
//     	
//     leftChild = rightChild = NULL;   // make sure they won't be delete twice.
//      Trash.add(this);	// this will be deleted later.!
//   }  
//   else
   {
      node = this;
   }
   return(node);

};

long
PTBinOptr::getPathWidth(void)
{
   long pathwidth;
   
   switch(operationToken) // get the resulting data type and path width
   {
      case PLUS:     
      case MINUS: 
      case MULTIPLY: 
      case DIVIDE:      
      case MOD:         
      case OR:       
      case XOR:   
      case XNOR:  
      case AND:
      case NAND:
      case NOR:   
//       pathwidth = max(leftChild->getPathWidth(), rightChild->getPathWidth());
         pathwidth = args[0]->getPathWidth();
	 int i;
         for(i=1; i<argcount; i++)
         {
         	pathwidth = max(pathwidth, args[i]->getPathWidth());
         }
         break;
         
      case COMPEQUALS:  // boolean results
      case LT:       
      case LTE:      
      case GT:    
      case GTE:   
      case NOTEQUAL: 
         pathwidth = 1;
         break;   
            
      case ROL:       // result type is that of left operand
      case ROR:         
      case SHL:       
      case SHR:
      case LSQRBRACE:	// array index
         pathwidth = args[0]->getPathWidth();
         break;
             
      default:
         Compiler_Error("Binary Operation (%s) Undefined!\n",operationStr);
         break;
   }
   
   return(pathwidth);
};

DataType
//PTBinOptr::getDataType(DF_Entry *l, DF_Entry *r)
PTBinOptr::getDataType(void)
{
   DataType datatype;
   
   DF_Entry *l = df[0];	
   
   switch(operationToken) // get the resulting data type and path width
   {
      case PLUS:     
      case MINUS: 
      case MULTIPLY: 
      case DIVIDE:      
      case MOD:         
      case OR:       
      case XOR:   
      case XNOR:  
      case NOR:  
      case AND:
      case NAND: 
         datatype = l->getDataType();
         break;
         
      case COMPEQUALS:  // boolean results
      case LT:       
      case LTE:      
      case GT:    
      case GTE:   
      case NOTEQUAL: 
         datatype = Data_bit;
         break;   
            
      case ROL:       // result type is that of left operand
      case ROR:         
      case SHL:       
      case SHR:
      case LSQRBRACE:	// array index
         datatype = l->getDataType();
         break;
             
      default:
         Compiler_Error("Binary Operation (%s) Undefined!\n",operationStr);
         break;
   }
   return(datatype);
};

boolean
PTBinOptr::testProcArg(boolean readstat, boolean writestat)
{
	boolean result = True;	// assume true until proven false.
	if(writestat)
		result = False;		// cannot write to a binary operation!

	return(result);
};

PTNode *
PTBinOptr::make_clone(int message)
{
	PTBinOptr *clone = new PTBinOptr(operationToken, getSourceLineNum());
	
	// copy each of the operands
	for(int i=0; i<argcount; i++)
	{
		PTNode *x = args[i]->make_clone();
		clone->linkChild(x,NULL);
	
	};
	clone->copy_baseClass(this,message);
	return(clone);
};

VIRTUAL void
PTBinOptr::linkChild(PTNode *left, PTNode *right)
{
	if(argcount == argmax)	// need more space
	{
		argmax = argmax + 8;
		PTNodePtr *temp = new PTNodePtr[argmax];
		for(int i=0; i<argcount; i++)
		{
			temp[i] = args[i];
		}
		
		delete args;
		args = temp;
	};
	
	if(left)
		args[argcount++] = left;
		
	if(right)							// recursively add the next operand.
		linkChild(right,NULL);
};

PRIVATE boolean
PTBinOptr::sortArgs(void)
{
	int nextConst = 0;
	
	// sort the constants to the left side
	for(int i = 1; i<argcount; i++)
	{
		if(df[i] && df[i]->isConstant())
		{
			// shift from 0 to i
			DF_Entry *temp = df[i];
			for(int j = i; j > nextConst; j--)
			{
				df[j] = df[j-1];
			}
			df[nextConst++] = temp;
		}
	
	};
	return(True);
};

PRIVATE DF_Entry *
PTBinOptr::foldArgs(void)
{
	boolean try_more_folding = True;
	int prevCount = argcount;
	while(try_more_folding == True)
	{
		
		// can only be sorted if the operation is +, *, &...
		if(isCommAssocOptr(operationToken))
			sortArgs();
	
		for(int i=1; i<argcount; i++)
		{
			DF_Entry *node1 = df[i-1];
			DF_Entry *node2 = df[i];
			if(node1 && node2 && (node1->isConstant() || node2->isConstant()))
			{
				DF_Entry *x;
				x = evalConstBinary(node1,node2,operationToken,getSourceLineNum());
				if(x)
				{
					df[i-1] = NULL;
					df[i] = x;
				}
			}
	
		}/* end for */
		
		compressArgs();
		
		
		// if the operation is folded down to 1 operand, then no more
		// folding can take place.
		if((argcount < prevCount) && (argcount >= 2))
		{
			try_more_folding = True;
			prevCount = argcount;
		}
		else
		{
			try_more_folding = False;
		}
		
	} /* end while */
	
	// if there is only a single entry left, return that!
	// Otherwise, the operation still exists.
	DF_Entry *result = NULL;
	int count = 0;
	for(int i=0; (i<argcount) && (count <= 1);i++)
	{
		if(df[i])
		{
			result = df[i];
			count++;
		}
	};
	
	if(count == 1)
		return(result);
	else
		return(NULL);

};


// Make sure that there are no blank spaces

PRIVATE boolean
PTBinOptr::compressArgs(void)
{
	boolean more_compressing = True;
	while(more_compressing == True)
	{
	
		more_compressing = False;
		for(int i=1; i<argcount; i++)
		{
			if(df[i-1] == NULL && df[i] != NULL)
			{
				df[i-1] = df[i];
				df[i] = NULL;
				more_compressing = True;
			}
		}
	}
	

	// recount the number of args in the list
	int count = 0;
	for(int i = 0; i<argcount; i++)
	{
		if(df[i] != NULL)
			count++;
	}
	argcount = count;
	
	return(True);
};

//------------------------------------------------------------------------
// CLASS PTUnaryOptr()
//------------------------------------------------------------------------

PTUnaryOptr::PTUnaryOptr(int optrToken, int start_lineno) 
            : PTNode(ptreeUnaryOptr, start_lineno)
{
   operationToken = optrToken;
	operationStr = getTokenStr(operationToken);
};

void 
PTUnaryOptr::printMe(void)
{
   char *str = operationStr;
   dumpLine("%s\n",str);
};

PTNode *
PTUnaryOptr::cfold(void)
{
   leftChild = leftChild->cfold();
   
   PTNode *newnode;
   if( leftChild->isConstant() )
   {
      newnode = evalConstUnary(leftChild, operationToken, getSourceLineNum());
      if(sem_count.get() != 0)
      	newnode->semanticCheck();
      	
      leftChild = NULL; // null this so that it won't be deleted again.
      Trash.add(this);	// to be deleted later on!
   }
   else
   {
      newnode = this;
   }
   return (newnode);
};

void
PTUnaryOptr::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();

	leftChild->semanticCheck();
	setStepNum();
	if(nextStmt)
		Compiler_Error("I don't think a unary optr should have a nextStmt\n");


};

DF_Entry *
PTUnaryOptr::dataflow(int msg)
{
	DATAFLOW_INIT();
	DF_Entry *result = NULL;
	
   DF_Entry *l = leftChild->dataflow(1);     
   if(l->isConstant())
   {
   	result = evalConstUnary(l,operationToken, getSourceLineNum());
   }
   if(!result)
   { 
		OptrUnaryEntry *me;
		me = new OptrUnaryEntry(operationToken, getSourceLineNum());
   
		me->setSourceList(l);
		me->setResultType(l->getDataType(), l->getPathWidth());
   
 	   // before adding this operation to the data flow graph,
 	   // see if a common subexpression can be found!
 	   
 	   if(CLFlags.CommonSubExpr)
 	   {
 	   	result = CurrentDFG->commSubExpr(me);
 	   }
 	   if(result) // Yes, a common subexpression was found!
 	   {
 	   	if(result->getType() == Entry_optr)
 	   	{	
 	   		// the operation now has another result!
   			if(msg == 1)
   			{
   				OptrEntry *result_optr = (OptrEntry *)result;
   				result = storeOptrInTempOpnd(result_optr,getStepStartNum(),"");
   			}
 	   	}
 	   
 	   	delete me; 	   
 	   }
		else
		{
			CurrentDFG->addToDBLK(me);
			// if the message is set to 1, store the result in a temporary 
			// operand, and return that.
   
   		if(msg == 1)
			result = storeOptrInTempOpnd(me,getStepStartNum(),"");
		else
			result = me;
		}
	}
   
   return(result);
};

void 
PTUnaryOptr::dumpTree(void)
{
   incDumpIndent();
   leftChild->dumpTree();
   decDumpIndent();
   printMe();
   if(nextStmt) nextStmt->dumpTree();// should never happen ?
   
};

long
PTUnaryOptr::getPathWidth(void)
{
   return(leftChild->getPathWidth());
};

boolean
PTUnaryOptr::testProcArg(boolean readstat, boolean writestat)
{
	boolean result = True;	// assume true until proven false.
	if(writestat)
		result = False;		// cannot write to a unary operation.

	return(result);
};

PTNode *
PTUnaryOptr::make_clone(int message)
{
	PTUnaryOptr *clone = new PTUnaryOptr(operationToken, getSourceLineNum());
	clone->copy_baseClass(this,message);
	return(clone);
};

//------------------------------------------------------------------------
// CLASS PTIdent()
//------------------------------------------------------------------------


PTIdent::PTIdent(char *idname, int start_lineno) 
         : PTNode(ptreeIdent, start_lineno)
{
// name = mallocName(idname); 
   name = idname;  // no need to reallocate since the scanner does it already.
   myste = NULL;   // make sure this is null.
};

PTIdent::~PTIdent(void)
{
   if(name)
   { 
      delete name; 
      name = NULL; 
   };
   
   // do not delete `myste' (taken care of by symbol table destructor).
};

char *
PTIdent::getName(void)
{
   return(name);
};

void 
PTIdent::printMe()
{
   dumpLine("(ident)'%s'\n",name);
};

boolean
PTIdent::testProcArg(boolean readstat, boolean writestat)
{
	// if the identifier is actually a constant, 
	// this will be caught in the PT_Lvalue::semanticCheck!
	return(True);
};

PTNode *
PTIdent::make_clone(int message)
{
	char *clone_name = mallocName(name);
	PTIdent *clone = new PTIdent(clone_name, getSourceLineNum());
	clone->copy_baseClass(this,message);
	return(clone);
};
//------------------------------------------------------------------------
// CLASS PT_Lvalue()
//------------------------------------------------------------------------



PT_Lvalue::PT_Lvalue(char *idname, int start_lineno) 
         : PTIdent(idname, start_lineno)
{
   /* leave initialization of name and sourceLineNum to PTIdent */
};

PT_Lvalue::PT_Lvalue(PTIdent *id):PTIdent(id->getName(),id->getSourceLineNum())
{
   /* leave initialization of name and sourceLineNum to PTIdent */
   // ??? Has this ever been actually used.
};


PT_Lvalue::~PT_Lvalue(void)
{
   /* do nothing */
};


void 
PT_Lvalue::printMe(void)
{
   dumpLine("(Lvalue)'%s'\n",name);
};

//    If the identifier is on the LHS of an equation, then it is being
//    assigned a new value. Therefore, always make a new entry in the
//    operand table.

void 
PT_Lvalue::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();
	setStepNum();
	
   myste = SymTbl.lookup(name);
   if(!myste)
   {
      Error(getSourceLineNum(), "Undefined symbol (%s)!\n",name);
      
      // Insert a dummy symbol into the symbol table.
      myste = SymTbl.insert(name);
      myste->setDataType(Data_int);
      myste->setPathWidth( getDefaultPathWidth( Data_int ));
      myste->setModeAccess(True, True);
   }
   
   // check that the symbol is writeable!
   myste->step_used.setNum(getStepStartNum());
   if(myste->isWriteable() == False)
   {
   	Error(getSourceLineNum(),"Cannot assign value to symbol `%s'.\n",name);
   }
   else
   {
   	myste->step_altered.setNum(getStepStartNum());
   }
};

DF_Entry *
PT_Lvalue::dataflow(int message)
{
	DATAFLOW_INIT();

   OpndEntry *opnd1;
   opnd1 = new OpndEntry(myste,getSourceLineNum());
   return(opnd1);
};

PTNode *
PT_Lvalue::make_clone(int message)
{
	char *prefix = SymTbl.Inline.getPrefix();
	char *clone_name = mallocName(prefix,name);
	PT_Lvalue *clone = new PT_Lvalue(clone_name, getSourceLineNum());
	clone->copy_baseClass(this,message);
	return(clone);
};

//------------------------------------------------------------------------
// CLASS PT_Rvalue()
//------------------------------------------------------------------------



PT_Rvalue::PT_Rvalue(char *idname, int start_lineno) 
         : PTIdent(idname, start_lineno)
{
   /* leave initialization of name and sourceLineNum to PTIdent */
};

PT_Rvalue::PT_Rvalue(PTIdent *id) : PTIdent(id->getName(),0)
{
   /* leave initialization of name and sourceLineNum to PTIdent */
};

PT_Rvalue::~PT_Rvalue(void)
{
   /* do nothing */
};


void 
PT_Rvalue::printMe()
{
   dumpLine("(Rvalue)'%s'\n",name);
};

// An identifier is added to the operand table in one of two ways.
// 1> If the identifier is on the RHS of an equation, then it can
//    use a previous entry in the operand table (if one exists),
//	or  2> simply make a new entry.

void
PT_Rvalue::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();
	setStepNum();
	
   myste = SymTbl.lookup(name);
   if(!myste)
   {
      Error(getSourceLineNum(), "Undefined symbol (%s)!\n",name);
      
      // Insert a dummy symbol into the symbol table.
      myste = SymTbl.insert(name);
      myste->setDataType(Data_int);
      myste->setPathWidth( getDefaultPathWidth( Data_int ));
      myste->setModeAccess(True, True);

   }
   // if this is on the RHS (not LHS), try to find a previous entry for it
   // by following the predecessor block entries. ???

   myste->step_used.setNum(getStepStartNum());
};

DF_Entry *
PT_Rvalue::dataflow(int message)
{
	DATAFLOW_INIT();

	myste->step_accessed.setNum(getStepStartNum());
   // look for a previous version of this name.

   DBlkEntry *dblk = CurrentDFG->peekTODS();
   DF_Entry *opnd = dblk->block_trace(myste);
   
   // try to find something that can be copied.
   DF_Entry *cprop = opnd->copyPropogate();
   return( (cprop) ? cprop : opnd );

};

boolean
PT_Rvalue::isConstant(void)
{
   // CONST symbols cannot be determined until the symbol table
   // is set up, and the semanticChecking is done. So if this 
   // has not been done yet, just return False.
   if(!myste)
   {
      return(False);
   }
   else if(myste->isConstant() == True)	// defined as CONST
   {
   	return(True);
   }
//   else if(myste->copyProp.test() == True)	// was assigned a constant value.
//   {
//   	return(True);
//   }
   else												// none of the above.
   {
   	return(False);
   }
};

long
PT_Rvalue::getValue(void)
{
	if(myste->isConstant() == True)
	{
   	return(myste->getConstantValue());
   }
//   else if(myste->copyProp.test() == True)
//   {
//   	STEntry *ste_const = myste->copyProp.get();
//   	return(ste_const->getConstantValue());
//   }
   else
   {
   	Compiler_Error("PT_Rvalue::getValue() was expected to return by now!\n");
   	return(0);
   }
};

long
PT_Rvalue::getPathWidth(void)
{
   return(myste->getPathWidth());
//	if(myste->isConstant() == True)
//	{
//   	return(myste->getPathWidth());
//   }
//   else if(myste->copyProp.test() == True)
//   {
//   	STEntry *ste_const = myste->copyProp.get();
//   	return(ste_const->getPathWidth());
//   }
//   else
//  {
//   	Compiler_Error("PT_Rvalue::getPathWidth() expected to return by now!\n");
//  	return(0);
//   }
};

PTNode *
PT_Rvalue::cfold(void)
{
//	if(myste && myste->copyProp.test() == True)
//	{
//		STEntry *ste = myste->copyProp.get();
//		long value = ste->getConstantValue();
//		long pw    = ste->getPathWidth();
//		PTNode *constant = new PTConst(value,pw);
//		if(sem_count.get() != 0)
//			constant->semanticCheck();
//	
//		Trash.add(this);
//		return(constant);
//	}
//	else
//	{	
		return(this);
//	};
};

PTNode *
PT_Rvalue::make_clone(int message)
{
	char *prefix = SymTbl.Inline.getPrefix();
	char *clone_name = mallocName(prefix,name);
	PT_Rvalue *clone = new PT_Rvalue(clone_name, getSourceLineNum());
	clone->copy_baseClass(this,message);
	return(clone);
};

//------------------------------------------------------------------------
// CLASS PTConst()
//------------------------------------------------------------------------

PTConst::PTConst(long value, int width, int start_lineno) 
        : PTNode(ptreeConst, start_lineno)
{
   constantValue = value;
   pathwidth = width;
   myste = NULL;

};
//PTConst::~PTConst(void)
//{ /* do nothing special */};
//

long 
PTConst::getValue(void)
{
   return(constantValue);
};

long
PTConst::getPathWidth(void)
{
   return(pathwidth);
};

// Used when a constant is constant folded.
void
PTConst::resetValue(long value)
{
   constantValue = value;
};

void 
PTConst::printMe(void)
{
   dumpLine("(constant) %d\n",constantValue);
};

void
PTConst::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();
		
   myste = SymTbl.lookup(constantValue,pathwidth);
   if(!myste)
   {
      myste = SymTbl.insert(constantValue, pathwidth);   
      myste->setDataType(Data_int); // integer constant for now
   }  
   myste->step_used.setNum(getStepStartNum());

};

DF_Entry *
PTConst::dataflow(int message)
{
	DATAFLOW_INIT();
   myste->step_accessed.setNum(getStepStartNum());
   return(myste);	// the STEntry acts as the DF_Entry!
};

boolean
PTConst::testProcArg(boolean readstat, boolean writestat)
{
	boolean result = True;	// assume true until proven false.
	if(writestat)
		result = False;		// cannot write to a constant!

	return(result);
};


PTNode *
PTConst::make_clone(int message)
{
	PTConst *clone = new PTConst(constantValue, pathwidth, getSourceLineNum());
	return(clone);
};

//------------------------------------------------------------------------
PT_Cond::PT_Cond(PTNode *expr) : PTNode(ptreeCondition)  // constructor
{
   leftChild = expr;
   rightChild = NULL;
};

PT_Cond::~PT_Cond(void) // destructor
{
   if(leftChild)
   {
      delete leftChild;
      leftChild = NULL;
   }
};


// always make sure the result of a condition is set in a 
// temporary result prefixed with "_C" instead of "_T".

DF_Entry *
PT_Cond::dataflow(int message)
{
	DATAFLOW_INIT();
	
   DF_Entry *df = leftChild->dataflow(0);
   if(df->getType() == Entry_optr)
   {
      df = storeOptrInTempOpnd((OptrEntry*)df,getStepStartNum(),"_C");
   }
   return(df);
};



void 
PT_Cond::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();

   leftChild->semanticCheck();
   setStepNum();
   if(leftChild->getPathWidth() != 1)
   {
      Error(leftChild->getSourceLineNum(),
         "A single bit result was expected from this operation!\n");
   }
};

PTNode*
PT_Cond::cfold(void)
{
	leftChild = leftChild->cfold();
   return(this);
};

long 
PT_Cond::getValue(void)
{
   return(leftChild->getValue());
};

// The path width of a condition is always a single bit wide.
long 
PT_Cond::getPathWidth(void)
{
   return(1);
};

void 
PT_Cond::printMe(void)
{
   dumpLine("(cond)\n");
};

void 
PT_Cond::dumpTree(void)
{
   printMe();
   leftChild->dumpTree();
   if(nextStmt)
      nextStmt->dumpTree();

};

boolean
PT_Cond::testProcArg(boolean readstat, boolean writestat)
{
	return(leftChild->testProcArg(readstat,writestat));
};

PTNode *
PT_Cond::make_clone(int message)
{
	PTNode *condition_clone = leftChild->make_clone();
	PT_Cond *clone = new PT_Cond(condition_clone);
	return(clone);
};
//------------------------------------------------------------------------

OpndEntry *storeOptrInTempOpnd(OptrEntry *optr, int stepnum, char *prefix)
{
      char *id = mallocNameTemp(prefix);
      STEntry *ste = SymTbl.insert(id);
      ste->setDataType(optr->getDataType());
      ste->setPathWidth(optr->getPathWidth());
      ste->step_accessed.setNum(stepnum);
      
      OpndEntry *opnd = new OpndEntry(ste, stepnum);
      opnd->setSourceList(optr);		// optr goes into opnd.
      optr->setResultsList(opnd);	// opnd comes from optr.

      return(opnd);
}


//------------------------------------------------------------------------


