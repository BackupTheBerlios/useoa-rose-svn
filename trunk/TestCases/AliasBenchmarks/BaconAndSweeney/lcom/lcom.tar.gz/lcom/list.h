// FILE: LIST.H

#ifndef LIST_H
#define LIST_H

#include <stdlib.h>
#include <stdio.h>

#ifdef NO_INLINE
#define INLINE
#else
#define INLINE inline
#endif

class  list_node
{
   list_node *successor, *predecessor;
   void *item;
   
//   int allocated;
   
//   static int initialized = 0;
//   static list_node *free = NULL;
//   static list_node nodepool[1000];

		friend class List;
   
   public:
      list_node(void);	// constructor
//   	void *operator new (long );
//   	void operator delete(void *);
   	   
};

class List
{

   list_node *head, *tail, *current;
   list_node *locateNode(void *);
      // find a list_node with a certain item.  Returns NULL if not found

   public:

      List(void);
      ~List(void);

      void *rear();
         // get the item of the last list_node.

      void *front();
         // get the item of the first list_node.

      void *succ();
         // get the next item (towards the rear).

      void *pred();
         // get the previous item (towards the front).

      void *get_current();
         // get the current item.
      
      void *remove_front(void);
         // deletes and returns the item stored at the head of the List.

      unsigned del_front();
         // delete the list_node at the front
         
      void *remove_rear(void);
         // deletes and returns the item stored at the tail of the List.
         
      unsigned del_rear();
         // delete the list_node at the back

      unsigned del(void);
         // delete the current list_node.  

      unsigned del(void *);
         // delete the list_node with the passed item if present.

      unsigned ins_after(void *);
         // insert in the next position a list_node with the passed item.

      unsigned ins_before(void *);
         // insert in the previous position a list_node with the passed item.

      unsigned prepend(void *);
         // add a new list_node at the front with the passed item.

      unsigned append(void *);
         // add a new list_node at the back with the passed item.

      void dump_List();
         // dump the List to the screen for debugging.
         
      int empty(void);
         // is the List empty?
      
      int length(void);
         // the number of items in this List.
      
      void join(List *x);
         // place all list_nodes from List x to the end of this List,
         // simultaneously emptying List x.
         
      void clear(void);
         // clear all items from the List.

      void sort(int(*fcmp)(const void *, const void *));

};

// A Stack and a Queue are both a restricted type of List,
// and should not use List as its base class to avoid access
// to the object thru the public methods in List that do not
// pertain to Stack and Queue (ie, append(), getCurrent() , etc). 

class Stack
{
   List s;
   
   public:
      Stack(void);    // constructor
      ~Stack(void);      // destructor
      
       void push(void *x);
         /* pushes x onto the stack */
         
       void* pop(void) ;
         /* pops and returns top of stack */

       int empty(void);
         /* returns true if the stack is empty */

       int full(void);
         /* never full */

       int length(void); 
         /* returns current number of elements on the stack */

       void* top(void) ;
         /* returns reference to the top of stack */
         
       void del_top(void);
         /* pops, but does not return the top of stack */
         
       void clear(void);
         /* remove all elements from the stack */
};

class Queue
{
   List q;
   
   public:
      Queue(void);    // constructor
      ~Queue(void);      // destructor
      
       void enq(void *x);
         /*enqueues x on Queue q */
         
       void* deq(void);
         /* pops and returns top of stack */

       int empty(void) ;
         /* returns true if the Queue is empty */

       int full(void) ;
         /* never full */

       int length(void) ; 
         /* returns current number of elements in the Queue */

       void* front(void)   ;
         /* returns reference to the top of stack */
         
       void del_front(void) ;
         /* pops, but does not return the top of stack */
         
       void clear(void);
         /* remove all elements from the stack */
};

#endif
