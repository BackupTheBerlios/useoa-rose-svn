/* FILE : getlines.h */

#ifndef GETLINES_H
#define GETLINES_H


class SourceInfo
{
	int linenum;
	int filenum;
public:
	SourceInfo(int line);	// constructor
	SourceInfo(void);	// constructor
	~SourceInfo(void);	// destructor
	int getLine(void);
	void setLine(int line_no);

	int getFileNo(void);
	char *getFileName(void);	

};

int openSourceFile(char *fn);

int closeSourceFile(int fileid);

char *getSourceLine(int fileid, int lineNum);

void initSourceLineInfo(void);

char *getFileName(int fileId);

char *getSourceLine(struct sourceFile_S *source);

#endif
