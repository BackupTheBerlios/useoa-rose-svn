
// FILE: PTPROC.C - PARSE TREE PROCEDURE NODES

#include <stdio.h>
#include "lconfig.h"
#include "ptnode.h"
#include "ptexpr.h"
#include "build.h"
#include "globals.h"
#include "ptproc.h"

class DF_Entry;

extern DataFlowGraph *CurrentDFG;
//extern PTNode        *CurrentPF;
extern PTProcDecl        *CurrentPF;

// CLASS PTProcDecl
// CLASS PTLocalDecls
// CLASS PT_ProcCall
// CLASS PT_Return

#ifndef lint
static char *sccsid = "@(#)ptproc.C	1.11 (University of Guelph, VLSI Dept.) 93/06/09";
#endif /* lint */

//------------ function prototypes -------------------------
OpndEntry *storeOptrInTempOpnd(OptrEntry *optr, int lineno, char *prefix);


//------------------------------------------------------------------------
// CLASS PTProcDecl()
//------------------------------------------------------------------------

PTProcDecl::PTProcDecl( PTIdent *pname, 
            PTLocalDecls *parms,
            PTLocalDecls *loc, 
            PTStmt *st,
            int start_lineno)   
            : PTNode(ptreeProcDecl, start_lineno)
{
   /* printf("Compiling procedure \"%s()\"\n",pname->getName());*/
   procname = pname;
   params = parms;
   locals = loc;
   stmts = st; 
   returnDataType = Data_int; /* just fill in a value */
   functionMode = False;      /* assume this is a procedure, 
                                 until told otherwise */
   
   returnStmtFound = False;   /* assume no return stmt found yet. */
   
   internalErrorCount = 0;
   // stack the current PTProcDecl's
   oldPF = CurrentPF;
   CurrentPF = this;
};

PTProcDecl::~PTProcDecl(void)
{
   if(procname)   {delete procname; procname = NULL; };
   if(params)     {delete params;   params = NULL; };
   
   CurrentPF = oldPF;   // pop the stack.
   
//   if(!cleanedUpFlag)
//     cleanUp();
};


// a semanticCheck() checks for proper usage of symbols, including
// data types and definitions, while inserting symbols into the 
// symbol table.

void 
PTProcDecl::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();
	setStepNum();
	
   char *procNameStr = procname->getName();
   STEntry *ste = SymTbl.lookupProc(procNameStr);
   if(ste)
   {
      	Error(getSourceLineNum(),"Symbol `%s' redefined.\n",procNameStr);
   }
   else
   {
   	ste =    SymTbl.insertProc(procNameStr); 
   }
   ste->setPTNode(this);   
// SymTbl.incScope();
   if(params)
      params->semanticCheck();   // 
   if(locals)
   	locals->semanticCheck();   //
   
   if(stmts)
      stmts->semanticCheck();
   
   // a function should have a return statement. This should have been 
   // set in the semantichCheck() for the above stmts.   

   if(functionMode && (returnStmtFound == False))
   {     
      Error(getSourceLineNum(),"Expected a RETURN statement in function %s\n",
                procname->getName());
   }


};

// ::semanticCheck() must be called before ::dataflow() can be called.
// Initialize a new data flow graph.

DF_Entry * 
PTProcDecl::dataflow(int message)
{
	DATAFLOW_INIT();
	
   DataFlowGraph *newdfg = new DataFlowGraph( procname->getName() );
   DataFlowGraph *olddfg = CurrentDFG;
   CurrentDFG = newdfg;
   
   DFCount_resetAll();

   CurrentDFG->pushSBLK(); 
   CurrentDFG->pushDBLK(); 
   CurrentDFG->pushCBLK(); 
   
   if(params)
      params->dataflow();
   if(locals)
   	locals->dataflow();
   if(stmts)
      stmts->dataflow();
   
   CurrentDFG->popBlockLevel();
   
   if(CLFlags.Debug)
   	printf("START PRINTING DFT!!!\n");
   	
   newdfg->print();
   
   delete newdfg;
   
      
   CurrentDFG = olddfg;
   return(NULL);
};

void 
PTProcDecl::printMe(void)
{
   char *idstr = (functionMode) ? "func" : "proc";
   dumpLine("(%s)%s\n",idstr,procname->getName());
};

void
PTProcDecl::dumpTree(void)
{
   printf("TREE DUMP *******************************\n");
   
   char *str = procname->getName();

   incDumpIndent();
   printMe();
   dumpLine("'%s' parameters:",str);
   if(params)
      params->dumpTree();
   
   dumpLine("'%s' locals:",str);
   locals->dumpTree();
   
   if(stmts)
   {
      dumpLine("'%s' stmts:\n",str);
      stmts->dumpTree();
   }


// if(returnExpr)
// {
//    dumpLine("'%s' return:\n",str);
//    returnExpr->dumpTree();
// }

   dumpLine("'%s' End.\n",str);
   
   decDumpIndent();
   if(nextStmt) nextStmt->dumpTree();
   
   printf("END OF TREE DUMP ************************\n");      
};


boolean 
PTProcDecl::get_arg(int count, int &readStatus, int &writeStatus, 
            DataType &datatype)
{  
   if(params)
      return( params->get_arg(count, readStatus, writeStatus,datatype) );
   else
      return(False);
};

void 
PTProcDecl::setFunctionMode(DataType dt)
{
   returnDataType = dt;
   functionMode = True;
};

boolean
PTProcDecl::isProcedure(void)
{
   return( (functionMode) ? False : True );
};

boolean
PTProcDecl::isFunction(void)
{
   return( (functionMode) ? True : False );
};

void
PTProcDecl::setReturnFound(void)
{
   returnStmtFound = True;
};

void 
PTProcDecl::compile(int message)
{
	SymTbl.incScope();
	SymTbl.Inline.reset();
	
	if(CLFlags.Debug)
		printf("SEMANTIC CHECKING STAGE!!!\n");
	semanticCheck();
	
	if(CLFlags.Debug)
		printf("DATAFLOW STAGE!!!\n");
	dataflow();
	
	// this procedure declaration can be cleaned up now to save 
	// memory, as long as we are not in debug mode (since we
	// need to be able to dump the parse tree in debug mode!).

	if(CLFlags.DumpParseTree)	
		dumpTree();

	// do not delete the procedure declaration completely
	// since we need to keep it around for other procedures
	// that might call this procedure (prototype checking)
	// Need to keep everything around since the procedure
	// may be called inline.
				
	//cleanUp();
   //if(locals)     {delete locals;   locals = NULL; };
   //if(stmts)      {delete stmts;    stmts = NULL; };

   
   SymTbl.deleteCurrentScope();
   SymTbl.decScope();
   //cleanedUpFlag = True;
   Trash.clean_it_up();
};

void
PTProcDecl::getInlineCode(PTNodePtr *arglist, int argcount,
									PTNodePtr *inlineCode, PTNodePtr *returnCode)
{
	// add parameters to the symbol table.
	if(params)					
		params->semanticCheck();
	
	// add local declarations to the symbol table.
	if(locals)
		locals->semanticCheck();
	
	PTNode *stmts_clone = stmts->make_clone();
	if(functionMode)
	{
		PTNode *temp = stmts_clone;
		PTNode *next = temp->getNext(False);	// do not unlink
		
		if(temp->getNodeType() == ptreeReturn)
		{
			*returnCode = stmts_clone->getChild(0,True);
			delete stmts_clone;
			stmts_clone = NULL;
		}
		else
		{
			while(temp)	//look for the return statement!
			{
				if(next->getNodeType() == ptreeReturn)
				{
					next = temp->getNext(True);		// unlink temp from next
					break;									// stop the loop
				}
				temp = next;
				next = temp->getNext(False);
			} /* end while */
	
			// get the expression in the return statement, and unlink it.
			*returnCode = next->getChild(0,True);
			delete next;
		}/* end else */
	}
	
	int count, readStat, writeStat;
	DataType dt;	// not actually used.
	
	PTNode *copyIn = NULL;
	PTNode *copyOut = NULL;
	
	// copy in all the IN or INOUT parameters
	for(count = 0; count < argcount; count++)
	{
		PTNode *arg = arglist[count]; // get the count`th real arg.
		
		// get the count'th formal arg.
		params->get_arg(count, readStat, writeStat,dt);
		if(readStat)	// copy it!
		{
			int lineno = arg->getSourceLineNum();
			PTAssign *assign = new PTAssign(lineno);
			char *str = params->get_arg_id(count); // get name of the formal param.
			char *prefix = SymTbl.Inline.getPrefix();
			str = mallocName(prefix,str);	// copy and allocate space
			PT_Lvalue *lval = new PT_Lvalue(str,lineno);
			assign->linkChild(lval,arg);
			
			if(copyIn)
				copyIn->linkNext(assign);
			else
				copyIn = assign;
		}
	}
	
	// copy out all the OUT or INOUT parameters
	for(count = 0; count < argcount; count++)
	{
		PTNode *arg = arglist[count];
		
		params->get_arg(count, readStat, writeStat,dt);
		if(writeStat)	// copy it!
		{
			char *str;
			int lineno = arg->getSourceLineNum();
			PTAssign *assign = new PTAssign(lineno);
			if(arg->getNodeType() != ptreeIdent)
			{
				Compiler_Error("Copy out needs a PTIdent type\n");
			}
			else
			{
				str = ((PTIdent *)arg)->getName();
			}						
			
			// need to make the PT_Rvalue into a PT_Lvalue.
			str = mallocName(str);	// copy and allocate space
			PT_Lvalue *lval = new PT_Lvalue(str,lineno);
			
			char *prefix = SymTbl.Inline.getPrefix();
			str = params->get_arg_id(count);
			str = mallocName(prefix,str);  // copy and allocate space

			PTNode *rval = new PT_Rvalue(str,lineno);
			assign->linkChild(lval,rval);
			
			if(copyOut)
				copyOut->linkNext(assign);
			else
				copyOut = assign;	
		}
	
	}
	
	PTNode *resultingCode = NULL;
	
	resultingCode = copyIn;
	if(resultingCode)
		resultingCode->linkNext(stmts_clone);
	else
		resultingCode = stmts_clone;
	
	if(resultingCode && copyOut)
	{
		resultingCode->linkNext(copyOut);
	}
	else if(copyOut)
	{
		resultingCode = copyOut;
	}
	
	*inlineCode = resultingCode;
};

int
PTProcDecl::getInternalErrorCount(void)
{
	return(internalErrorCount);
};

void
PTProcDecl::setInternalErrorCount(int count)
{
	internalErrorCount = count;
};

PTNode *
PTProcDecl::make_clone(int message)
{
	PTIdent *pname_clone = (PTIdent *)(procname->make_clone());
	
	// the parameter list can be empty.
	PTLocalDecls *params_clone;
	if(params)
		params_clone = (PTLocalDecls *)(params->make_clone());
	else
		params_clone = NULL;
		
	PTLocalDecls *locals_clone = (PTLocalDecls *)(locals->make_clone());
	PTStmt *stmts_clone = (PTStmt *)(stmts->make_clone());
	
	PTProcDecl *clone = new PTProcDecl(pname_clone, params_clone, locals_clone,
		stmts_clone,getSourceLineNum());
	
	if(functionMode)
		clone->setFunctionMode(returnDataType);
	return(clone);
};


//------------------------------------------------------------------------
// CLASS PTLocalDecls()
//------------------------------------------------------------------------

// DataType currentDataType;
// PTIdent *idList;
// boolean isParam;
// boolean readaccess, writeaccess;

// constructor
PTLocalDecls::PTLocalDecls(int start_lineno) 
            : PTNode(ptreeLocalDecl, start_lineno)
{
   currentDataType = Data_int;
   idList = NULL;
   isParam = False;
   isConst = False;
   readaccess = True;
   writeaccess = True;
};

// destructor
PTLocalDecls::~PTLocalDecls(void)   
{ 
   if(idList) { delete idList; idList = NULL;};
};


void
PTLocalDecls::setParameter(boolean param)
{
   isParam = param; 
};

void
PTLocalDecls::setDataType(DataType dt)
{
   currentDataType = dt;
};

void
PTLocalDecls::setIdentList(PTIdent *id)
{
   idList = id;
   isConst = False;
};

void 
PTLocalDecls::setConstList(PTIdent *id, PTNode *expr)
{
   isConst = True;
   idList = id;
   writeaccess = False;
   const_expr = expr;

};

void
PTLocalDecls::setAccessMode(int rwmode)
{
   switch(rwmode)
   {
      case IN:    
         readaccess = True;
         writeaccess = False;
         break;
      case OUT:
         readaccess = False;
         writeaccess = True;
         break;
      case INOUT:       
      default:       
         readaccess = True;
         writeaccess = True;
         break;
   };
      

};


// insert the identifiers in this declaration into the symbol table.
 
void 
PTLocalDecls::semanticCheck(void)
{
	/////SEMANTIC_CHECK_INIT();
	if(sem_count.get() == 0)
		sem_count.inc();
		
	setStepNum();
	
   PTIdent *id = idList;
   while(id)
   {     
   	char *name = mallocName(SymTbl.Inline.getPrefix(),id->getName());
   	
      STEntry *ste = SymTbl.lookup(name);
      if(ste)
      {
         Error("Duplication of identifier '%s'\n",id->getName());
      }
      else
      {
         if(isConst)	// is this a CONST or VAR declaration
         {
            // verify that the const_expr is actually a constant.
            
            if(const_expr->getNodeType() == ptreeConst)
            {
               int cv = const_expr->getValue();
               int pw = getDefaultPathWidth( Data_int );
               ste = SymTbl.insert(cv, pw, name);
            }
         }
         else
         {  
            ste = SymTbl.insert(name);
            ste->setDataType(currentDataType);
            ste->setPathWidth( getDefaultPathWidth( currentDataType ));
            boolean writeable;
            if(SymTbl.Inline.getScope() != 0)
            	writeable = True;
            else
            	writeable = writeaccess;
            	
            ste->setModeAccess(readaccess, writeable);
            if(isParam)
               ste->param.setIsParameter(True);
         }  
      }
      id = (PTIdent *)(id->getNext());
   }
// PTLocalDecls *n = (PTLocalDecls *)getNext();
// if(n)
//    n->semanticCheck();
   if(nextStmt)
      nextStmt->semanticCheck();
};

DF_Entry *
PTLocalDecls::dataflow(int message)
{
	DATAFLOW_INIT();
	
   if(SymTbl.Inline.getScope() != 0)
   {
   	Compiler_Error("PTLocalDecls::dataflow() should not be called inline.\n");
   };

// For each identifier that is part of the parameter list, add
// it to the appropriate place in the data flow graph.

   if(isParam)
   {
      PTIdent *id = idList;
      while(id)
      {  
         STEntry *ste = SymTbl.lookup( id->getName());  
         CurrentDFG->addToParams(ste,readaccess,writeaccess);
      
         id = (PTIdent *)(id->getNext());
      }
   }
   
   
// PTLocalDecls *n = (PTLocalDecls *)getNext();
// if(n)
//     return( n->dataflow() );  
// else
//    return(NULL);

   if(nextStmt)
      return( nextStmt->dataflow() );
   else
      return(NULL);

};

void 
PTLocalDecls::cleanUp(void)
{ };


void
PTLocalDecls::dumpTree(void)
{
   incDumpIndent();
   dumpLine("[local decl]: ");
   if(idList) 
         idList->dumpTree();
   else
         printf("none?\n");
         
   if(nextStmt)   nextStmt->dumpTree();
   decDumpIndent();
};

boolean
PTLocalDecls::get_arg(int count,int &readStatus, int &writeStatus, 
                        DataType &datatype)
{
   int actualCount = idList->nextCount();
   
   if(count >= actualCount)
   {
      if(nextStmt)
      {
         PTLocalDecls *next_local = (PTLocalDecls *)nextStmt;
         return( next_local->get_arg(count-actualCount,
                     readStatus,writeStatus,datatype));
      }
      else
         return(False);
   }
   else
   {  
      
      readStatus = (readaccess) ? 1 : 0;
      writeStatus = (writeaccess) ? 1 : 0;
      datatype = currentDataType;
         
      return(True);
   }
};

char *
PTLocalDecls::get_arg_id(int count)
{
   int actualCount = idList->nextCount();
   
   if(count >= actualCount)
   {
      if(nextStmt)
      {
         PTLocalDecls *next_local = (PTLocalDecls *)nextStmt;
         return( next_local->get_arg_id(count-actualCount));
      }
      else
         return("");
   }
   else
   {  
   	PTIdent *id = idList;
   	for(int i = 0; i < count; i++)
   	{
//   		id = (PTIdent *)(idList->getNext());
   		id = (PTIdent *)(id->getNext());
   	}
   	return(id->getName());
   }
};

PTNode *
PTLocalDecls::make_clone(int message)
{
	PTLocalDecls *clone = new PTLocalDecls(getSourceLineNum());
	
	// local declarations only exist if the idList is not NULL;
	// If so, no need to set paramaters, rwmodes, and identifier lists.
	
	if(idList)
	{
		clone->setParameter(isParam);
		clone->setDataType(currentDataType);
	
		// read / write access
		int access_mode_clone = OUT;
		if(readaccess)
		{
			if(writeaccess)
				access_mode_clone = INOUT;
			else
				access_mode_clone = IN;
		}
		clone->setAccessMode(access_mode_clone);
	
		// either set the ident list or the constantlist.
		PTIdent *id_clone = (PTIdent *)(idList->make_clone());
		
		if(isConst)
		{
			PTNode *const_expr_clone = const_expr->make_clone();
			clone->setConstList(id_clone,const_expr_clone);
		}
		else
		{
			clone->setIdentList(id_clone);
		}
	} /* end if */
	clone->copy_baseClass(this,message);
	
	return(clone);
};
//------------------------------------------------------------------------
// CLASS PT_ProcCall()
//------------------------------------------------------------------------
PT_ProcCall::PT_ProcCall(char *id, boolean inlineflag, int start_lineno) 
   : PTNode(ptreeProcCall, start_lineno)
{
   ident = mallocName(id);
   STEntry *ste = SymTbl.lookup(ident);
   if(!ste)
   {
      Error(getSourceLineNum(),
      	"Unable to find procedure call '%s' in symbol table.\n", ident);
      myprocdecl = NULL;
   }
   else
      myprocdecl = (PTProcDecl *)(ste->getPTNode());
      
   functionMode = False;   // assume this is a procedure, until
                           // set otherwise.
                           
   // This procedure call is only inline if the command line OKs it.
   inlineFlag = inlineflag && CLFlags.InlineCode;
   inlineCode = NULL;
   returnCode = NULL;
   
   inputlist = NULL;
   outputlist = NULL;
};

PT_ProcCall::~PT_ProcCall(void)
{
   if(ident)
   {
      delete ident;
      ident = NULL;
   }
   if(inputlist)
   {
      for(int i=0; i<argcount; i++)
      {
      	PTNode *arg = inputlist[i];
      	delete arg;
      }
      delete inputlist;
      inputlist = NULL;
   }
   if(outputlist)
   {
      for(int i=0; i<argcount; i++)
      {
      	PTNode *arg = outputlist[i];
      	if(arg)
      		delete arg;
      }
      delete outputlist;
      outputlist = NULL;
   }

};

void 
PT_ProcCall::setExprList(PTNode *expr)
{
	if(expr)
 	{
		inputlist = list2array(expr, argcount);
		outputlist = new PTNodePtr[argcount];
		for(int i = 0; i < argcount; i++)
		{
			outputlist[i] = NULL;
		}
 	}
 	else
 	{
 		inputlist = NULL;
 		outputlist = NULL;
 		argcount = 0;
 	}
};

void 
PT_ProcCall::setExprArray(PTNodePtr *expr, int count)
{
	inputlist = expr;
	argcount = count;
	outputlist = new PTNodePtr[argcount];
	for(int i = 0; i < argcount; i++)
	{
		outputlist[i] = NULL;
	}
};

DF_Entry *
PT_ProcCall::dataflow(int message)
{
	DATAFLOW_INIT();
	
	if(inlineFlag)
	{
		if(functionMode)
		{
			inlineCode->dataflow();
			return(returnCode->dataflow(message));
		}
		else	// procedures have no return statements
		{
			return(inlineCode->dataflow());
		}
	}
         
   int readStatus,writeStatus;
   DataType datatype;
   
   OptrProcEntry *proc_optr = new OptrProcEntry(ident, getSourceLineNum());
//   proc_optr->setId();
   
   int in_argcount = 0;
   int out_argcount = 0;
   
   // starting at argcount = 0, find each of the
   // formal paramaters in the procedure call, that has read status.
   
   for(int i = 0; i<argcount; i++)
   {
   	myprocdecl->get_arg(i,readStatus,writeStatus,datatype);
         
      if(readStatus)	// only read the input values.
      {
         in_argcount++;
         PTNode *expr = inputlist[i];
         DF_Entry *df = expr->dataflow(1);
         proc_optr->setSourceList(df);
      }        
      
   }
   
   CurrentDFG->addToDBLK(proc_optr);
   
   // starting at argcount = 0, find each of the
   // formal paramaters in the procedure call, that has write status.   
   
   for(i = 0; i<argcount; i++)
   {
   	myprocdecl->get_arg(i,readStatus,writeStatus,datatype);
      
      if(writeStatus)
      {
         out_argcount++;
         PTNode *expr = outputlist[i];
         if(expr->getNodeType() != ptreeIdent)
            Compiler_Error("arg in proc call for OUT or INOUT ",
                           "should be an ident (?)\n");
            
         STEntry *ste = SymTbl.lookup(((PTIdent *)expr)->getName());
         OpndEntry *opnd = new OpndEntry(ste,getSourceLineNum());
         opnd->setSourceList(proc_optr,out_argcount);
         proc_optr->setResultsList(opnd);
      }        
      
   }
   
   // add this procedure call to the calls list
   // CANNOT do this here anymore since the call may be pruned out!
   //CurrentDFG->addToCalls(ident);

	DF_Entry *result;
	
   // if message is set to 1, store operation in a temporary result.
   if(functionMode)
   {
   	if(message == 1)
      	result = storeOptrInTempOpnd(proc_optr,getStepStartNum(),"");
      else
      	result = proc_optr;
   }
   else
   {
      if(nextStmt)
         nextStmt->dataflow();
		result = NULL;
   }
   
   return(result);
   
}; /* end PT_ProcCall::dataflow() */

void
PT_ProcCall::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();
	setStepNum();
	

   // Verify that a function is used as a function,
   // or that a procedure is used as a procedure.
   
   if(myprocdecl != NULL)
   {
      if( functionMode && myprocdecl->isProcedure() )
      {
         Error(getSourceLineNum(),"Procedure used as a function!\n");
      }
      else if( !(functionMode) && myprocdecl->isFunction() )
      {
         Error(getSourceLineNum(),"Function used as a procedure!\n");
      }
   } /* end if */
   
   
   // if the proc/func was not previously defined, just do a semantic check
   // on the real arguments, without comparing to the formal arguements
   // (since there aren't any!!!)
   
   if(myprocdecl == NULL)
   {
      for(int i=0; i<argcount; i++)
      {
         inputlist[i]->semanticCheck();
      }
      
      return;  // no point in doing any more checking, so return.
   }  
   
   // from this point on, 'myprocdecl' must be defined!!
   
   char *pfstr = ( myprocdecl->isFunction() ) ? "function" :  "procedure";

   // starting at argcount = 0, find the read and write status for each of 
   // the formal parameters used, and test to see if the real argument
   // used is appropriate.
   
	int readStatus, writeStatus;
	DataType datatype;
   
  
   int count = 0;
   while(myprocdecl->get_arg(count,readStatus,writeStatus,datatype))
   {
		PTNode *expr;
		
		// if there are no more expressions to test, 
      // then not enough were supplied.
      if(count >= argcount)
      {
         Error(getSourceLineNum(),
               "Not enough arguments to %s '%s'(only found %d)\n",
                     pfstr,ident,count);
         break;
      }
      else
      {
      	expr = inputlist[count];
      }
      
      if(!inlineFlag)
      {
			expr->semanticCheck();
		}
      
      // An arguement that is supposed to have data direction OUT or INOUT
      // cannot be an operator (binary or unary), a constant, or
      // a function call.
      boolean readstat = readStatus ? True : False;
      boolean writestat = writeStatus ? True : False;
      if(expr->testProcArg(readstat,writestat))
      {
       	if(readstat)
      	{
      		expr->semanticCheck();
      	};
			
			if(writestat)
      	{	 // can only write an identifier with write status.
      		if(expr->getNodeType() != ptreeIdent)
      			Compiler_Error("Expected an identifier for real arg!\n");
      		PTNode *lval = new PT_Lvalue((PTIdent*)expr);
      		lval->semanticCheck();
      		outputlist[count] = lval;
      	}
      }
      else
      {
			Error(getSourceLineNum(),
				"Argument #%d in call to %s %s() cannot be written to!\n",
					count,pfstr,ident) ;     
      }
         
      // now check that the proper data type is used, or can be converted to.
      // FOR LATER ON!!!!!
      
      count++;
   }/* end while */
   
   
   // if there are still more expressions, then there were
   // too many supplied.
   if(count < argcount)
   {
      Error("Line %d: Too many arguments to %s '%s' (Expected %d args)\n",
            getSourceLineNum(),pfstr,ident,argcount);
   }
   
   // get the inline code

   if(inlineFlag && myprocdecl->getInternalErrorCount() == 0)   
   {
   	// no need to continue if there is already a compilation error.
   	
     		int inline_level = SymTbl.Inline.incScope();
   		
   		myprocdecl->getInlineCode(inputlist,argcount,&inlineCode,&returnCode);
			inlineCode->semanticCheck();
			if(returnCode)
				returnCode->semanticCheck();
			SymTbl.Inline.setScope(inline_level);
   }
   else
   {	// this is not inline, so just do a semantic check on each expression.
   	for(int i = 0; i<argcount; i++)
   	{
   		inputlist[i]->semanticCheck();
   	}
   }
   
   
   
   if(nextStmt)
      nextStmt->semanticCheck();
      
   return;
}; /* end PT_ProcCall::semanticCheck() */

void
PT_ProcCall::setFunctionMode(void)
{
   functionMode = True;
};

boolean 
PT_ProcCall::isFunction(void)
{
   return( functionMode );
};

boolean 
PT_ProcCall::isProcedure(void)
{
   return( (functionMode) ? False : True );
};
 
void
PT_ProcCall::dumpTree(void)
{
	incDumpIndent();
	if(functionMode )
		dumpLine("funcCall to %s:",ident);
	else
		dumpLine("procCall to %s:",ident);
		
	if(inlineFlag)
	{
		dumpLine("(inline)\n"); 
		inlineCode->dumpTree();
	}
	else
	{
		dumpLine("\n");
	}

	decDumpIndent();
	if(nextStmt)
		nextStmt->dumpTree();

};

boolean
PT_ProcCall::testProcArg(boolean readstat, boolean writestat)
{
	boolean result = True;
	
	if(writestat)
		result = False;				// cannot write to a function
			
	return(result);
};

PTNode *
PT_ProcCall::make_clone(int message)
{
	PT_ProcCall *clone = new PT_ProcCall(ident,inlineFlag,getSourceLineNum());
	if(functionMode)
		clone->setFunctionMode();
//	PTNode *exprlist_clone = exprlist->make_clone();
//	clone->setExprList(exprlist_clone);

	PTNodePtr *argarray = new PTNodePtr[argcount];
	for(int i=0; i<argcount; i++)
	{
		argarray[i] = inputlist[i]->make_clone();	
	}
	clone->setExprArray(argarray,argcount);
	clone->copy_baseClass(this,message);
	return(clone);
};

//------------------------------------------------------------------------
// CLASS PT_Return()
//------------------------------------------------------------------------

PT_Return::PT_Return(PTNode *ret_expr, int lineno) 
   : PTNode(ptreeReturn, lineno)
{
   expr = ret_expr;
};

PT_Return::~PT_Return(void)
{
   if(expr)
   {
      delete expr;
      expr = NULL;
   }

};

void
PT_Return::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();
	setStepNum();
	
   if(CurrentPF && CurrentPF->isProcedure() )
   {
      Error(getSourceLineNum(), 
         "Cannot return an expression in a procedure.\n");
   }
   
   CurrentPF->setReturnFound();
   
   if(expr)
      expr->semanticCheck();
      
   if(nextStmt)
   {
      Error(getSourceLineNum(), 
            "Return statement should be the last statement!\n");
            
      nextStmt->semanticCheck(); // check for other errors anyway.

   }
   
};

DF_Entry *
PT_Return::dataflow(int message)
{
	DATAFLOW_INIT();

   DF_Entry *df = expr->dataflow(1);
   CurrentDFG->setReturn(df);

   return(NULL);
};

void
PT_Return::dumpTree(void)
{
   incDumpIndent();
   printMe();
   if(expr) expr->dumpTree();
   
   // left and right child should not exist, but use them just in case.
   if(leftChild)     leftChild->dumpTree();
   if(rightChild)    rightChild->dumpTree();
   
   decDumpIndent();
   if(nextStmt)      nextStmt->dumpTree();
};

PTNode *
PT_Return::make_clone(int message)
{
	PTNode *expr_clone = expr->make_clone();
	PT_Return *clone = new PT_Return(expr_clone, getSourceLineNum());
	clone->copy_baseClass(this,message);
	return(clone);
};

PTNode *
PT_Return::getChild(int count, boolean unlinkflag)
{
	PTNode *child = NULL;
	
	if(count == 0)
	{
		child = expr;
		if(unlinkflag == True)
		{
			expr = NULL;
		}
	}
	else
	{
		Compiler_Error("Invalid index (%d) in PT_Return::getChild()\n",count);
	}	
	

	return(child);

};

//-----------------------------------------------------------------------------

