// FILE: YYSTYPE.H

#ifndef YYSTYPE_H
#define YYSTYPE_H

//#include "ptnode.h"
#include "dfentry.h"

class PTNode;
class PT_tuple;

typedef struct
{
	union
	{
		PTNode		*treeptr;
		PT_tuple		*tuple;
		long			intValue;
		double			realValue;
		DataType    dataType;
		char			*name;
	};
	int sourceline;
} YYSTYPE;


#endif
