// FILE : TOKENS.C
// This file works closely with 'tokenstr.c'

#include <stdio.h>
#include "lconfig.h"
#include "tokens.h"  

// file tokenstr.h should only be included here!
#include "tokenstr.h"


extern char *yytext;
extern FILE *yyin;
extern char *SourceFileName;
int yylex(void);

/*****************************************************************************/

char *getTokenStr(int token)
{
   char *str;
   static char tempstr[10];

   if(token < MINTOKEN)
   {
      tempstr[0] = char(token);
      tempstr[1] = '\0';
      str = tempstr;
   }
   else if(token > MAXTOKEN)
      str = "Undefined Token";
   else
      str = TokenString[token - MINTOKEN];

   return(str);

}
/*****************************************************************************/
void getTokenStream(void)
{

   int c,count=0;
   while((c=yylex()) != 0 )
   {
      printf("*** LEX STREAM: %d ('%s',%s)\n",c,yytext,getTokenStr(c));
      count++;
   }
   printf("*** END OF LEX STREAM (%d tokens found) ***\n", count);
   /* reopen file */
   fclose(yyin);
   yyin = fopen(SourceFileName,"r");

}
/*****************************************************************************/
char *getBinOptrStr(int operationToken, boolean flagError)
{
	char *id;
   switch(operationToken)  // get the token strings
  	{
      case PLUS:        id = "+";         break;
     	case MINUS:       id = "-";         break;
      case MULTIPLY:    id = "*";         break;
      case DIVIDE:      id = "/";         break;
     	case MOD:         id = "mod";       break;
      case COMPEQUALS:  id = "==";        break;
      case LT:          id = "<";         break;
      case LTE:         id = "<=";        break;
      case GT:          id = ">";         break;
      case GTE:         id = ">=";        break;
      case NOTEQUAL:    id = "!=";        break;
      case AND:         id = "and";       break;
      case NAND:        id = "nand";      break;
      case OR:          id = "or";        break;
      case XOR:         id = "xor";       break;
      case XNOR:        id = "xnor";      break;
      case NOR:         id = "nor";       break;
      case ROL:         id = "rol";       break;
      case ROR:         id = "ror";       break;
      case SHL:         id = "shl";       break;
      case SHR:         id = "shr";       break;   
      case LSQRBRACE:   id = "$array$";   break;
      default:
         if(flagError == True)
         	Compiler_Error("Binary Operation (%s) Undefined!",operationToken);
         else
         	id = NULL;
         break;
    }
	return(id);
}
/*****************************************************************************/
char *getUnaryOptrStr(int operationToken, boolean flagError)
{
	char *id;
	switch(operationToken)
	{
     	case NOT:         id = "not"; break;
     	case MINUS:       id = "-";   break;
     	default:
			if(flagError == True)
				Compiler_Error("Unary Operation (%s) Undefined!",operationToken);
			else
				id = NULL;
			break;
	}/* end switch */
   	
   return(id);
};








/*****************************************************************************/

