
// FILE: PTNODE.H - PARSE TREE NODES


#ifndef PTNODE_H 
#define PTNODE_H


#include "tokens.h"
#include "boolean.h"
#include "dataflow.h"

#ifdef __TURBOC__
#include "dfentry.h"
#endif

#include "virtual.h"

#define PRIVATE

//-----------------------------------------------------------------------
// The following classes are defined in this file, in this order.
//
class PTNode;			// base class
class PTLocalDecls;
class PTStmt;
class PT_tuple;
class PTAssign;

//-----------------------------------------------------------------------
// Other parse tree classes derived from PTNode, but defined elsewhere.
class PTIdent;

//-----------------------------------------------------------------------

enum enumPtreeNodeType 
		{	ptreeIf, ptreeLoop, ptreeExpr,ptreeBlock,ptreeProcDecl,ptreeFuncDecl,
			ptreeLocalDecl, ptreeAssign, ptreeBinOptr, 
			ptreeUnaryOptr, ptreeStmt, ptreeIdent, ptreeConst,
			ptreeMethodDecl, ptreeMethodList, ptreeImplementation, 
			ptreeInterfaceMap, ptreeProcName, 
			ptreeVersionConstraint, ptreeConstraint,
			ptreeTuple,ptreeRoot, ptreeProcCall,
			ptreeSwitch, ptreeCobegin, ptreeReturn, ptreeCondition,
			ptreeVersionDecl, ptreeVersionId, ptreeOneOf
		};
typedef enum enumPtreeNodeType PtreeNodeType;

typedef PTNode*	PTNodePtr;

//-----------------------------------------------------------------------
// Function prototypes
PTNodePtr *list2array(PTNode *list, int &count);

//-----------------------------------------------------------------------
class StepCounter
{
	int nextStep;
	
	public:
		StepCounter(void);	// constructor
		void reset(void);		// reset to 1
		int getNext(void);	
};
//-----------------------------------------------------------------------
class RepeatCounter
{	
	int count;
	const char *msg;
	
	RepeatCounter(const char *message = "Unknown")	// constructor
	{
		msg = message;
		count = 0;
	};
	friend class PTNode;
	
public:
	void inc(void)
	{
		count++;
	};
	
	void test(void)
	{
		if(count == 0)
		{
				Compiler_Error("PTNode::%s was never called!\n",msg);
		}
	};
	
	int get(void)
	{
		return(count);
	};


};
//-----------------------------------------------------------------------

#define SEMANTIC_CHECK_INIT() {	sem_count.inc(); }

#define DATAFLOW_INIT()	{	if(ErrorCount > 0)	\
					return(NULL);		\
				sem_count.test();		\
				df_count.inc();		\
								}

//-----------------------------------------------------------------------
// the following static is supposed to be defined inside the class PTNode,
// however, gcc-2.0 thinks that this is a bug, so put it outside to fix
// the problem for now.

//#ifdef MYGNU
//static int PTNode_dumpIndent;
//#endif

// Declare it here for all systems.
static int PTNode_dumpIndent;
//-----------------------------------------------------------------------
class PTNode
{
private:

//	int sourceLineNumStart;
//	int sourceLineNumEnd;
	int sourceLineNum;
	int stepStartNum, stepEndNum;
	
	MagicNumber magic;
	
	
protected:

	PTNode *leftChild, *rightChild;  // some inherited classes
						// may have more leaves
	PTNode *nextStmt;
	PTNode *lastStmt;
	boolean cleanedUpFlag;
	PTNode *parentNode;
	
	// count the number of times semanticCheck and dataflow were called.
#ifdef __XXXGNUC__
	RepeatCounter sem_count("semanticCheck()");
	RepeatCounter df_count("dataflow()");	
#else
	RepeatCounter sem_count;
	RepeatCounter df_count;	
#endif
	
	//	void make_copy(PTNode *l, PTNode *r, PTNode *next);
	void copy_baseClass(PTNode *nodetocopy, int message);
	
	PtreeNodeType nodetype;
	void incDumpIndent(void){PTNode_dumpIndent++;};
	void decDumpIndent(void){PTNode_dumpIndent--;};

	void dumpLine(char *format, ...);
	
public:

	PTNode(PtreeNodeType type, int start_lineno = 0);	//constructor
	virtual ~PTNode(void);	// destructor
	
	PtreeNodeType getNodeType(void);
	void printNodeTypeStr(void);
	char *getNodeTypeStr(void);
	
	virtual void linkChild(PTNode *child1, PTNode *child2=(PTNode*)0);
	void linkNext(PTNode *next);
	int  nextCount(void);
	virtual PTNode *getChild(int count, boolean unlinkflag = False);
	PTNode *getLeftChild(boolean unlinkflag = False);
	PTNode *getRightChild(boolean unlinkflag = False);
	
//	int getStartLineNum(void);
//	int getEndLineNum(void);

	int getSourceLineNum(void);
	int getStepStartNum(void);
	int getStepEndNum(void);
	int setStepNum(void);
	
	virtual PTNode *getNext(boolean unlinkflag = False);
	PTNode *getLast(void); 

	virtual void printMe(void);
//	virtual boolean constantFold(long *foldedValue);
	virtual void dumpTree(void);

	virtual void semanticCheck(void);
	virtual DF_Entry *dataflow(int message = 0);
	virtual void cleanUp(void);
	
	virtual PTNode *cfold(void);
	virtual boolean isConstant(void);
	virtual long getValue(void);
	virtual long getPathWidth(void);
//	virtual List *getLvalueList(void);
	virtual PTNode *make_clone(int message = 0);
	
	virtual boolean testProcArg(boolean readstat, boolean writestat);
};
//-----------------------------------------------------------------------
class PTStmt : public PTNode
{
public:
	PTStmt(void);
	DF_Entry *dataflow(int message = 0);
	VIRTUAL PTNode *make_clone(int message = 0);
};

//-----------------------------------------------------------------------

class PT_tuple : public PTNode
{

	PTNodePtr *nodes;
	int count;
	boolean unlinkFlag;
public:
	PT_tuple(int size, int start_lineno);
	PT_tuple(PTNode *node0, PTNode *node1, int start_lineno = 0);
	~PT_tuple(void);
	PTNode *getTuple(int i);
	void setTuple(int i, PTNode *n);
	void unlink(void);
	void constantFoldCond(int i);
	VIRTUAL PTNode *make_clone(int message = 0);
};


//-----------------------------------------------------------------------

class PTAssign : public PTNode
{
public:
	PTAssign(int lineno = 0);
	void dumpTree(void);
	DF_Entry *dataflow(int message = 0); 
	void semanticCheck(void);
	VIRTUAL PTNode *make_clone(int message = 0);
};

//-----------------------------------------------------------------------

#endif
