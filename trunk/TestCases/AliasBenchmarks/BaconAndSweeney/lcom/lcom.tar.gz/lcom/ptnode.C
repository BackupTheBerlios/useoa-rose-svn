
// FILE: PTNODE.C	- PARSE TREE NODES

#include <stdio.h>
#include "lconfig.h"
#include "ptnode.h"
#include "ptexpr.h"
#include "build.h"
#include "globals.h"

class DF_Entry;

extern DataFlowGraph *CurrentDFG;
//extern PTNode        *CurrentPF;
//extern PTProcDecl        *CurrentPF;

// CLASS PTNode
// CLASS PTProcDecl
// CLASS PTLocalDecls
// CLASS PTAssign
// CLASS PTStmt
// CLASS PT_tuple

#ifndef lint
static char *sccsid = "@(#)ptnode.C	1.24 (University of Guelph, VLSI Dept.) 93/06/09";
#endif /* lint */

//------------ function prototypes -------------------------
// none

//-----------------------------------------------------------------------

StepCounter Steps;	// create a static object

//-----------------------------------------------------------------------
StepCounter::StepCounter(void)	// constructor
{
	reset();
};
void StepCounter::reset(void)		// reset to 1
{
	nextStep = 1;
};

int StepCounter::getNext(void)
{
	return(nextStep++);	
};

//------------------------------------------------------------------------
// CLASS PTNode (generic class)
//------------------------------------------------------------------------

// constructor
PTNode::PTNode(PtreeNodeType newtype, int lineno)
{
	nodetype = newtype;
	nextStmt = 		(PTNode *)0;
	lastStmt = 		(PTNode *)0;
	leftChild = 	(PTNode *)0;
	rightChild = 	(PTNode *)0;
	
	cleanedUpFlag = False;
	sourceLineNum = lineno;
	stepStartNum = stepEndNum = 0;

	
	if(nodetype == ptreeRoot) PTNode_dumpIndent = 1; // initialize
	
	// count the number of times 'semanticCheck()' and 'dataflow()'
	// are called for this PTNode.
	//sem_count = df_count = 0;
};

int
PTNode::getSourceLineNum(void)
{
	return(sourceLineNum);
};

int
PTNode::getStepStartNum(void)
{
	return(stepStartNum);
};

int
PTNode::getStepEndNum(void)
{
	return(stepEndNum);
};

// destructor
PTNode::~PTNode(void)
{
	if(nextStmt)	{ delete nextStmt; 	nextStmt = NULL; };
	if(leftChild)	{ delete leftChild;	leftChild = NULL; };
	if(rightChild)	{ delete rightChild;	rightChild = NULL; };
	
	if(!cleanedUpFlag)	cleanUp();
};

PtreeNodeType 
PTNode::getNodeType(void)
{
	return(nodetype);
};

void 
PTNode::linkChild(PTNode *child1, PTNode *child2)
{ 	
	if(child1)
	{
		leftChild = child1;
		child1->parentNode = this;
	}
	if(child2)
	{
		rightChild = child2;
		child2->parentNode = this;
	}
};

PTNode *
PTNode::getLeftChild(boolean unlinkflag)
{
	PTNode *child = leftChild; 
	if(unlinkflag == True)
		leftChild = NULL; 
	return(child);
};

PTNode *
PTNode::getRightChild(boolean unlinkflag)
{
	PTNode *child = rightChild; 
	if(unlinkflag == True)
		rightChild = NULL; 
	return(child);
};

PTNode *
PTNode::getChild(int count, boolean unlinkflag)
{
	PTNode *child = NULL;
	
	switch(count)
	{
		case 0:
			child = getLeftChild(unlinkflag);	
			break;
		case 1:
			child = getRightChild(unlinkflag);	
			break;
		default:
			Compiler_Error("Virtual call to PTNode::getChild(count = %d)\n",
								count);
			break;
	}/* end switch */
	return(child);
};


// link in the new node sequentially. ie, it must go to the end of the list.

void 
PTNode::linkNext(PTNode *newnode)
{
	if(lastStmt)
	{
		lastStmt->linkNext(newnode);
		lastStmt = newnode;
	}
	else
	{
		nextStmt = newnode;	// if this is the last node, then newnode will
		lastStmt = newnode;	// be next and last from here.
	}
};

int 
PTNode::nextCount(void)
{
	if(nextStmt)
		return(nextStmt->nextCount() + 1);
	else
		return(1);
};

int 
PTNode::setStepNum(void)
{
	int x = Steps.getNext();
	if(stepStartNum == 0)
		stepStartNum = x;
	else
		stepEndNum = x;
		
	return(x);
};

void 
PTNode::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();
	setStepNum();
	if(leftChild)  leftChild->semanticCheck();
	if(rightChild) rightChild->semanticCheck();
	if(nextStmt)	nextStmt->semanticCheck();
};

void
PTNode::cleanUp(void)
{
	cleanedUpFlag = True;
};

char *
PTNode::getNodeTypeStr(void)
{
	char *str;
	switch(nodetype)
	{
	case ptreeIf: 						str = "if"; break;
	case ptreeExpr:					str = "expr"; break;
	case ptreeBlock: 					str = "block"; break;
	case ptreeProcDecl: 				str = "procDecl"; break;
	case ptreeFuncDecl: 				str = "funcDecl"; break;
	case ptreeLocalDecl: 			str = "localDecl"; break;
	case ptreeAssign: 				str = ":="; break; 
	case ptreeBinOptr: 				str = "binop"; break; 
	case ptreeUnaryOptr: 			str = "unop"; break;
	case ptreeStmt: 					str = "stmt"; break; 
	case ptreeIdent: 					str = "ident"; break; 
//	case ptreeDataStor:				str = "storage-element";break;
	case ptreeConst: 					str = "const"; break;
	case ptreeMethodDecl: 			str = "methodDecl"; break;
	case ptreeMethodList: 			str = "methodList"; break; 
	case ptreeImplementation: 		str = "implementation"; break; 
	case ptreeInterfaceMap: 		str = "interfaceMap"; break;
	case ptreeProcName: 				str = "procName"; break; 
	case ptreeVersionConstraint: 	str = "versionConstraint"; break;
	case ptreeConstraint: 			str = "constraint"; break;
	case ptreeRoot:					str = "Root"; break;
	case ptreeLoop:					str = "Loop"; break;
	case ptreeProcCall:				str = "procCall"; break;
	case ptreeReturn:					str = "return";break;
	default: 							str = "Unknown Node Type"; break;
	
	}
	return(str);
};

void
PTNode::printNodeTypeStr(void)
{
	char *str = getNodeTypeStr();
	printf("[%s]\n",str);
};

void
PTNode::dumpTree(void)
{	
	incDumpIndent();
	printMe();
	if(leftChild)		leftChild->dumpTree();
	if(rightChild)		rightChild->dumpTree();
	decDumpIndent();
	if(nextStmt)		nextStmt->dumpTree();
};

void
PTNode::dumpLine(char *format, ...)
{
	int i;
	for(i=0;i<PTNode_dumpIndent;i++)
		putchar('.');
	
	va_list argptr;

   va_start(argptr, format);
   vprintf(format, argptr);
   va_end(argptr);
	
};

void
PTNode::printMe(void)
{
	dumpLine("[%s]\n",getNodeTypeStr());
};

DF_Entry *
PTNode::dataflow(int message)
{
	DATAFLOW_INIT();

	if(leftChild)
		leftChild->dataflow();
	if(rightChild)
		rightChild->dataflow();
	if(nextStmt)
		nextStmt->dataflow();
		
	return((DF_Entry *)0);
};	

PTNode *
PTNode::cfold(void)			{return(this);};

boolean 
PTNode::isConstant(void)		{return(False);};

long 
PTNode::getValue(void)			{return(0L); };

long 
PTNode::getPathWidth(void)		{return(0L); };

PTNode*
PTNode::make_clone(int message)
{
	Compiler_Error("Unexpected call to virtual function PTNode::make_clone()\n");
	return(NULL);
};

// if message is 1, then do not copy the next field.
void
PTNode::copy_baseClass(PTNode *x, int message)
{
	leftChild  = (x->leftChild)  ? (x->leftChild)->make_clone()  : NULL;
	rightChild = (x->rightChild) ? (x->rightChild)->make_clone() : NULL;
	if(message == 1)
	{
		nextStmt = lastStmt = NULL;
	}
	else
	{
		if(x->nextStmt)
		{
			nextStmt = (x->nextStmt)->make_clone();
			lastStmt = nextStmt->getLast(); 	
		}
		else
		{
			nextStmt = lastStmt = NULL;
		}
	}
};

PTNode *
PTNode::getNext(boolean unlinkflag) 
{
	PTNode *next = nextStmt; 
	if(unlinkflag == True)
		nextStmt = NULL; 
	return(next);
};

PTNode *
PTNode::getLast(void)
{
	if(!nextStmt)
	{
		return(this);	// this must be the last.
	}
	else if(lastStmt)	// recalculate last stmt.
	{
		lastStmt = lastStmt->getLast();	
		return(lastStmt);
	}
	else /* nextStmt && !lastStmt */
	{
		lastStmt = nextStmt->getLast();
		return(lastStmt);
	
	}
};

boolean
PTNode::testProcArg(boolean readstat, boolean writestat)
{
	Compiler_Error("Virtual call to PTNode::testProcArg()\n");
	return(False);
};

//------------------------------------------------------------------------
// CLASS PTAssign()
//------------------------------------------------------------------------

PTAssign::PTAssign(int start_lineno) : PTNode(ptreeAssign, start_lineno)
{};

void 
PTAssign::dumpTree(void)
{
	incDumpIndent();
	leftChild->dumpTree();
	decDumpIndent();
	
	printMe();
	
	incDumpIndent();
	rightChild->dumpTree();
	decDumpIndent();
	if(nextStmt) nextStmt->dumpTree();
};

void
PTAssign::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();
	
	rightChild->semanticCheck();	
	rightChild = rightChild->cfold();
	
	leftChild->semanticCheck();
	leftChild = leftChild->cfold();
	
	setStepNum();
	if(nextStmt)
		nextStmt->semanticCheck();
};

DF_Entry *
PTAssign::dataflow(int message)
{
	DATAFLOW_INIT();
		
	DF_Entry *r, *l;
	OptrEntry *optr;
	
	r = rightChild->dataflow();
	
	switch(r->getType())
	{
		case Entry_opnd:
		case Entry_symtbl:
		//case Entry_loopmerge:
		//case Entry_merge:
			// In an assignment statement with no operators on the RHS
			// of the equation, we need to make an entry in the operator
			// table so that there is still a flow of control specified.
			// So, add an 'ASSIGNEQUALS' operator to the operator table, with
			// its source being the constant or single operand on the RHS.
			// Then add the identifier on the LHS of the assignment
			// to the operand table, with its source being the operator
			// (unary :=) which was added to the operator table.
			
			optr = new OptrAssignEntry(getSourceLineNum());
			optr->setSourceList(r);	// only one source for this operator
			CurrentDFG->addToDBLK(optr);
			
			// special case: since a value is being assigned to the 
			// element on the left hand side, it MUST make a new
			// entry in the operand table, and NOT use any previous 
			// reference.
			
			l = leftChild->dataflow();	
			l->setSourceList(optr);
			optr->setResultsList(l);
			
			break;
		case Entry_optr:
			// The right side of the assignment was an equation (noted by
			// the fact that it is of type 'Entry_optr'),  so
			// at least one entry must have been made in the operator
			// table. Therefore, add the identifier on the LHS
			// of the assignment to the operand table, with its
			// source being the operator that was added to the operator table.
			
			optr = (OptrEntry *)r;
			l = leftChild->dataflow();
			l->setSourceList(optr);
			optr->setResultsList(l);
			break;
		default:
			Compiler_Error("No enum EntryType in PTAssign::dataflow().\n");
			break;
	};
	
	
//	if(r->isDefinitelySet() == False)
//	{
//#ifdef DEBUG
//		Error(getSourceLineNum(),
//			"DEBUG: Value for '%s' not definitely set. Cannot be used in expr.\n",
//				l->getName());
//#endif
//	}
	if(nextStmt)
		nextStmt->dataflow();
		
	return( (DF_Entry *)0);

};

PTNode *
PTAssign::make_clone(int message)
{
	PTAssign *clone = new PTAssign(getSourceLineNum());
	clone->copy_baseClass(this,message);
	return(clone);
};

//------------------------------------------------------------------------
// CLASS PTStmt()
//------------------------------------------------------------------------

PTStmt::PTStmt(void) : PTNode(ptreeStmt)
{};

DF_Entry *
PTStmt::dataflow(int message)
{
	DATAFLOW_INIT();

	if(leftChild)
		leftChild->dataflow();
	
	if(rightChild)
		Compiler_Error("Right Child not expected from PTStmt()\n");
		
	if(nextStmt)
		nextStmt->dataflow();
		
	return(NULL);
};

PTNode *
PTStmt::make_clone(int message)
{
	PTStmt *clone = new PTStmt();
	clone->copy_baseClass(this,message);
	return(clone);
};

//------------------------------------------------------------------------
// CLASS PT_tuple()
//------------------------------------------------------------------------
PT_tuple::PT_tuple(int size, int start_lineno) 
	: PTNode(ptreeTuple, start_lineno)
{
	count = size;
	nodes = new PTNodePtr[count];
	for(int i=0; i<count; i++)
		nodes[i] = NULL;
	unlinkFlag = False;
};

PT_tuple::PT_tuple(PTNode *x0, PTNode *x1, int start_lineno) 
	: PTNode(ptreeTuple,start_lineno)
{
	count = 2;
	nodes = new PTNodePtr[count];
	nodes[0] = x0;
	nodes[1] = x1;
	unlinkFlag = False;
};


void
PT_tuple::setTuple(int i, PTNode *x)
{
	if(i<0 || i > count+1)
		Compiler_Error("Array bound out of range, PT_tuple::setTuple()\n");
	nodes[i] = x;


};

PTNode *
PT_tuple::getTuple(int i)
{
	if(i<0 || i > count+1)
		Compiler_Error("Array bound out of range, PT_tuple::getTuple()\n");

	return(nodes[i]);
};

// Do not delete the nodes from this tuple when the unlinkFlag is set to True.
// This method is used to allow the parser to carry a set of nodes together in
// one single rule.

void
PT_tuple::unlink(void)
{
	unlinkFlag = True;
};

PT_tuple::~PT_tuple(void)
{
	if(unlinkFlag == False)	// Only delete the nodes if unlink if false.
	{
		for(int i = 0; i<count; i++)
		{
			PTNode *n = nodes[i];
			if(n)
				delete n;
				
		}
	}
	delete nodes;
};

void
PT_tuple::constantFoldCond(int i)
{
	if(nodes[i])
		nodes[i] = nodes[i]->cfold();
};

PTNode *
PT_tuple::make_clone(int message)
{
	PT_tuple *clone = new PT_tuple(count, getSourceLineNum());
	for(int i = 0; i < count; i++)
	{
		// 
		PTNode *tempnode = nodes[i];
		if(tempnode)
			tempnode = tempnode->make_clone();
		clone->setTuple(i,tempnode);
	};
	clone->copy_baseClass(this,message);

	return(clone);
};

//------------------------------------------------------------------------
PTNodePtr *list2array(PTNode *mylist, int &size)
{
	size = mylist->nextCount();
	PTNodePtr *x = new PTNodePtr[size];
	
	PTNode *thisarg = mylist;

	for(int i=0; i<size; i++)
	{
		PTNode *nextarg = thisarg->getNext(True);	// get the next, and unlink it.
		x[i] = thisarg;
		thisarg = nextarg;
	}

	return(x);

};




//------------------------------------------------------------------------
/***************
void copyPropogate(PTNode *l, PTNode *r)
{
	PtreeNodeType nt = l->getNodeType();
	if(nt == ptreeIdent)
	{
		PT_Lvalue *lval = (PT_Lvalue *)l;
		STEntry *ste = SymTbl.lookup(l->getName());
	}
	else
	{
		return;
	};
	
	nt = r->getNodeType();
	if(nt == ptreeIdent)
	{
		
	
	
	}



}

********************/



//------------------------------------------------------------------------

