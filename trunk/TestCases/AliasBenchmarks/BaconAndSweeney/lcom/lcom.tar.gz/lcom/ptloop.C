// FILE : PTLOOP.C

#ifndef lint
static char *sccsid = "@(#)ptloop.C	1.21 (University of Guelph, VLSI Dept.) 93/06/09";
#endif /* lint */


#include <stdio.h>
#include "lconfig.h"
#include "ptloop.h"
#include "build.h"
#include "globals.h"

#ifdef __TURBOC__
#include <string.h>
#endif

class DF_Entry;

extern DataFlowGraph *CurrentDFG;
extern PTNode        *CurrentPF;

//class PT_Loop;
//class PT_NLoop;			// LOOP n TIMES
//class PT_WLoop;			// WHILE cond LOOP
//class PT_RLoop;			// LOOP i IN [ x .. y]


//------------------------------------------------------------------------
// CLASS PT_Loop()
//------------------------------------------------------------------------
PT_Loop::PT_Loop(int lineno) 
		: PTNode(ptreeLoop, lineno)	// Constructor
{
	// use the left child as the expression, and the right child as the body.
	
	leftChild = rightChild = NULL;
	loopId = NULL;
	loopInitStmt = NULL;
	loopIncStmt = NULL;
	loopCond = NULL;

};

PT_Loop::~PT_Loop(void)		// destructor
{
	// the base destructor should delete the left and right children.
	if(loopId)
	{
		delete loopId;
		loopId = NULL;
	}
	if(loopInitStmt)
	{
		delete loopInitStmt;
		loopInitStmt = NULL;
	}
	if(loopIncStmt)
	{
		delete loopIncStmt;
		loopIncStmt = NULL;
	}
	if(loopCond)
	{
		delete loopCond;
		loopCond = NULL;
	}
};
void 
PT_Loop::setExpr(PTNode *expr)
{
	leftChild = expr;
};



void
PT_Loop::setBody(PTNode *body)
{
	rightChild = body;
};

void 
PT_Loop::semanticCheck(void)
{
	Compiler_Error("Virtual call to PT_Loop::semanticCheck()\n");	
};


DF_Entry * 
PT_Loop::dataflow(int message)
{
	DATAFLOW_INIT();
	
	// initialization statement can go in the block that precedes this loop.
	if(loopInitStmt)
		loopInitStmt->dataflow();	 // initialize counter
	
	// set up this loop entry.
	LoopEntry *myloop = new LoopEntry(getSourceLineNum());
	CurrentDFG->addToCBLK(myloop);
	
	// Set up the loop merge points (finish them off after the dataflow)
	// Need one LoopMergeEntry for each variable that has changed
	// inside the loop statement.
	
	SymTbl.start_Lvalue_List();
	STEntry *ste = SymTbl.get_Next_Lvalue();
	
	while(ste)
	{
		// ::lineNumAltered was set in the stmts->semanticCheck().
	
		if(ste->step_altered.inRange(getStepStartNum(),getStepEndNum()) )
		{
			LoopMergeEntry *lme = new LoopMergeEntry(ste,getSourceLineNum());
			//CurrentDFG->addToCBLK(lme);
			myloop->appendMergePt(lme);
			CBlkEntry *cblk = CurrentDFG->peekTOCS();

			DF_Entry *before = (cblk->getPredBlock())->block_trace(ste);
			lme->set(before,NULL);	// set the after value later.
		}
		
		ste = SymTbl.get_Next_Lvalue();
	}/* end while */


	{	// set up for condition block

		CurrentDFG->pushSBLK(True);
		CurrentDFG->pushDBLK();
		CurrentDFG->pushCBLK();
	
		// make sure the condition gets stored an operand.
		
		DF_Entry *condSignal = loopCond->dataflow(1);

		// the condition of the loop may begin as part of the sblk, dblk, or cblk;
		// So find first one.
		myloop->setCondBlock(CurrentDFG->getFirstUsableBlockEntry(), condSignal);
		CurrentDFG->popBlockLevel();
	}

	
	
	CBlkEntry *cblk = CurrentDFG->peekTOCS();


	// set up for body of loop	
	CurrentDFG->pushSBLK(True);
	CurrentDFG->pushDBLK();
	CurrentDFG->pushCBLK();

	boolean bodyflag = False;

	if(rightChild)
	{
		rightChild->dataflow();	 // body of the loop.
		bodyflag = True;
	}
	if(loopIncStmt)
	{
		// incrementing is implicitly part of the body of the loop.
		loopIncStmt->dataflow(); 		
		bodyflag = True;
	}

	// the body of the loop may begin as part of the sblk, dblk, or cblk; 
	// So find first one.
	BlockEntry *body = NULL;
	if(bodyflag) 
		body = CurrentDFG->getFirstUsableBlockEntry();
		
	myloop->setBodyBlock(body);
	CurrentDFG->popBlockLevel();

	if(bodyflag)
	{
		SymTbl.start_Lvalue_List();
		ste = SymTbl.get_Next_Lvalue();
		while(ste)
		{
			if(ste->step_altered.inRange(getStepStartNum(),getStepEndNum()) )
			{
				LoopMergeEntry *x = (LoopMergeEntry *)(cblk->block_trace(ste));	
#ifdef DEBUG
				if(x->isMergePoint() == False)
				{
					Compiler_Error("LoopMergeEntry object expected!!\n");
				}

#endif /* DEBUG */
					
				DF_Entry *after = body->block_trace(ste);
				x->set(NULL,after);	// before was set earlier.
			}
			ste = SymTbl.get_Next_Lvalue();
		
		} /* end while */
		
	} /* end if(bodyflag) */

	// fill in LoopMergeEntry for the loop increment variable.
//	if(mymerge)
//	{
//		STEntry *loopSTE = SymTbl.lookup(loopId);
//		before = (cblk->getPredBlock())->block_trace(loopSTE);
//		after = body->block_trace(loopSTE);
//			
//		mymerge->set(before,after);
//	}
	
	
	
	// it is possible that the next statement after this loop can
	// be combined as part of the current sequencing block, so just
	// add a new control block and a new data block, so that they might
	// be used.
	
	CurrentDFG->pushDBLK();
	CurrentDFG->pushCBLK();
	
	
	if(nextStmt)
		nextStmt->dataflow();	
	// statements should have no return value from dataflow().
	
	return(NULL);

};

void
PT_Loop::dumpTree(void)
{

	incDumpIndent();
	printMe();

	if(loopInitStmt)
	{
		dumpLine("Loop initialization\n");
		loopInitStmt->dumpTree();
	}

	dumpLine("Loop Condition:\n");
	loopCond->dumpTree();

	if(rightChild || loopIncStmt)
	{
		dumpLine("Loop Body:\n");
	}

	if(rightChild)
		rightChild->dumpTree();
	if(loopIncStmt)
		loopIncStmt->dumpTree();

	dumpLine("Loop End.\n");
	
	decDumpIndent();
	if(nextStmt) nextStmt->dumpTree();
};

//------------------------------------------------------------------------
// CLASS PT_NLoop()
//------------------------------------------------------------------------
PT_NLoop::PT_NLoop(int lineno) 
			: PT_Loop(lineno)	// Constructor
{
	// use the left child as the expression, and the right child as the body.
};

PT_NLoop::~PT_NLoop(void)		// destructor
{
	// the base destructor should delete the left and right children.
	if(loopId)
	{
		delete loopId;
		loopId = NULL;
	}
	if(loopInitStmt)
	{
		delete loopInitStmt;
		loopInitStmt = NULL;
	}
	if(loopIncStmt)
	{
		delete loopIncStmt;
		loopIncStmt = NULL;
	}
	if(loopCond)
	{
		delete loopCond;
		loopCond = NULL;
	}
};

void 
PT_NLoop::semanticCheck(void)
{
	
	if(!leftChild || !rightChild)
		Compiler_Error("Loop structure incorrectly formed!\n");

	SEMANTIC_CHECK_INIT();
		
	// explicitly declare a temp. id, and assign zero to it.
	
	// Make a temporary integer for the loop counter (initialize to 0).
	// Usually, only explicitly declared variables are inserted into 
	// the symbol table during PTLocalDecl::semanticCheck().
	
	loopId = mallocNameTemp();
	SymTbl.insert(loopId);
	
	// set up the loop initialization  (loopId := 1)
	PT_Lvalue *loopCounter = new PT_Lvalue(loopId,getSourceLineNum());
	loopInitStmt = new PTAssign(getSourceLineNum());

	// constants inserted into ST automatically.
	PTConst *initconst = new PTConst(1,32,getSourceLineNum()); 
	loopInitStmt->linkChild(loopCounter,initconst);
	
	
	// set up the loop incrementer	(loopId := loopId + 1)
	PTBinOptr *incr = new PTBinOptr(PLUS);

	// constants inserted into ST automatically.
	PTConst *incValue = new PTConst(1,32);

	PT_Lvalue *lval = new PT_Lvalue(loopId,getSourceLineNum());
	PT_Rvalue *rval1 = new PT_Rvalue(loopId,getSourceLineNum());
	loopIncStmt = new PTAssign(getSourceLineNum());
	
	incr->linkChild(rval1,incValue);
	loopIncStmt->linkChild(lval,incr);
	
	// set up the loop condition
	// while (loopId <= expr)  (for LOOP n TIMES (only))

	loopCond = new PTBinOptr(LTE,getSourceLineNum());		
	PT_Rvalue *rval2 = new PT_Rvalue(loopId,getSourceLineNum());
	
	
	// do not actually delete the left child, 
	// since it may be needed for cloning later on.
	PTNode *n_expr = leftChild->make_clone();
	n_expr->semanticCheck();
	n_expr = n_expr->cfold();

	// check that the N is actually a constant!
	if(n_expr->isConstant() == False)
	{
		Error(n_expr->getSourceLineNum(),
			"Constant expression expected for NLoop.\n");
	}	
	
	loopCond->linkChild(rval2,n_expr);		
	loopCond = loopCond->cfold();
		
	// check the newly created explicit loop counter
	// (also inserts the new symbol into symbol table)
	loopInitStmt->semanticCheck();	
	setStepNum();	//loop does not start until loop is initialized.

	loopCond->semanticCheck();	
	
	// check the body of the loop
	rightChild->semanticCheck();	

	loopIncStmt->semanticCheck();
	setStepNum();
	
	if(nextStmt)
		nextStmt->semanticCheck();
	
};

PTNode *
PT_NLoop::make_clone(int message)
{
	PT_NLoop *clone = new PT_NLoop(getSourceLineNum());
	
	clone->copy_baseClass(this,message);
	return(clone);	
};
//------------------------------------------------------------------------
// CLASS PT_WLoop()
//------------------------------------------------------------------------
PT_WLoop::PT_WLoop(int lineno) 
			: PT_Loop(lineno)	// Constructor
{
	// use the left child as the expression, and the right child as the body.
	int i = 23; /* do something */

};

PT_WLoop::~PT_WLoop(void)		// destructor
{
	// the base destructor should delete the left and right children.
	if(loopCond)
	{
		delete loopCond;
		loopCond = NULL;
	}
};

void
PT_WLoop::setExpr(PTNode *express)
{
	loopCond = express;
};

void 
PT_WLoop::semanticCheck(void)
{
 
	SEMANTIC_CHECK_INIT();
	setStepNum();
	
	loopCond = loopCond->cfold();
	loopCond->semanticCheck();	

	rightChild->semanticCheck();	// check the body of the loop
	
	setStepNum();
	
	if(nextStmt)
		nextStmt->semanticCheck();
	
};

PTNode *
PT_WLoop::make_clone(int message)
{
	PT_WLoop *clone = new PT_WLoop(getSourceLineNum());
	PTNode *loopCond_clone = loopCond->make_clone();
	clone->setExpr(loopCond_clone);
	clone->copy_baseClass(this,message);
	return(clone);	
};
//------------------------------------------------------------------------
// CLASS PT_RLoop()
//------------------------------------------------------------------------
PT_RLoop::PT_RLoop(char *id, int lineno) 
		: PT_Loop(lineno)	// Constructor
{
	// use the left child as the expression, and the right child as the body.
	
	loopId = mallocName(id);
	minExpr = maxExpr = NULL;	// ranges are set later.

};

PT_RLoop::~PT_RLoop(void)		// destructor
{
	// the base destructor should delete the left and right children.
	if(loopId)
	{
		delete loopId;
		loopId = NULL;
	}
	if(loopInitStmt)
	{
		delete loopInitStmt;
		loopInitStmt = NULL;
	}
	if(loopIncStmt)
	{
		delete loopIncStmt;
		loopIncStmt = NULL;
	}
	if(loopCond)
	{
		delete loopCond;
		loopCond = NULL;
	}

};


void 
PT_RLoop::semanticCheck(void)
{
//	if(!leftChild || !rightChild)
//		Compiler_Error("Loop structure incorrectly formed!\n");
	
	SEMANTIC_CHECK_INIT();
	
	// explicitly declare a temp. id, and assign zero to it.
		
	// set up the loop initialization  (loopId := 0)
	PT_Lvalue *loopCounter = new PT_Lvalue(loopId,getSourceLineNum());
	loopInitStmt = new PTAssign(getSourceLineNum());
	loopInitStmt->linkChild(loopCounter,minExpr);
	
	
	// set up the loop incrementer	(loopId := loopId + 1)
	PTBinOptr *incr = new PTBinOptr(PLUS);

	// constants inserted into ST automatically.
	incValue = new PTConst(1,32);

	PT_Lvalue *lval = new PT_Lvalue(loopId,getSourceLineNum());
	PT_Rvalue *rval1 = new PT_Rvalue(loopId,getSourceLineNum());
	loopIncStmt = new PTAssign(getSourceLineNum());
	
	incr->linkChild(rval1,incValue);
	loopIncStmt->linkChild(lval,incr);
	
	// set up the loop condition.
	// while (loopId <= expr)  (for LOOP n TIMES (only))
	loopCond = new PTBinOptr(LTE,getSourceLineNum());	
	PT_Rvalue *rval2 = new PT_Rvalue(loopId,getSourceLineNum());
	loopCond->linkChild(rval2,maxExpr);		
	leftChild = NULL;
	loopCond = loopCond->cfold();
	
	// check the newly created explicit loop counter
	// (also inserts the new symbol into symbol table.	)
	loopInitStmt->semanticCheck();	
	setStepNum();										
	loopCond->semanticCheck();	

	// check the body of the loop
	// This must be done before the semantic checking for the loopInitStmt, 
	// loopCond and loopIncStmt.
	
	rightChild->semanticCheck();	
	setStepNum();		// set the step number for checking loopId
	
	// check that the loop incrementer is not altered 
	// inside the loop by the user. 
	STEntry *ste = SymTbl.lookup(loopId);
	if(ste->step_altered.inRange(getStepStartNum(),getStepEndNum()))
	{
		Error("Cannot alter loop counter '%s' in loop.\n",loopId);
	};
	
	loopIncStmt->semanticCheck();
	setStepNum();	// set this again for use in ::dataflow().
	
	if(nextStmt)
		nextStmt->semanticCheck();
	
};

void 
PT_RLoop::setExpr(PTNode *express)
{
	if(!minExpr)
	{
		minExpr = express;
	}

	else if(!maxExpr)
	{
		maxExpr = express;
	}
};

PTNode *
PT_RLoop::make_clone(int message)
{
	char *clone_name = mallocName(SymTbl.Inline.getPrefix(),loopId);
	PT_RLoop *clone = new PT_RLoop(clone_name,getSourceLineNum());
	delete clone_name;	// the PT_RLoop ctor should have copied this.
	clone->copy_baseClass(this,message);
	clone->setExpr(minExpr->make_clone());
	clone->setExpr(maxExpr->make_clone());
	return(clone);	
};


//------------------------------------------------------------------------
