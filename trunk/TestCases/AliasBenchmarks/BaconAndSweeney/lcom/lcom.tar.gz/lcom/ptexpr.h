
// FILE: PTEXPR.H - PARSE TREE EXPRESSIONS


#ifndef  PTEXPR_H
#define  PTEXPR_H

#include "tokens.h"
#include "boolean.h"
#include "dataflow.h"
#include "ptnode.h"
#include "symtable.h"

//-----------------------------------------------------------------------
// The following classes are defined in this file, in this order.
//
class PTIdent;
class PT_Lvalue;
class PT_Rvalue;
class PTConst;
class PTBinOptr;
class PTUnaryOptr;
class PT_Cond;

//-----------------------------------------------------------------------
class PTIdent : public PTNode
{
protected:
	char *name;
	STEntry *myste;

public:
	PTIdent(char *idname, int lineno);
	~PTIdent(void);
	char *getName(void);
	VIRTUAL void printMe(void);
//	DF_Entry *dataflow(int message = 0);
	VIRTUAL PTNode *make_clone(int message = 0);
	
	VIRTUAL boolean testProcArg(boolean readstat, boolean writestat);
};

//-----------------------------------------------------------------------
class PT_Lvalue : public PTIdent
{

public:
	PT_Lvalue(char *idname, int lineno);
	PT_Lvalue( PTIdent *id);
	~PT_Lvalue(void);
	VIRTUAL void printMe(void);
	VIRTUAL void semanticCheck(void);
	VIRTUAL DF_Entry *dataflow(int message = 0);
	VIRTUAL PTNode *make_clone(int message = 0);
};
//-----------------------------------------------------------------------
class PT_Rvalue : public PTIdent
{

public:
	PT_Rvalue(char *idname, int lineno);
	PT_Rvalue( PTIdent *id);
	~PT_Rvalue(void);
	VIRTUAL void printMe(void);
	VIRTUAL void semanticCheck(void);
	VIRTUAL DF_Entry *dataflow(int message = 0); 
	boolean isConstant(void);
	long getValue(void);
	long getPathWidth(void);
	VIRTUAL PTNode *make_clone(int message = 0);
	VIRTUAL PTNode *cfold(void);
};

//-----------------------------------------------------------------------
class PTConst : public PTNode
{
	long constantValue;
	int pathwidth;
	STEntry *myste;
	
public:
	PTConst(long value, int width, int lineno = 0);
//	PTConst(long value, int width = MAXPATHWIDTH, int lineno = 0);
//	~PTConst(void);
	VIRTUAL void printMe(void);
	long getValue(void);
	long getPathWidth(void);
	void resetValue(long value);
	VIRTUAL DF_Entry *dataflow(int message = 0); 
	VIRTUAL void semanticCheck(void);
	boolean isConstant(void)	{return(True);};
	VIRTUAL PTNode *make_clone(int message = 0);
	VIRTUAL boolean testProcArg(boolean readstat, boolean writestat);
};


//-----------------------------------------------------------------------

class PTBinOptr : public PTNode
{
	int operationToken;
	char *operationStr;
	PTNodePtr *args;
	int argcount;
	int argmax;
	DF_EntryPtr *df;
	
	boolean sortArgs(void);
	DF_Entry *foldArgs();
	boolean compressArgs(void);
	
	friend PTNode *buildBinaryExpr(PTNode *, int , PTNode *, int );

	
public:
	PTBinOptr(int optr, int lineno = 0);
	~PTBinOptr(void);
	VIRTUAL void printMe(void);
	VIRTUAL void dumpTree(void);
	VIRTUAL void semanticCheck(void);
	VIRTUAL DF_Entry* dataflow(int message = 0);
	PTNode *cfold(void);
	long getPathWidth(void);
//	DataType getDataType(DF_Entry *left, DF_Entry *right);
	DataType getDataType(void);
	VIRTUAL PTNode *make_clone(int message = 0);
	VIRTUAL boolean testProcArg(boolean readstat, boolean writestat);
	VIRTUAL void linkChild(PTNode *left, PTNode *right);
};

//-----------------------------------------------------------------------
class PTUnaryOptr : public PTNode
{
	int operationToken;
	char *operationStr;

public:
	PTUnaryOptr(int optr, int lineno = 0);
//	~PTUnaryOptr(void);
	VIRTUAL void printMe(void);
	PTNode *cfold(void);
	VIRTUAL DF_Entry* dataflow(int message = 0);
	VIRTUAL void semanticCheck(void);
	VIRTUAL void dumpTree(void);
	long getPathWidth(void);
	//DataType getDataType(void);
	VIRTUAL PTNode *make_clone(int message = 0);
	VIRTUAL boolean testProcArg(boolean readstat, boolean writestat);

};


//-----------------------------------------------------------------------
class PT_Cond : public PTNode	
{

	
public:
	PT_Cond(PTNode *expr);
	~PT_Cond(void);

	VIRTUAL void printMe(void);

	VIRTUAL void dumpTree(void);

	VIRTUAL DF_Entry *dataflow(int message = 0);
	VIRTUAL void semanticCheck(void);
	
	long getValue(void);
	long getPathWidth(void);
	PTNode *cfold(void);
	VIRTUAL PTNode *make_clone(int message = 0);
	VIRTUAL boolean testProcArg(boolean readstat, boolean writestat);
};

//-----------------------------------------------------------------------
#endif
