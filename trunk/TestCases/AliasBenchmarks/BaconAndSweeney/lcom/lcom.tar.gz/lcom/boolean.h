// FILE: BOOLEAN.H

#ifndef BOOLEAN_H
#define BOOLEAN_H


//enum  enumBoolean {False, True};
//typedef enum enumBoolean boolean;


#define False 0
#define True  1
#define boolean int

#endif

