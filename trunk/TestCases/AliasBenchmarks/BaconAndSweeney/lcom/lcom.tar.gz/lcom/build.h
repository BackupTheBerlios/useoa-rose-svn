// FILE: build.h


#ifndef BUILD_H
#define BUILD_H

#include "ptnode.h"
#include "ptexpr.h"


long rol(long x, long pathwidth, long count = 1);
long ror(long x, long pathwidth, long count = 1);

boolean testShiftOperands(long lpathw, long rval, long lineno);


PTNode *buildBinaryExpr(PTNode *lexpr, int opToken, PTNode *rexpr, int lineno);

PTNode *buildUnaryExpr(PTNode *expr, int opToken, int lineno);

// void constantFold(PTNode **node); // this is now obsolete

PTConst *
evalConstUnary(PTNode *left, int operationToken, long lineno = 0);

PTConst *
evalConstBinary(PTNode *left, PTNode *right, int opToken, long lineno = 0);

DF_Entry *
evalConstUnary(DF_Entry *left, int operationToken, long lineno = 0);

DF_Entry *
evalConstBinary(DF_Entry *left, DF_Entry *right, int opToken, long lineno = 0);

//DF_Entry *
//evalAlgebraicIdentity(DF_Entry *left, DF_Entry *r, int opToken, long lineno = 0);

boolean isAssociativeOptr(int opToken);
boolean isCommutativeOptr(int opToken);
#define isCommAssocOptr(opToken) \
	(isAssociativeOptr(opToken) && isCommutativeOptr(opToken))

#endif /* BUILD_H */
