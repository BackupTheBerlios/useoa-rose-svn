// FILE: StringSet.c
// Based on Set classes used in GNU class libraries.

#include "lconfig.h"
#include "sets.h"
#include <stdio.h>

#ifndef __GNUC__
#include <string.h>
#endif

#define Compiler_Error printf

#ifndef lint
static char *sccsid = "@(#)sets.C	1.4 (University of Guelph, VLSI Dept., T. Ponzo) 93/10/04";
#endif /* lint */



//**************************************************************************
// Class IntSet
//**************************************************************************
IntSet::IntSet(int chunksize) 
{ 
	count = 0;
	maxsize = chunksize;
	ptr = new int[maxsize];
	if(!ptr)
		Compiler_Error("Cannot allocate enough memory for IntSet(%d)\n",maxsize);
};


IntSet::IntSet(const IntSet& s)
{ 
	maxsize = count = s.count; 
	ptr = new int[maxsize];
	if(!ptr)
		Compiler_Error("Cannot allocate enough memory for IntSet(%d)\n",maxsize);	
	for(int i = 0; i<count; i++)
		ptr[i] = s.ptr[i];
		
	
};

IntSet::~IntSet(void)		// destructor
{
	delete ptr;
};


int& 
IntSet::operator ()(int   idx)
{
  return ptr[idx-1];
}

void 
IntSet::clear(void)
{
	count = 0;
};


int 
IntSet::contains (int  item)
{
	return( (seek(item)) ? 1 : 0);
	
};

int 
IntSet::operator != (IntSet& b)
{
	if(count != b.count)
		return(0);
	for(int i = 0; i<count; i++)
	{
		if(ptr[i] != b.ptr[i])
			return(0);
	}
	
  return(1);
}

// return 0 if equal;
// return -1 if item1 < item2
// return +1 if item1 > item2
	
int 
IntSet::compare(int item1, int item2)
{
	return(item1 - item2);
};


int 
IntSet::seek(int item)
{
	if(count == 0)
		return(0);
	
	int l = 0;
	int h = count-1;
	while (l <= h)
	{
		int mid = (l + h) / 2;
		int cmp = compare(item, ptr[mid]);
		if(cmp == 0)
			return(mid+1);
		else if(cmp < 0)
			h = mid - 1;
		else
			l = mid + 1;
	}
	return(0); 	// item is not in the set.

};

int 
IntSet::add(int  item)
{
	if(count == 0)				// if this is the first, easy to add.
	{
		ptr[count++] = item;
		return(count);
	}
		
	int idx = seek(item);	// if the item already exists, do not add it again.
	if(idx != 0)
		return(idx);
	
	// if there is not enough room for the new item, expand the array size
	if(count == maxsize)
	{
		maxsize += CHUNKSIZE;

		int *temp_ptr = new int [maxsize];
		if(!temp_ptr)
			Compiler_Error("Not enough memory for IntSet::add()\n");
			
		for (int z = 0; z < count; z++)
			temp_ptr[z] = ptr[z];
		delete ptr;
		ptr = temp_ptr;
	}

	int insert_pos;
	
	if(item < ptr[0])		// test the beginning of the list
	{
		insert_pos = 0;
	}
	else if(item > ptr[count - 1])	// test the end of the list
	{
		insert_pos = count;
	}
	else	// must go into the middle.
	{
		// locate the smallest number that is larger than the new item.
		// This is the position in which to insert the new item. If this
		// smallest number was not found, then the new item must be added to
		// the end.
	
		int l = 0;
		int h = count - 1;
	
		while (l < h)
		{
			int mid = (l + h) / 2;
			int cmp = compare(item, ptr[mid]);
			if (cmp < 0)
				h = mid;
			else
				l = mid + 1;
		}/* end while */
	
		insert_pos = l;
	
		
	} /* end else */
	
	// move all items greater than this item up one position.
	for(int j = count; j > insert_pos; j--)
		ptr[j] = ptr[j-1];
		
	ptr[insert_pos] = item;
	++count;
	return(insert_pos + 1);
	
}

void 
IntSet::del(int  item)
{
	int del_pos = seek(item);
	if(del_pos == 0)
		return;
	del_pos -= 1;

	count --;
	
	for(int i = del_pos; i<count; i++)
	{
		ptr[i] = ptr[i+1];
	}
	
	
}


// return true if a is a subset of b
// ie, everything in a is located in b.

int 
IntSet::operator <= (IntSet& b)
{
	if(count > b.count)
		return(0);
		
	for(int i = 0; i<count; i++)
	{
		if(!b.contains(ptr[i]))
			return(0);
	}
	return(1);
}

int 
IntSet::operator == (IntSet& b)
{
	if(count != b.count)
		return(0);
	for (int i=0; i<count; i++)
	{
		if(ptr[i] != b.ptr[i])
			return(0);
	}
	return(1);
}

// adds all elements of b to a.

void 
IntSet::operator |= (IntSet& b)
{
	if (&b == this || b.count == 0)
		return;
	else 
	{
		for(int i = 0; i<b.count; i++)
		{
			add(b.ptr[i]);
		}
	}
	return;	
}

// delete all items of b from a.

void 
IntSet::operator -= (IntSet& b)
{
	if (&b == this)
		clear();
	else
	{
		for(int i=0; i<b.count; i++)
		{
			del(b.ptr[i]);
		}
	}
}

// delete all elements of a not occurring in b.

void 
IntSet::operator &= (IntSet& b)
{
	if (b.count == 0)
		clear();
	else if (&b != this && count != 0)
	{
		for(int i = count - 1; i >= 0; i--)
		{	
			if(b.contains(ptr[i]))
				del(ptr[i]);
		}
	}
};

// return the number of elements in the set that are found
// in the range min_item to max_item, inclusive.

int 
IntSet::rangeCount(int min_item, int max_item)
{
	int range_count = 0;
	for(int i =0; i<count; i++)
	{
		int item = ptr[i];
		if(item >= min_item && item <= max_item)
			range_count++;
	}
	return(range_count);

};	
   




//**************************************************************************
// Class StringSet
//**************************************************************************


typedef char* charptr;

StringSet::StringSet(int chunksize) 
{ 
	count = 0;
	maxsize = chunksize;
	ptr = new charptr[maxsize];
	if(!ptr)
		Compiler_Error("Cannot allocate enough memory for StringSet(%d)\n",maxsize);
};


StringSet::StringSet(const StringSet& s)
{ 
	maxsize = count = s.count; 
	ptr = new charptr[maxsize];
	if(!ptr)
		Compiler_Error("Cannot allocate enough memory for StringSet(%d)\n",maxsize);	
	for(int i = 0; i<count; i++)
	{
		char *str = s.ptr[i];
		int len = strlen(str);
		char *temp = new char[len+1];
		if(!temp)
			Compiler_Error("Unable to allocate memory in StringSet constructor.\n");
		strcpy(temp,str);
		ptr[i] = temp;
	}
	
};

StringSet::~StringSet(void)		// destructor
{
	for(int i = 0; i < count; i++)
		delete ptr[i];						// delete the string

	delete ptr;								// delete the array of string pointers
};

char *
StringSet::operator ()(int idx)
{
  return ptr[idx-1];
};

void 
StringSet::clear(void)
{
	for(int i = 0; i < count; i++)
		delete ptr[i];
		
	count = 0;
};

int 
StringSet::contains (const char *item)
{
	return( (seek(item)) ? 1 : 0);
	
};

int 
StringSet::operator != (StringSet& b)
{
	if(count != b.count)
		return(0);
	for(int i = 0; i<count; i++)
	{
		if(strcmp(ptr[i],b.ptr[i]) != 0)
			return(0);
	}
	
  return(1);
}

// return 0 if equal;
// return -1 if item1 < item2
// return +1 if item1 > item2
	
int 
StringSet::compare(const char *item1, const char *item2)
{
	return(strcmp(item1,item2));
};


int 
StringSet::seek(const char *item)
{
	if(count == 0)
		return(0);
	
	int l = 0;
	int h = count-1;
	while (l <= h)
	{
		int mid = (l + h) / 2;
		int cmp = compare(item, ptr[mid]);
		if(cmp == 0)
			return(mid+1);
		else if(cmp < 0)	// str1 < str2
			h = mid - 1;
		else					// str1 > str2
			l = mid + 1;
	}
	return(0); 	// item is not in the set.

};

int 
StringSet::add(const char *item)
{
	if(count == 0)				// if this is the first, easy to add.
	{
		char *str = new char[strlen(item) + 1];
		strcpy(str,item);
		ptr[count++] = str;
		return(count);
	}
		
	int idx = seek(item);	// if the item already exists, do not add it again.
	if(idx != 0)
		return(idx);
	
	// if there is not enough room for the new item, expand the array size
	if(count == maxsize)
	{
		maxsize += CHUNKSIZE;

		char **temp_ptr = new charptr[maxsize];
		if(!temp_ptr)
			Compiler_Error("Not enough memory for StringSet::add()\n");
			
		for (int z = 0; z < count; z++)
			temp_ptr[z] = ptr[z];
		delete ptr;
		ptr = temp_ptr;
	}

	// locate the smallest string that is larger than the new item.
	// This is the position in which to insert the new item. If this
	// smallest string was not found, then the new item must be added to
	// the end.
	
	int l = 0;
	int h = count - 1;
	int insert_pos;
		
	if(compare(item,ptr[0]) < 0)		// test for beginning of the list
	{
		insert_pos = 0;
		
	}
	else if(compare(item,ptr[h]) > 0)	// test for end of the list
	{
		insert_pos = count;
	}
	else											// must be somewhere in the middle
	{
		while (l < h)
		{
			int mid = (l + h) / 2;
			int cmp = compare(item, ptr[mid]);
			if (cmp < 0)
				h = mid;
			else
				l = mid + 1;
				
		}/* end while */
	
		insert_pos = l;
	}
	
	// move all items greater than this item up one position.
	for(int j = count; j > insert_pos; j--)
		ptr[j] = ptr[j-1];

	// make sure to allocate a copy of the string before assigning it.	
	char *tempstr = new char[strlen(item) + 1];
	strcpy(tempstr,item);	
	ptr[insert_pos] = tempstr;
	++count;
	return(insert_pos + 1);
		
	
}

void 
StringSet::del(const char *item)
{
	int del_pos = seek(item);
	if(del_pos == 0)
		return;
	del_pos -= 1;

	delete ptr[del_pos];
	
	count --;
	
	for(int i = del_pos; i<count; i++)
	{
		ptr[i] = ptr[i+1];
	}
	
	
}


// return true if a is a subset of b
// ie, everything in a is located in b.

int 
StringSet::operator <= (StringSet& b)
{
	if(count > b.count)
		return(0);
		
	for(int i = 0; i<count; i++)
	{
		if(!b.contains(ptr[i]))
			return(0);
	}
	return(1);
}

int 
StringSet::operator == (StringSet& b)
{
	if(count != b.count)
		return(0);
	for (int i=0; i<count; i++)
	{
		if(strcmp(ptr[i],b.ptr[i]) != 0)
			return(0);
	}
	return(1);
}

// adds all elements of b to a.

void 
StringSet::operator |= (StringSet& b)
{
	if (&b == this || b.count == 0)
		return;
	else 
	{
		for(int i = 0; i<b.count; i++)
		{
			add(b.ptr[i]);
		}
	}
	return;	
}

// delete all items of b from a.

void 
StringSet::operator -= (StringSet& b)
{
	if (&b == this)
		clear();
	else
	{
		for(int i=0; i<b.count; i++)
		{
			del(b.ptr[i]);
		}
	}
}

// delete all elements of a not occurring in b.

void 
StringSet::operator &= (StringSet& b)
{
	if (b.count == 0)
		clear();
	else if (&b != this && count != 0)
	{
		for(int i = count - 1; i >= 0; i--)
		{	
			if(b.contains(ptr[i]))
				del(ptr[i]);
		}
	}
};

   
