
// FILE: blkentry.h

#ifndef BLKENTRY_H
#define BLKENTRY_H

#include "list.h"
#include "utils.h"

class BlockEntry;
typedef BlockEntry*     BlockEntryPtr;

// Block Types
enum enumBlockType { Block_ctrl, Block_data, Block_seq};
typedef enum enumBlockType  BlockType;

class DataFlowGraph;
class STEntry; // defined in file symtable.h, but needed for forwarding.

#include "virtual.h"

/*****************************************************************************/
// Class BlockEntry
/*****************************************************************************/

class BlockEntry 
{

protected:

   BlockType blocktype; 
   BlockEntry *parentBlock;
   BlockEntry *predBlock;
   int index;
   DataFlowGraph *dfg;
   char *headerId;
   List mylist;
   MagicNumber magic;
   
   boolean resolvedFlag;
   friend class DataFlowGraph;
   void printHeader(void);
   
	boolean fixedTimeFlagKnown;
	boolean fixedTimeFlag; 
	
private:
   int tempindex;

   
public:
   BlockEntry(BlockType bt);
   virtual ~BlockEntry(void);
   
   virtual void print(void);
   void resolveIndices(void); 
   
         
   
   void           addTo(DF_Entry *x);
   BlockType      getBlockType(void);
   
   void           setParentBlock(BlockEntry *b);
   void           setPredBlock(BlockEntry *b);
   BlockEntry     *getParentBlock(void);
   BlockEntry     *getPredBlock(void);
   
   boolean        empty(void);
   unsigned long  length(void);
   int            getIndex(void);
   DF_Entry   *getFirstEntry(void);
   DF_Entry    *getLastEntry(void);
   DF_Entry   *getNextEntry(void);

   virtual BlockEntry      *getParentBlockChained(void);
   virtual BlockEntry      *getPredBlockChained(void);
   
   virtual boolean isUsable(void);
   virtual DF_Entry *block_trace(STEntry *target_dfste, boolean searchPred = True);
   virtual DF_Entry *commSubExpr(DF_Entry *df, boolean localBlock, boolean searchPred = True);
   virtual void pruneDeadCode(void);
   virtual boolean fixedTimeExecution(void);
   virtual void insertEntryBefore(DF_Entry *entry1, DF_Entry *entry2);
};

/*****************************************************************************/
// Class SBlkEntry
/*****************************************************************************/

class SBlkEntry : public BlockEntry
{
   
public:
   SBlkEntry(void);
   ~SBlkEntry(void);
   
// DF_Entry *block_trace(STEntry *target_dfste);
   boolean isUsable(void);
   BlockEntry     *getParentBlockChained(void);
   BlockEntry     *getPredBlockChained(void);
   virtual void print(void);
   virtual void resolveIndices(void);
   VIRTUAL boolean fixedTimeExecution(void);
};

/*****************************************************************************/
// Class DBlkEntry
/*****************************************************************************/

class DBlkEntry : public BlockEntry
{
   
public:
   DBlkEntry(void);
   ~DBlkEntry(void);
   
// DF_Entry *block_trace(STEntry *target_dfste);
   BlockEntry     *getParentBlockChained(void);
   BlockEntry     *getPredBlockChained(void);
	VIRTUAL void pruneDeadCode(void);
};

/*****************************************************************************/
// Class CBlkEntry
/*****************************************************************************/

class CBlkEntry : public BlockEntry
{
   
public:
   CBlkEntry(void);
   ~CBlkEntry(void);
   
   BlockEntry     *getParentBlockChained(void);
   BlockEntry     *getPredBlockChained(void);
};



#endif /* BLKENTRY_H */
