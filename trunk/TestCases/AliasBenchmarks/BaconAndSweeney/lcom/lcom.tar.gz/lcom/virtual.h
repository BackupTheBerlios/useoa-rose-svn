// FILE: virtual.h

#ifndef VIRTUAL_H
#define VIRTUAL_H

#ifdef __GNUC__
#define VIRTUAL virtual
#else
#define VIRTUAL 
#endif

#endif /* VIRTUAL_H */


