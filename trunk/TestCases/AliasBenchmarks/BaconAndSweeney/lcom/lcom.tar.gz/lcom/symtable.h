// FILE: SYMTABLE.H

#ifndef SYMTABLE_H
#define SYMTABLE_H

#include "boolean.h"
#include "dataflow.h"
#include "utils.h"
#include "ptnode.h"
#include "sets.h"

//---------------------------------------------------------------------------	
class Parameter
{
	int p_in;
	int p_out;
	int p_index;
	boolean p_is_a_param;
	Parameter(void);	// constructor (make sure only a STEntry can create this)
	friend class STEntry;
	
public:
	void setIndex(int index, int in_index, int out_index);
	int getIndex(int &index, int &in, int &out);
	int getIndex(void);
	void setIsParameter(boolean tf);
	boolean isParameter(void);
	
};

//---------------------------------------------------------------------------	
class StepCheck
{
	IntSet num;
	StepCheck(void);	// constructor	(make sure only a STEntry can create this)
	friend class STEntry;
	
public:
	void setNum(int stepnum);
	boolean inRange(int minstep, int maxstep = MAXINT);
	boolean empty(void);
};

//---------------------------------------------------------------------------	
// The purpose of copy propogation is to keep track of when the contents
// of a variable are known. 
// For example, if A is assigned a value 5, and then later, A is used
// in an expression, as in B := A * 2, then we can use the fact that 
// we know that A has the value 5, and we can constant fold the statement
// into B := 10;
// - The same notion can be indirected one or more levels, ie,
//		A := 5;
//		B := A;
//		C := B * 3;	/* can be folded to C := 15; */

//---------------------------------------------------------------------------	
#define MAX_SCOPE_DEPTH 10

class STEntry : public DF_Entry
{
	STEntry *next;
	STEntry *prev;
	int hashval;	// the hash value for this symbol.
							// Used to make deletions thru crossLinks easy,
							// since we know which bucket this belongs to.
	char *id;
	int token;
	int scope;
	boolean undefined;
	boolean constantNow;
	boolean printFlag;
	
	
	DataType datatype;
	PtreeNodeType symbolType;
	boolean isConst;
	int pathwidth;
	long constantValue;
	
	boolean readaccess, writeaccess;
	PTNode *ptnode;
	DF_Entry *lastVersion;
	friend class SymbolTable;
	
public:
	STEntry(char *name);
	STEntry(long constant, int pathwidth, char *name = NULL);
	~STEntry(void);
	
	void setSymbolType(PtreeNodeType symtype);
	PtreeNodeType getSymbolType(void);
	
	void setPTNode(PTNode *p);
	PTNode *getPTNode(void);

	char *getName(void)		{return(id);};
	void print(void);
	void resolveIndices(void);
	
	int getToken(void)		{return(token);};
	void setToken(int tok)	{ token = tok; };
	
	int getScope(void)		{return(scope);};
	void setScope(int newscope)	{scope = newscope;};

	void setNext(STEntry *nextEntry){next = nextEntry;};
	STEntry *getNext(void)		{return(next);};
	
	boolean isUndefined(void)	{return(undefined);}
	
	DataType getDataType(void);
	void setDataType( DataType dt);
	
	VIRTUAL boolean isConstant(void);
	long getConstantValue(void);
	void setConstantValue(long cv);
	
	int getPathWidth(void);
	void setPathWidth(int pw);
	
	char *getModeStr(void);
	boolean isWriteable(void);
	void setModeAccess(boolean readable, boolean writeable);
	
	Parameter param;
	//Copy_Propogation copyProp;
	VIRTUAL void pruneDeadCode(void);
	
	VIRTUAL boolean isDefinitelySet(boolean printFlag = True);
	
	//struct
	//{
		StepCheck step_altered;
		// A symbol has been 'altered' if it is on the left side of an assignment
		// stmt or an OUT parameter from a procedure call.
	
		StepCheck step_accessed;
		// A symbol is 'accessed' if it is actually used in the DFTs.
		// ie, the programmer used the symbol, and it was not constant folded out.
	
		StepCheck step_used;
		// A symbol has been `used' if it appears in the HLL program.
		// It may end up being constant folded out, so it might never
		// actually be accessed, and therefore not be printed out
		// in the .STBL;
		
	//} step;	

	VIRTUAL DF_Entry *copyPropogate(void);
	
	void setLastVersion(DF_Entry *opnd);
	DF_Entry *getLastVersion(void);
	VIRTUAL DF_Entry *getRealSource(void);
};

//-------------------------------------------------------------------------
class ST_InLine
{
	int next_scope;
	int curr_scope;
	char prefix[20];
	ST_InLine(void);	// constructor (only a SymbolTable can create this object)
	friend class SymbolTable;
	
public:
	int getScope(void);
	void setScope(int other_scope);
	int incScope(void);
	char *getPrefix(void);
	void reset(void);
	
};
//-------------------------------------------------------------------------
#define DEFAULTTABLESIZE 211

typedef STEntry* STEptr;

class SymbolTable 
{
	STEntry *next_ste_in_crosslink;
	int next_ste_currentScope;	
	
	int *counts;						// array of counters (one for each entry)
	int currentScope;
	unsigned hashTableSize;				
	boolean keepStatistics;
	long entryCount;
	
	STEptr *hashBuckets;
	List crossLink[MAX_SCOPE_DEPTH];

public:

	SymbolTable(void);
	~SymbolTable(void);
	
	void initialize(int tableSize = DEFAULTTABLESIZE, boolean keepStats = True);
	
	unsigned getHashValue(char *name);			// hash function on name
	unsigned getHashValue(long constantval);	// hash function on a constant

	List *getCurrentCrossLink(void);
	int getPrintCount(void);	// how many symbols will be printed in the .STBL

	STEntry *insertProc(char *name);	// insert procedures and functions.
	STEntry *insert(char *name);		// insert everything else
	STEntry *lookupProc(char *name);
	STEntry *lookup(char *name);
	
	STEntry *insert(long constval, int pathwidth, char *name = NULL);
	STEntry *lookup(long constval, int pathwidth);
	
	int incScope(void);
	int decScope(void); 
	inline int getScope(void)  {return(currentScope);};
	void deleteScope(int dscope);
	void deleteCurrentScope(void);
	void incStatistics(unsigned hashValue);		
		
	void dump(int scope);
	void dumpAll(void);

	void dumpStats(void);		// display statistical information
	void start_Lvalue_List(void);
	STEntry *get_Next_Lvalue(void);
	
	//void resetCopyPropInRange(int step1, int step2);
	
	ST_InLine Inline;

};

#endif

