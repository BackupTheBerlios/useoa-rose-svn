// FILE: blkentry.c

#include "lconfig.h"
#include <stdio.h>
#include <stdlib.h>
#include "errors.h"
//#include "globals.h"
//#include "blkentry.h"
#include "dfentry.h"
#include "virtual.h"
#include "dataflow.h"
#include "symtable.h"
#include "blkentry.h"
#include "globals.h"

#ifndef lint
static char *sccsid = "@(#)blkentry.C	1.8 (University of Guelph, VLSI Dept.) 93/06/09";
#endif /* lint */

extern DataFlowGraph *CurrentDFG;

class DF_Entry;

/******************************************************************************/
// Class BlockEntry
// 
// declarations:
//		List mylist;
/******************************************************************************/

	
BlockEntry::BlockEntry(BlockType bt) 
{
	blocktype = bt;
	parentBlock = NULL;
	predBlock = NULL;
	dfg = CurrentDFG;
	index = -1;
	static int tempindexcount = 1;
	tempindex = tempindexcount++;
	resolvedFlag = False;	
	headerId = "BLK!!!";	// this string is never actually used.
	
	fixedTimeFlagKnown = False;	// we do not yet know if it is fixed time
	// fixedTimeFlag = True;
};

BlockEntry::~BlockEntry(void)
{
	DF_Entry *z;
	while(z = (DF_Entry *)mylist.remove_front())
	{
		delete z;	// delete the CtrlEntry, or OpndEntry, or OptrEntry, ...
	}
};

boolean
BlockEntry::empty(void)
{
	return (mylist.empty());
};

unsigned long
BlockEntry::length(void)
{
	return( mylist.length() );
};

int
BlockEntry::getIndex(void)
{
	if(index == (-1))
		index = dfg->blockIndex.nextIndex();
	
	return(index);
};

void 
BlockEntry::addTo(DF_Entry *x)
{
	mylist.append(x);
};

void 
BlockEntry::print(void)
{
	if( isUsable() )
	{	
		printHeader();
		DF_Entry *x;
		for(x = (DF_Entry *)mylist.front(); x; x = (DF_Entry *)mylist.succ())
		{
			x->print();
		}
	
		Outfile->print(".ENDBLK\n\n");
	}
	
};

void
BlockEntry::resolveIndices(void)
{
	if(!resolvedFlag)
	{
		
		if( isUsable() )
		{	
			DF_Entry *x;
			for(x = (DF_Entry *)mylist.front(); x; x = (DF_Entry *)mylist.succ())
			{
				x->resolveIndices();
			}
	
		}
	
		resolvedFlag = True;
	}

};

BlockType
BlockEntry::getBlockType(void)
{
	return blocktype;
};

BlockEntry *
BlockEntry::getParentBlock(void)
{
	return( parentBlock );
};

void
BlockEntry::setParentBlock(BlockEntry *b)
{
	parentBlock = b;
};


BlockEntry *
BlockEntry::getPredBlock(void)
{
	return( predBlock );
};


void
BlockEntry::setPredBlock(BlockEntry *b)
{
	predBlock = b;
};

boolean
BlockEntry::isUsable(void)
{
	return( ! empty() );
};


DF_Entry *
BlockEntry::block_trace(STEntry *target_dfste, boolean searchPred)
{
	DF_Entry *x = (DF_Entry *)mylist.rear();
	while(x)
	{
		DF_Entry *y = x->block_trace(target_dfste);
		if(y)
		{
			return(y);
		}
		
		x = (DF_Entry *)mylist.pred();
	}
	// if not found in this block, so try the predecessor block.
	if(predBlock && searchPred)
		return( predBlock->block_trace(target_dfste) );
	else
		//return( dfg->DFST_trace(target_dfste) );
		return(target_dfste);
};

VIRTUAL DF_Entry *
BlockEntry::commSubExpr(DF_Entry *df, boolean localBlock, boolean searchPred)
{
	DF_Entry *x = (DF_Entry *)mylist.rear();
	while(x)
	{
		DF_Entry *y = x->commSubExpr(df, localBlock);
		if(y)
		{
			return(y);
		}
		
		x = (DF_Entry *)mylist.pred();
	}
	// if not found in this block, so try the predecessor block.
	if(predBlock && searchPred)
	{
		// set localBlock to False for the next block.
		return( predBlock->commSubExpr(df,False,searchPred) );
	}
	else
	{
		return(NULL);
	}

};

VIRTUAL void
BlockEntry::pruneDeadCode(void)
{
	DF_Entry *x = (DF_Entry *)mylist.rear();
	while(x)
	{
		x->pruneDeadCode();
		x = (DF_Entry *)mylist.pred();
	}
};

void
BlockEntry::printHeader(void)
{

//	Outfile->newline();
	int myindex = this->getIndex();
	
	if(CLFlags.Debug)
		Outfile->print("%s %d ##%d\n", headerId, myindex,tempindex);
	else
		Outfile->print("%s %d\n", headerId, myindex);
	
	int predblockno = 0;	// assume 0 for now.
	if(predBlock)
	{
		if(predBlock->isUsable())
			predblockno = predBlock->getIndex();
		else
		{
			BlockEntry *b = predBlock->getPredBlockChained();
			if(b)
				predblockno = b->getIndex();
			else
				predblockno = 0;
		}
	}
		
	Outfile->print(".PRED %d\n", predblockno);
	
	int parentblockno = 0;	// assume 0 for now.
	if(parentBlock)
	{
		if(parentBlock->isUsable())
			parentblockno = parentBlock->getIndex();
		else
		{
			BlockEntry *b = parentBlock->getParentBlockChained();
			if(b)
				parentblockno = b->getIndex();
			else
				parentblockno = 0;
		}
	}
	Outfile->print(".PRNT %d\n", parentblockno);
	
};
DF_Entry *
BlockEntry::getFirstEntry(void)
{
	return( (DF_Entry *)mylist.front() );
};

DF_Entry *
BlockEntry::getLastEntry(void)
{
	return( (DF_Entry *)mylist.rear() );
};

DF_Entry *
BlockEntry::getNextEntry(void)
{
	return( (DF_Entry *)mylist.succ() );
};

BlockEntry *
BlockEntry::getParentBlockChained(void)
{
	Compiler_Error("Invalid call: virtual ",
						"BlockEntry::getParentBlockChained(void)\n");
	return(NULL);
};

BlockEntry *
BlockEntry::getPredBlockChained(void)
{
	Compiler_Error("Invalid call: virtual ",
						"BlockEntry::getPredBlockChained(void)\n");
	return(NULL);
};

boolean
BlockEntry::fixedTimeExecution(void)
{
	if(fixedTimeFlagKnown == False) // if we do not know, test it!
	{
		DF_Entry *x = (DF_Entry *)mylist.front(); 
		fixedTimeFlag = True;		// assume true until proven false.
		
		while(x && (fixedTimeFlag == True))
		{
			fixedTimeFlag = x->fixedTimeExecution();	
			x = (DF_Entry *)mylist.succ();
		}
		fixedTimeFlagKnown = True;	// now we know for sure.	
	}
	return(fixedTimeFlag);



};

// look thru the list for entry2, and insert entry1 just before it.
VIRTUAL void 
BlockEntry::insertEntryBefore(DF_Entry *entry1, DF_Entry *entry2)
{
	boolean found = False;
	DF_Entry *currentNode = (DF_Entry *)mylist.front();
	while(currentNode && (found == False))
	{
		if(currentNode == entry2)
		{
			mylist.ins_before(entry1);
			found = True;
		}
		else
		{
			currentNode = (DF_Entry *)mylist.succ();
		}
	};

	if(found == False)
	{
		Compiler_Error("%s. Cannot find entry (0x%x)\n",
			"BlockEntry::insertEntryBefore()",(void *)entry2);
	}


};

/******************************************************************************/
// Class SBlkEntry
// 
// declarations:
//		List mylist;
/******************************************************************************/

// Block Types
//enum enumBlockType { Block_ctrl, Block_data, Block_seq};
//typedef enum enumBlockType  BlockType;

	
SBlkEntry::SBlkEntry(void) : BlockEntry(Block_seq)
{
//	headerId = ".SBLK";
	headerId = ".CBLK";
};

SBlkEntry::~SBlkEntry(void) 
{
	/* do nothing */
};

boolean
SBlkEntry::isUsable(void)
{
	int count = 0;
	
	CtrlEntry *x; 
	for(x = (CtrlEntry *)mylist.front(); x; x = (CtrlEntry *)mylist.succ() )
	{
		if(x->isUsable())
			count++;
	}
	
	boolean result = False;
	if(count >= 2)
		result = True;
	else if(count == 1)
		result = False;
	else
		Compiler_Error("SBLK should have atleast one usable entry (?)\n");	
	return(result);
};

void
SBlkEntry::print(void)
{
	if( isUsable() )
	{	
		printHeader();
		int count = 0;
		CtrlEntry *x; 	// only control entries should be in this list.
		for(x = (CtrlEntry *)mylist.front(); x; x = (CtrlEntry *)mylist.succ())
		{
			if(x->isUsable())
			{
				count++;
			}
		
		}
	
		// print either .SEQ or .LSEQ (if all blocks have a fixed time);
		boolean fixedTime = False;	// assume it is false
		
		// test the command line switch first!
		if(CLFlags.LogicSequential == True)
		{
			fixedTime = fixedTimeExecution();	
		}
		Outfile->print("%s %d",(fixedTime ? ".LSEQ" : ".SEQ"), count);
		
		for(x = (CtrlEntry *)mylist.front(); x; x = (CtrlEntry *)mylist.succ())
		{
			x->print();	// print the CtrlEntry.
		}
		Outfile->newline();
	
		Outfile->print(".ENDBLK\n\n");
	}
};

void
SBlkEntry::resolveIndices(void)
{
	if(!resolvedFlag)
	{
		
		if( isUsable() )
		{	
			DF_Entry *x;
			for(x = (DF_Entry *)mylist.front(); x; x = (DF_Entry *)mylist.succ())
			{
				x->resolveIndices();
			}
	
		}
	
		resolvedFlag = True;
	}

};


BlockEntry *
SBlkEntry::getParentBlockChained(void)
{
	if(isUsable())
		Compiler_Error("Call to SBlkEntry::getParentBlockChained() ",
							"of valid entry.\n");

	if(parentBlock)
	{
		if (parentBlock->isUsable() )
			return(parentBlock);
		else
			return(parentBlock->getParentBlockChained());
	}
	else
		return(NULL);


};

BlockEntry *
SBlkEntry::getPredBlockChained(void)
{
	Compiler_Error("An SBlk should never be a predecessor to any block!\n");
	return(NULL);
};

boolean
SBlkEntry::fixedTimeExecution(void)
{
	if(fixedTimeFlagKnown == False) // if we do not know, test it!
	{
		CtrlEntry *x = (CtrlEntry *)mylist.front(); 
		fixedTimeFlag = True;		// assume true until proven false.
		
		while(x && (fixedTimeFlag == True))
		{
			fixedTimeFlag = x->fixedTimeExecution();	
			x = (CtrlEntry *)mylist.succ();
		}
		fixedTimeFlagKnown = True;	// now we know for sure.	
	}
	return(fixedTimeFlag);

};
/******************************************************************************/
// Class DBlkEntry
/******************************************************************************/

	
DBlkEntry::DBlkEntry(void) : BlockEntry(Block_data)
{	
	headerId = ".DBLK";
};

DBlkEntry::~DBlkEntry(void) 
{
	/* do nothing */
};


BlockEntry *
DBlkEntry::getParentBlockChained(void)
{
	Compiler_Error("A DBlk should never be a parent.\n");
	return(NULL);
};

BlockEntry *
DBlkEntry::getPredBlockChained(void)
{
	if(isUsable())
		Compiler_Error("Invalid call to DBlkEntry::getPredBlockChained(void)\n");
	
	if(predBlock)
	{
		if(predBlock->isUsable())
			return(predBlock->getPredBlock());
		else
			return( predBlock->getPredBlockChained() );
	}
	else
		return(NULL);


};

// All the entries in a data block have already been pruned from
// tracing OUT parameters.
// So, just return from here!
VIRTUAL void
DBlkEntry::pruneDeadCode(void)
{
	return;
};


/******************************************************************************/
// Class CBlkEntry
/******************************************************************************/

	
CBlkEntry::CBlkEntry(void) : BlockEntry(Block_ctrl)
{	
	headerId = ".CBLK";
};

CBlkEntry::~CBlkEntry(void) 
{
	/* do nothing */
};


BlockEntry *
CBlkEntry::getParentBlockChained(void)
{
	if( isUsable() ) 
		Compiler_Error("Call to CBlkEntry::getParentBlockChained() ",
							"of valid entry.\n");
		
	if(parentBlock)
	{
		if (parentBlock->isUsable() )
			return(parentBlock->getParentBlock());
		else
			return(parentBlock->getParentBlockChained());
	}
	else
		return(NULL);
};

BlockEntry *
CBlkEntry::getPredBlockChained(void)
{
	if(isUsable())
		Compiler_Error("Invalid call to CBlkEntry::getPredBlockChained(void)\n");
	
	if(predBlock)
	{
		if(predBlock->isUsable())
			return(predBlock->getPredBlock());
		else
			return( predBlock->getPredBlockChained() );
	}
	else
		return(NULL);

};



/******************************************************************************/
