// FILE: PTLOOP.H

#ifndef PTLOOP_H
#define PTLOOP_H

#include "ptnode.h"
#include "ptexpr.h"

class PT_Loop;
class PT_NLoop;
class PT_WLoop;
class PT_RLoop;


//-------------------------------------------------------------------------
class PT_Loop : public PTNode
{
protected:

	char *loopId;
	PTAssign *loopInitStmt;
	PTAssign *loopIncStmt;
	PTNode  *loopCond;
	unsigned endStmtNum;
	
public:
	PT_Loop(int lineno);
	~PT_Loop(void);
	virtual void setExpr(PTNode *express);
	void setBody(PTNode *body);
	void semanticCheck(void);
	DF_Entry *dataflow(int message = 0); 
	void dumpTree(void);
};
//-------------------------------------------------------------------------
class PT_NLoop : public PT_Loop
{
	
public:
	PT_NLoop(int lineno);
	~PT_NLoop(void);
//	void setExpr(PTNode *express);
	void semanticCheck(void);
//	void dumpTree(void);
	VIRTUAL PTNode *make_clone(int message = 0);
};
//-------------------------------------------------------------------------
class PT_WLoop : public PT_Loop
{
	
public:
	PT_WLoop(int lineno);
	~PT_WLoop(void);
	void setExpr(PTNode *express);
	void semanticCheck(void);
//	void dumpTree(void);
	VIRTUAL PTNode *make_clone(int message = 0);
};
//-------------------------------------------------------------------------
class PT_RLoop : public PT_Loop
{
	PTNode *minExpr, *maxExpr;
	PTConst *incValue;
	
public:
	PT_RLoop(char *id, int lineno);
	~PT_RLoop(void);
	void setExpr(PTNode *express);
	void semanticCheck(void);
//	void dumpTree(void);
	VIRTUAL PTNode *make_clone(int message = 0);
};
//-------------------------------------------------------------------------

#endif /* PTLOOP_H */
