// FILE: stackq.h

#ifndef STACKQUEUE_H
#define STACKQUEUE_H

// CLASS STACKELEMENT (only used within Stack and Queue)

class StackElement
{
public:
	StackElement *next;
	void *element;
	
	StackElement(void);
	~StackElement(void);
		
		
};
	
//	CLASS STACK

class Stack
{
	StackElement *topOfStack;

public:
	
	Stack(void);	// constructor
	~Stack(void);
	void push(void *);
	void * pop(void);
	int isEmpty(void);
};

/////  CLASS QUEUE

class Queue
{
	StackElement *first, *last;
public:
	Queue(void);	// constructor
	~Queue(void);	// destructor
	void enqueue(void *);
	void *dequeue(void);
	int isEmpty(void);
};

#endif
