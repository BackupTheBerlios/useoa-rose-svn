
// FILE: PTMETHOD.C	- PARSE TREE NODES FOR METHODS AND MODULES

#include <stdio.h>
#include "lconfig.h"
#include "ptnode.h"
#include "ptexpr.h"
#include "ptmethod.h"
#include "build.h"
#include "globals.h"

////////////////////////// The following are unimplemented yet!
// CLASS PTMethodDecl
// CLASS PTMethodList
// CLASS PTImplementation
// CLASS PTInterfaceMap
// CLASS PTProcName
// CLASS PTVersionConstraint
// CLASS PTConstraint

#ifndef lint
static char *sccsid = "@(#)ptmethod.C	1.4 (University of Guelph, VLSI Dept.) 93/06/09";
#endif /* lint */

		

//------------------------------------------------------------------------
// CLASS PTMethodDecl()
//------------------------------------------------------------------------

PTMethodDecl::PTMethodDecl(void) : PTNode(ptreeMethodDecl)
{
	Error("METHODS not implemented yet!\n");
};
//------------------------------------------------------------------------
// CLASS PT_VersionDecl()
//------------------------------------------------------------------------

PT_VersionDecl::PT_VersionDecl(char *str1, char *str2) : PTNode(ptreeVersionDecl)	// constructor
{
	areaDefined = False;
	timeDefined = False;
	
	version = str1;
	proc = str2;
};

#define VER_KILL_LIST(list,node) \
{	node = (PT_VersionID *)list.remove_front();\
	while(node){	delete node; \
		node = (PT_VersionID *)list.remove_front();\
	}\
}

		

PT_VersionDecl::~PT_VersionDecl(void) // destructor
{	
	PT_VersionID *x;
	VER_KILL_LIST(mustuse,x);
	VER_KILL_LIST(mayuse,x);
	VER_KILL_LIST(closedModule,x);
	VER_KILL_LIST(replace,x);
	VER_KILL_LIST(nocost,x);
};

void 
PT_VersionDecl::setMustUse(PT_VersionID *list)
{
		mustuse.append(list);
};
void 
PT_VersionDecl::setMayUse(PT_VersionID *list) 								
{
	mayuse.append(list);
};

void 
PT_VersionDecl::setClosedModule(PT_VersionID *list) 							
{
	closedModule.append(list);
};
void 
PT_VersionDecl::setReplace(PT_VersionID *id, PT_VersionID *list)
{

	replace.append(list);
};
		
void 
PT_VersionDecl::setNoCost(PT_VersionID *list) 							
{
	nocost.append(list);
};

void 
PT_VersionDecl::setArea(int area, int lineno)							
{
	if(areaDefined == True)
	{
		Error(lineno,"Redefinition of AREA not allowed.\n");
	}
	
	areaDefined = True;
	maxarea = area;
};

void 
PT_VersionDecl::setTime(int time, int lineno)
{
	if(timeDefined == True)
	{
		Error(lineno,"Redefinition of TIME not allowed.\n");
	}
	
	timeDefined = True;
	maxtime = time;
};

void
PT_VersionDecl::print(void)
{
	Outfile->print(".VER %s %s\n",version,proc);
	
	printList(".MUST",	mustuse);	
	printList(".MAY",	mayuse);	
	printList(".MOD",	closedModule);	
	printList(".REPL",	replace);	
	printList(".NOCOST",	nocost);	
	
	Outfile->print(".AREA %d\n",maxarea);
	Outfile->print(".TIME %d\n",maxtime);
	Outfile->print(".END\n");
	Outfile->newline();
	
};

VIRTUAL void
PT_VersionDecl::semanticCheck(void)
{


};

void
PT_VersionDecl::printList(char *title, List &mylist)
{
	PT_VersionID *x = (PT_VersionID *)mylist.front();
	while(x)
	{
		x->print();
		x = (PT_VersionID *)mylist.succ();
	
	}
};

void
PT_VersionDecl::appendList(List &mylist, PT_VersionID *id)
{
	PT_VersionID *x = id;
	while(x)
	{
//		if(id->oneof == False)
//			mylist.append(x);

	}/* end while */
};

//------------------------------------------------------------------------
// CLASS PT_VersionID()
//------------------------------------------------------------------------

PT_VersionID::PT_VersionID(char *proc_name, char *version_name, int countx)
	: PTNode(ptreeVersionId)
{
	proc = proc_name;
	version = version_name;
	count = countx;
	oneof = False;
};

PT_VersionID::~PT_VersionID(void)	// destructor
{
	delete proc;
	delete version;
};

void
PT_VersionID::print(void)
{
	if(version == NULL)
		Outfile->print("%s %d ",proc,count);
	else
		Outfile->print("%s.%s %d ",proc,version,count);

	if(oneof == True && nextStmt)
		((PT_VersionID *)nextStmt)->print();
};

void
PT_VersionID::setOneOf(void)
{
	oneof = True;
	if(nextStmt)
		((PT_VersionID *)nextStmt)->setOneOf();
};

//------------------------------------------------------------------------
// CLASS PT_OneOf()
//------------------------------------------------------------------------
PT_OneOf::PT_OneOf(PT_VersionID *list) : PTNode(ptreeOneOf)
{
	vlist = list;
};

PT_OneOf::~PT_OneOf(void)
{
	delete vlist;
};

//------------------------------------------------------------------------
// CLASS PTMethodList()
//------------------------------------------------------------------------

PTMethodList::PTMethodList(void) : PTNode(ptreeMethodList)
{

};

//------------------------------------------------------------------------
// CLASS PTImplementation()
//------------------------------------------------------------------------

PTImplementation::PTImplementation(void) : PTNode(ptreeImplementation)
{

};

//------------------------------------------------------------------------
// CLASS PTInterfaceMap()
//------------------------------------------------------------------------

PTInterfaceMap::PTInterfaceMap(void) : PTNode(ptreeInterfaceMap)
{

};

//------------------------------------------------------------------------
// CLASS PTProcName()
//------------------------------------------------------------------------

PTProcName::PTProcName(void) : PTNode(ptreeProcName)
{

};

//------------------------------------------------------------------------
// CLASS PTVersionConstraint()
//------------------------------------------------------------------------

PTVersionConstraint::PTVersionConstraint(PTNode *ver, PTNode *constraints)
	 : PTNode(ptreeVersionConstraint)
{

};

//------------------------------------------------------------------------
// CLASS PTConstraint()
//------------------------------------------------------------------------

PTConstraint::PTConstraint(void) : PTNode(ptreeConstraint)
{

};

//------------------------------------------------------------------------
// CLASS PTConstraint()
//------------------------------------------------------------------------
