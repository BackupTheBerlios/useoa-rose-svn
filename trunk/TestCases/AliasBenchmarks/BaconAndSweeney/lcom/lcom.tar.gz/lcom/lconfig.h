// FILE: LCONFIG.H
// MAKE SURE ONE OF THE SYSTEM TYPES IS DEFINED

#if ! ( defined(__GNUC__) || defined(__TURBOC__) || defined(_AIX) \
	|| defined(MYOS2) || defined(hpux) \
	|| defined(sparc) || defined(__lucid))
#error System Definition is missing! _AIX, __GNU__, MYOS2, __TURBOC__, hpux, sparc, __lucid
#endif

