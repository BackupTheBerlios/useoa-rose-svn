// FILE : build.c

#ifndef lint
static char *sccsid = "@(#)build.C	1.10 (University of Guelph, VLSI Dept.) 93/05/06";
#endif /* lint */


#include "lconfig.h"

#include "errors.h"
#include "utils.h"
#include "globals.h"
#include "build.h"

//----------------------------------------------------
#define xor(a,b)  (( a | b ) & ~( a | b ))
//----------------------------------------------------
#define TEST_SYMBOL(x,y)	{ \
	if(x->isConstant() == False)\
		Compiler_Error("Expected a constant STEntry!\n");\
	y = (STEntry *)x;\
	}
	
// function prototypes
DF_Entry *
evalAlgebraicIdentity(DF_Entry *l, DF_Entry *r, int opToken, long lineno);
		
//----------------------------------------------------
static void
calcConstUnary(long oldval, long oldpw, long &newval, long &newpw, 
									int opToken, long lineno)
{


	switch(opToken)
	{
		case MINUS:
			newval = -(oldval);
			newpw = oldpw;
			break;
		case NOT:
			newval = ~(oldval);
			newpw = oldpw;
		default:
			Compiler_Error("Undefined Unary Operator (%s)\n",
				getTokenStr(opToken));
			break;
	}
};

//----------------------------------------------------



// evaluate unary operations that result in a constant.

PTConst *
evalConstUnary(PTNode *left, int opToken, long lineno)
{
	long oldval = left->getValue();
	long oldpw = left->getPathWidth();
	
	long newval, newpw;
	
	calcConstUnary(oldval, oldpw, newval, newpw, opToken, lineno);
	
	PTConst *pt = new PTConst(newval,newpw);
	
	delete left;
	return(pt);
};

//----------------------------------------------------
// evaluate unary operations that result in a constant.

DF_Entry *
evalConstUnary(DF_Entry *left, int opToken, long lineno)
{
	STEntry *l;
	TEST_SYMBOL(left,l);
	long oldval = l->getConstantValue();
	long oldpw = l->getPathWidth();
	
	long newval, newpw;
	
	calcConstUnary(oldval, oldpw, newval, newpw, opToken, lineno);

	STEntry *ste = SymTbl.lookup(newval,newpw);
	if(!ste)
	{
		ste = SymTbl.insert(newval,newpw);
		
	};
	return(ste);
};
//----------------------------------------------------
PTNode *buildUnaryExpr(PTNode *uexpr, int opToken, int lineno)
{
	uexpr = uexpr->cfold();
	
	PTNode *newnode;
//	if( uexpr->isConstant() )
//	{
//		newnode = evalConstUnary(uexpr, opToken, lineno);
//	}
//	else
	{
		newnode = new PTUnaryOptr(opToken,lineno);
		newnode->linkChild(uexpr);
	}

	return(newnode);
};

//----------------------------------------------------
// evaluate binary operations that result in a constant.

static void
calcConstBinary(long lval, long lpathw, long rval, long rpathw,
						int opToken, long &newvalue, long &newpathw, long lineno)
{
	
	switch(opToken)
	{
		case PLUS:
			newvalue = lval + rval;
			newpathw = max(lpathw, rpathw);
			break;
		case MINUS:
			newvalue = lval - rval;
			newpathw = max(lpathw, rpathw);
			break;
		case MULTIPLY:
			newvalue = lval * rval;
			newpathw = max(lpathw, rpathw);
			break;
		case DIVIDE:
			newvalue = lval / rval;
			newpathw = max(lpathw, rpathw);
			break;
		case COMPEQUALS:
			newvalue = (lval == rval) ? 1 : 0;
			newpathw = 1;	// a boolean result
			break;
		case NOTEQUAL:
			newvalue = (lval != rval) ? 1 : 0;			
			newpathw = 1;	// a boolean result
			break;
		case LT:
			newvalue = (lval < rval) ? 1 : 0;
			newpathw = 1;	// a boolean result
			break;
		case LTE:
			newvalue = (lval <= rval) ? 1 : 0;
			newpathw = 1;	// a boolean result
			break;
		case GT:
			newvalue = (lval > rval) ? 1 : 0;
			newpathw = 1;	// a boolean result
			break;
		case GTE:
			newvalue = (lval >= rval) ? 1 : 0;
			newpathw = 1;	// a boolean result
			break;
		case MOD:
			newvalue = lval % rval;
			newpathw = max(lpathw, rpathw);
			break;
		case AND:
			newvalue = lval & rval;
			newpathw = max(lpathw, rpathw);
			break;
		case NAND:
			newvalue = ~(lval & rval);
			newpathw = max(lpathw, rpathw);
			break;
		case OR:			//  bitwise operations?
			newvalue = lval | rval;
			newpathw = max(lpathw, rpathw);
			break;
		case NOR:					
			newvalue = ~(lval | rval);
			newpathw = max(lpathw, rpathw);
			break;
		case XOR:			
			newvalue = xor(lval,rval);
			newpathw = max(lpathw, rpathw);
			break;
		case XNOR:					
			newvalue = ~(xor(lval,rval));
			newpathw = max(lpathw, rpathw);
			break;
		case SHL:
			testShiftOperands(lpathw, rval, lineno);
			newvalue = lval << rval;
			newpathw = lpathw;
			break;
		case SHR:
			testShiftOperands(lpathw, rval, lineno);
			newvalue = lval >> rval;
			newpathw = lpathw;
			break;
		case ROL:
			newvalue = rol(lval,lpathw,rval);
			newpathw = lpathw;
			break;
		case ROR:
			newvalue = ror(lval, lpathw, rval);
			newpathw = lpathw;
			break;
	
		default:
			Compiler_Error("Undefined Binary Operator (%s)\n",
				getTokenStr(opToken));
			break;
	} /* end switch */
}		


// evaluate binary operations that result in a constant.

PTConst *
evalConstBinary(PTNode *left, PTNode *right, int opToken, long lineno)
{

	long lval = left->getValue();
	long lpw = left->getPathWidth();
	long rval = right->getValue();
	long rpw = right->getPathWidth();
		
	long newval, newpw;
		
	
	calcConstBinary(lval, lpw, rval, rpw, opToken, newval, newpw, lineno);	

	delete left;
	delete right;
	
	PTConst *pt = new PTConst(newval, newpw);
	return(pt);
}	
	
// evaluate binary operations that result in a constant.

DF_Entry *
evalConstBinary(DF_Entry *left, DF_Entry *right, int opToken, long lineno)
{
	// make sure that left and right are constants 
	// (ie, a STEntry with a constant value)
	DF_Entry *result;
		
	if(left->isConstant() && right->isConstant())
	{
		STEntry *l, *r;
		TEST_SYMBOL(left,l);	
		TEST_SYMBOL(right,r);

		long lval = l->getConstantValue();
		long lpw = l->getPathWidth();
		long rval = r->getConstantValue();
		long rpw = r->getPathWidth();
		
		long newval, newpw;
		
		calcConstBinary(lval, lpw, rval, rpw, opToken, newval, newpw, lineno);	

		STEntry *ste = SymTbl.lookup(newval,newpw);
		if(!ste)
		{
			ste = SymTbl.insert(newval,newpw);	
   		ste->step_used.setNum(0);	// does not matter what step this is on.
   		ste->step_accessed.setNum(0);	
		};
		result = ste;		// return a constant
	}
	else  
	{
		// return a DF_Entry, which may be NULL if no identity existed.
		result = evalAlgebraicIdentity(left,right,opToken,lineno);
	}
	return(result);
}	
	

//-----------------------------------------------------------------
// if the 2 expressions used in this binary expression are not both
// constants, then simply return a PTBinOptr.  If both of the 
// expressions are constant, then do the operation here in memory,
// and return a PTConst.


PTNode *buildBinaryExpr(PTNode *left, int opToken, PTNode *right, int lineno)
{
	if(!left || !right)
	{
		Compiler_Error("Bad call to function buildBinaryExpr()\n");
		return(NULL);
	}
	
	// constant fold both sides!
		
//	left = left->cfold();
//	right = right->cfold();
	

//	if(left->isConstant() && right->isConstant())
//	{
//		newnode = evalConstBinary(left, right, opToken, lineno);
//	}
//	else if((left->getType() == ptreeBinOptr) && isCommAssocOptr(opToken) &&
//				(left->getOptr() == opToken))
//	{
//		left->appendOpnd(right);
//		newnode = left;
//	}
//	else
//	{
//		if(right->isConstant() && isCommutativeOptr(opToken))
//			newnode->linkChild(right,left);
//		else


	PTNode *newnode;

	// if the left node is a binary operation,
	// and that operation is the same as the current opertion,
	// and the command line switch allows N-Ary operations,
	// then just link the right operand to the left operation.
	
	if((left->getNodeType() == ptreeBinOptr) &&
			(((PTBinOptr *)left)->operationToken == opToken) && 
			isCommAssocOptr(opToken) && CLFlags.N_AryOperators)
	{
		left->linkChild(right);
		newnode = left;
	}
	else
	{
		PTBinOptr *node = new PTBinOptr(opToken,lineno);
		node->linkChild(left,right);
		newnode = node;
	}


	return(newnode);



};

//----------------------------------------------------
boolean isCommutativeOptr(int opToken)
{
	boolean result;
	
	switch(opToken)
	{
		case PLUS:			// Commutative operations (ie, a + b == b + a)
		case MULTIPLY:
		case COMPEQUALS:
		case AND:
		case NAND:
		case OR:			
		case NOR:					
		case XOR:			
		case XNOR:					
			result = True;
			break;
			
		case DIVIDE:	// non-commutative operations (ie, a - b != b - a)
		case MINUS:		// (binary and unary -)
		case NOTEQUAL:
		case LT:
		case LTE:
		case GT:
		case GTE:
		case MOD:
		case SHL:
		case SHR:
		case ROL:
		case ROR:
		case LSQRBRACE:	// array index
		case NOT:	// unary not
			result = False;
			break;

		default:
			Compiler_Error("Undefined Operator (%s)\n", getTokenStr(opToken));
			break;
	} /* end switch */
	return(result);
};

//----------------------------------------------------
boolean isAssociativeOptr(int opToken)
{
	boolean result;
	
	switch(opToken)
	{
		case PLUS:			// Associative operations (ie, (a+b)+c == a+(b+c))
		case MULTIPLY:
		case AND:
		case NAND:
		case OR:			
		case NOR:					
		case XOR:			
		case XNOR:					
			result = True;
			break;
			
		case DIVIDE:	// non-associative operations 
		case MINUS:		// (binary and unary -)
		case NOTEQUAL:
		case LT:
		case LTE:
		case GT:
		case GTE:
		case MOD:
		case SHL:
		case SHR:
		case ROL:
		case ROR:
		case COMPEQUALS:
		case LSQRBRACE:	// array index
		case NOT:	// unary not
			result = False;
			break;

		default:
			Compiler_Error("Undefined Operator (%s)\n", getTokenStr(opToken));
			break;
	} /* end switch */
	return(result);
};

//----------------------------------------------------
// roll right `count' bits.
long ror(long x, long pathwidth, long count)
{
	if(count >= pathwidth)
		count =  count % pathwidth;
		
	for(int i = 0; i < count; i++)
	{
		// get the least significant bit
		long bit = (x & 0x0001) << (pathwidth - 1);
		x = (x >> 1) & 0x7fffffff;	// shift x and set msb to 0.
		x = x | bit;
	}
	return(x);

};


//----------------------------------------------------
// roll left `count' bits.

long rol(long x, long pathwidth, long count)
{
	if(count >= pathwidth)
		count =  count % pathwidth;
		
	for(int i = 0; i < count; i++)
	{
		// get the most significant bit
		long bit = (x >> (pathwidth -1)) & 0x00000001;
		x = (x << 1) & 0xfffffffe;	// shift x and set new lsb to 0.
		x = x | bit;
	}
	return(x);

};


//----------------------------------------------------
// As in C, there are two restrictions on the use of the shift operators.
// 1: the right operand may not be negative.
// 2: the value of the right operand may not exceed the number of bits
//    used to represent the left operand. 
//	If these restrictions are violated, the shift expression is undefined.
//

boolean testShiftOperands(long lpathw, long shiftval, long lineno)
{
	if(shiftval > lpathw)
	{
		Error(lineno,
			"Right operand may not exceed number of bits in left operand\n");
		return(False);
	}
	else if(shiftval < 0)
	{
		Error(lineno,"Right operand must be positive!\n");
		return(False);
	}
	return(True);	
}	


//----------------------------------------------------
// Try to use an algrebraic identity to eliminate an operation!
// x + 0 = 0 + x = 0
// x - 0 = x
// x * 0 = 0 * x = 0
// x * 1 = 1 * x = x
// x / 1 = x
// x & 0 = 0 & x = 0
// x | 0 = 0 | x = x

// return NULL if no identity can be used!

DF_Entry *
evalAlgebraicIdentity(DF_Entry *l, DF_Entry *r, int opToken, long lineno = 0)
{
	DF_Entry *result = NULL;
	boolean lconst = l->isConstant();
	boolean rconst = r->isConstant();
	long lval = (lconst) ? ((STEntry *)l)->getConstantValue() : 0;
	long rval = (rconst) ? ((STEntry *)r)->getConstantValue() : 0;
	
	switch(opToken)
	{
		case PLUS:
			if(lconst && (lval == 0))	// 0 + x = x
			{
				result = r;	
			}
			else if(rconst && (rval == 0))	// x + 0 = x
			{
				result = l;
			}
			break;
		case MULTIPLY:
			if(lconst)	
			{
				 if(lval == 0)
				 	result = l;
				 else if(lval == 1)
				 	result = r;	
			}
			else if(rconst)	
			{
				 if(rval == 0)
				 	result = r;
				 else if(rval == 1)
				 	result = l;	
			}
			break;
		case DIVIDE:	
			if(rconst)
			{
				if(rval == 1)	// x / 1 = x
					result = l;
				else if (rval == 0)
					Error(lineno,"Divide by zero evaluated.\n"); 
			}
			else if(lconst && (lval == 0))
			{
				result = l;	// 0 / x = 0
			}
			break;
		case AND:	// 0 & x = x & 0 = 0
			if(lconst && (lval == 0))	
				result = l;
			else if(rconst && (rval == 0))
				result = r;
			break;
			break;
		case OR:
			if(lconst && (lval == 0))
				result = r;		// 0 | x = x
			else if(rconst && (rval == 0))
				result = l;		// x | 0 = x
			break;
		case SHL:	// all shift and roll operations have the same identity
		case SHR:	// 0 << x = 0 >> x = 0 rol x = 0 ror x = 0
		case ROL:
		case ROR:
			if(rconst && (rval == 0))
				result = l;	
			else if(lconst && (lval == 0))
				result = l;
			break;
		case NAND:	// no identities possible for these operations.
		case NOR:
		case XOR:
		case XNOR:
		default:
			break;
	}/* end switch */
	return(result);

};
