
// FILE: PTBRANCH.H - PARSE TREE BRANCHING STATEMENTS (IF, SWITCH/CASE, COBEGIN)


#ifndef PTBRANCH_H 
#define PTBRANCH_H

#include "ptnode.h"
#include "tokens.h"
#include "boolean.h"
#include "dataflow.h"


/////////////////////////////////////////////////////////////////////////
// The following classes are defined in this file, in this order.
//

class PT_Branch;
class PT_if;
class PT_Switch;
class PT_CoBegin;

class CondBranch;
/////////////////////////////////////////////////////////////////////////
class PT_Branch : public PTNode
{

   
protected:
   CondBranch *cond_stmt;
   int branchCount;
   int caseCount;
   boolean defaultCase;
   
public:
   PT_Branch(PtreeNodeType btype, int lineno);
   ~PT_Branch(void);
   DF_Entry *dataflow(int message = 0);
   VIRTUAL void dumpTree(void);
};

/////////////////////////////////////////////////////////////////////////

class PT_if : public PT_Branch
{
   PT_tuple *if_thens;
   
// if_cond_stmt_T cond_stmt[MAXBRANCHCOUNT]; 
   
public:
   PT_if(PT_tuple *if_then_pairs, int lineno);
   ~PT_if(void);
// void setCondBranch(PT_tuple *tuple);
   void semanticCheck(void);
// DF_Entry *dataflow(int message = 0); 
	VIRTUAL PTNode *make_clone(int message = 0);
   VIRTUAL void dumpTree(void);
};
/////////////////////////////////////////////////////////////////////////
class PT_Switch : public PT_Branch
{
   PTNode *sw_exprvar;
   PT_tuple *sw_cases;
// PTNode **sw_expr; //array of expressions (ie, (sw_exprvar == case_expr))

public:
   PT_Switch(PTNode *expr, PT_tuple *cases, int lineno);
   ~PT_Switch(void);
   void semanticCheck(void);
// DF_Entry *dataflow(int message = 0); 
	VIRTUAL PTNode *make_clone(int message = 0);
   VIRTUAL void dumpTree(void);

};

/////////////////////////////////////////////////////////////////////////
class PT_CoBegin : public PT_Branch
{
   PTNode *cojoin;
   PT_tuple *branches;
   
public:
   PT_CoBegin(PT_tuple *possibleBranches, PTNode *cojoin_expr, int lineno);
   ~PT_CoBegin(void);   // destructor
   void semanticCheck(void);
   DF_Entry *dataflow(int message = 0); 
	VIRTUAL PTNode *make_clone(int message = 0);
   VIRTUAL void dumpTree(void);

};


/////////////////////////////////////////////////////////////////////////

#endif
