// FILE: subexpr.c

#include "lconfig.h"

#include "globals.h"
#include "build.h"
#include "subexpr.h"


extern DataFlowGraph *CurrentDFG;
OpndEntry *storeOptrInTempOpnd(OptrEntry *optr, int stepnum, char *prefix);

//-----------------------------------------------------------------
// Calculate the factorial of n
//-----------------------------------------------------------------
#define MAXFACT 20
unsigned long FactorialData[MAXFACT];

unsigned long factorial(unsigned long n)
{
	if (CLFlags.Debug)
	{
	  if(n < 0)
	     Compiler_Error("Negative value (%d) to factorial not allowed\n",n);
	}
	if (n <= 1)
		return(1);
	else
		return(n * factorial(n-1));
}

unsigned long factorialX(unsigned long n)
{
	if (CLFlags.Debug)
	{
	  if(n < 0)
	     Compiler_Error("Negative value (%d) to factorial not allowed\n",n);
	}
	unsigned long result;
	if(n <= 1)
		result = 1;
	else if ((n < MAXFACT) && (FactorialData[n] > 0))// check the table
		result = FactorialData[n];
	else
	{
		result = (n * factorial(n-1));	
		FactorialData[n] = result;
	}
	
	return result;
};
//-----------------------------------------------------------------
// Calculate (A!/B!), where B < A.
//-----------------------------------------------------------------
unsigned long factorialAB(unsigned long a, unsigned long b)
{
	unsigned long fact = 1;
	for(unsigned long i = a; i > b; i--)
		fact = fact * i;

	return(fact);
};

//-----------------------------------------------------------------
// Calculate the number of combinations of `r' items selected
// from `n' available items.
// nCr =  	n!
//		--------
//		(n-r)!r!
//-----------------------------------------------------------------
unsigned long nCr(unsigned long n, unsigned long r)
{
	// We get some overflow problems with this expression,
	//return(factorial(n) / (factorial(n-r)*factorial(r)));
	
	// So try this: Of the 2 denominators, use the larger and
	// factor out the numerator. Then finish the computation.
	unsigned long result;
	if(r > (n-r))
	{
		result = (factorialAB(n,r)/factorial(n-r));
	}
	else	// r <= (n-r)
	{
		result = (factorialAB(n,n-r)/factorial(r));
	}
	return result;
};

//-----------------------------------------------------------------
// Calculate the number of permutations of `r' items selected
// from `n' available items.
// nPr =   n!
//			------
//			(n-r)!
//-----------------------------------------------------------------
//// Comment this out since we do not need it now.

//int nPr(int n, int r)
//{
//	return(factorial(n) / factorial(n-r));
//};

//-----------------------------------------------------------------
//-----------------------------------------------------------------
class Combinations
{
	Combinations *subcomb;
	int R;	// need to make combinations of R units
	int N;	// make combinations out of a possible N units
	int next_opnd;	// keep track of the next unit to test;
	unsigned long expectedCombos;	
	static	int next_depth;
	
	DF_EntryPtr *opndArray;	// array of M units.
	
	public:
		Combinations(unsigned long r, unsigned long n, DF_EntryPtr *opnd);
		~Combinations(void);
		void next(OptrEntry *optr);
		boolean more(void);
};

int Combinations::next_depth = 0;	// keep track of depth of recursive calls.

Combinations::Combinations(unsigned long r, unsigned long n, DF_EntryPtr *opnd)
{
	R = r;
	N = n;
	opndArray = opnd;
	subcomb = NULL;
	next_opnd = 0;
	expectedCombos = nCr(N,R);
	if(expectedCombos <= 0)
		Compiler_Error("%s (%ld != nCr(%ld,%ld))\n%s\n",
		"Combinations::ctor - Overflow",
		expectedCombos,N,R,
		"Expression may be too complex or long.");
	else if(expectedCombos > 20000L)
		Warning("%s (%ld = nCr(%ld,%ld))\n%s%s\n",
		"Combinations::ctor - Impending Overflow",
		expectedCombos,N,R,
		"Expression may be too complex or long.",
		"(Likely not worth the effort!)");
};

Combinations::~Combinations(void)
{
	if(subcomb != NULL)
	{
		delete subcomb;
		subcomb = NULL;
	}

};

void
Combinations::next(OptrEntry *optr)
{
	if(CLFlags.Debug)
		printf("Entering - Combinations::next(depth=%d)\n",next_depth);
	next_depth++;
	if(expectedCombos == 0)
	{
		Compiler_Error("%s cannot be called without checking %s\n",
				"Combinations::next()","Combinations::more()");
	}
	
	if(R == 1)
	{
		//testOpnds[0] = opndArray[next_opnd];
		optr->setSourceList(opndArray[next_opnd]);
		next_opnd++;
		expectedCombos--;
	}
	else	// R >= 2
	{
		// this only need to be done once!
		if(subcomb == NULL)
		{
			subcomb = new Combinations(R-1,N-next_opnd-1,&opndArray[next_opnd+1]);
		}
	
		// if there are no more sub-combinations, start with a smaller set
		if(subcomb->more() == False)
		{
			next_opnd++;
			delete subcomb;
			subcomb = new Combinations(R-1,N-next_opnd-1,&opndArray[next_opnd+1]);
		}
			
		// add the next opnd to the optr
		optr->setSourceList(opndArray[next_opnd]);
		expectedCombos--;
		
		subcomb->next(optr);
	}
	// decrement the stack depth
	next_depth--;
	
	return;		

};

boolean
Combinations::more(void)
{
	return((expectedCombos > 0) ? True : False);
};

//-----------------------------------------------------------------
//-----------------------------------------------------------------

//OptrEntry *divideIntoSubexpressions(OptrEntry *me)
void divideIntoSubexpressions(OptrEntry *me)
{

	// test to see if this operation is a candidate for
	// common subexpression division
	if(isCommAssocOptr(me->getOptrToken()) == False)
		return;
	
	int num_opnds = me->arglist.length();
	if(num_opnds <= 2)
		return;

	// create a temporary array so we do not have to go thru the linked list.
	DF_EntryPtr *opnd_array = new DF_EntryPtr[num_opnds];
	DF_Entry *x = (DF_Entry *)me->arglist.front();
	for(int i=0; i<num_opnds; i++)
	{
		opnd_array[i] = x;
		x = (DF_Entry *)me->arglist.succ();
	}



	int opToken = me->getOptrToken();
	int lineno = me->sourceinfo.getLine();
	
	for(int j = num_opnds-1; j>=2; j--)
	{
	
		// find all combinations of `j' elements from the set of 
		// `num_opnds' elements.
		
		Combinations *combo = new Combinations(j,num_opnds,opnd_array);
		
		while(combo->more())
		{
			OptrEntry *optr = new OptrEntry(opToken,lineno);
			combo->next(optr);
			
			//printf("TESTING SUBEXPRESSION\n");
			//DF_Entry *junk = optr->arglist.front();
			//while(junk)
			//{
			//	switch(junk->getType())
			//	{
			//		case Entry_symtbl:
			//			printf("SYM %s\n",junk->getName());
			//			break;
			//		case Entry_opnd:
			//			printf("OPND %s\n",junk->getName());
			//			break;
			//		default:
			//			printf("Unknown symbol!\n");
			//			break;
			//	}
			//	junk = optr->arglist.succ();
			//}
			
			DF_Entry *result = CurrentDFG->commSubExpr(optr);
			if(result)
			{	// found a common subexpression!
				// Now need to break up the current expression!
			
   			DF_Entry *opnd = (DF_Entry *)optr->arglist.front();
   			while(opnd)
   			{
   				// find the opnd in the original operation, and delete it
   				if(!me->arglist.del(opnd))
   				{
   					Compiler_Error("Unable to delete opnd from list!\n");
   				};
   				opnd =  (DF_Entry *)optr->arglist.succ();
   			};
				// store the optr in a temporary operand, if neccessary
				if(result->getType() == Entry_optr)
				{
					 result = storeOptrInTempOpnd((OptrEntry *)result,0,"");
   			}
   					
				// the temporary opnd is now a source of 
				// the original operation.
				me->setSourceList(result);

				// recursively search for other subexpressions!!!!!!
					
				divideIntoSubexpressions(me);	
  				return;
   		}/* end if */
			
		
		
		}
	}

		
};

