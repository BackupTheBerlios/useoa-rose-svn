/* FILE: utils.h */

#ifndef UTILS_H
#define UTILS_H


#include "boolean.h"
#include <stdio.h>
#include <stdlib.h>
#include "list.h"


//-------------------------------------------------------------------------
#define MAGIC 0x71717171
//-------------------------------------------------------------------------
// The MagicNumber class can be used with any objects that get created
// on the heap, to help insure that an object destructor is never called 
// more than once.  (This problem became evident in this project
// since there are many objects that are interconnected and cross linked.)
//
// Use the class MagicNumber to quickly find out these problems (can 
// potentially cause stray pointer problems, otherwise) by simply
// declaring an object of type MagicNumber inside any other object.
// The MagicNumber constructor is automatically called upon the
// construction of any other object that uses a MagicNumber object.
// In the constructor, the 'magic' field is set to MAGIC.
// When an object destructor is called, the automatic variable
// for the class MagicNumber destroyed with an implicit call to
// its destructor. In the destructor, the 'magic' field is tested
// for integrity, and then set to zero.  With this method, if the same
// MagicNumber object destructor is called (implicity) more than once,
// it will be easily detected since the 'magic' field will not hold
// the appropriate magic number on the second try.
// 
// This class can also detect some random overwriting of memory,
// if that memory includes the area where the MagicNumber object is
// stored.



//-------------------------------------------------------------------------
extern void Compiler_Error(char *msg, ...);
//-------------------------------------------------------------------------

class MagicNumber
{
	int magic;
public:
	MagicNumber()	{ magic = MAGIC; };
	~MagicNumber() 
	{
	if(magic == MAGIC) 
		magic = 0;
	else 
		Compiler_Error("MAGIC NUMBER ERROR!!!\n");
	};
};

//-------------------------------------------------------------------------
struct sourceFile_S
{
	int fileId;
	int lineNumber;
};
//----------------------------------------------------------------------



/* function prototypes */


extern char *mallocName(char *name);
extern char *mallocName(char *name, char *suffix);
extern char *mallocName(char *prefix, int counter);
extern char *mallocNameTemp(char *prefix = "");
//----------------------------------------------------------------------

class OutputFile
{

	FILE *fp;
	char *fn;
	
public:

	OutputFile(char *filename);
	OutputFile(FILE *fp);
	~OutputFile(void);
	void close(void);
	
void print(char *format, ...);
	void comment(char *format, ...);
	void newline(void);
	int fileOK(void);

};

//----------------------------------------------------------------------

//inline boolean isOdd (int i) { return ( (boolean)   i & 0x0001  ); };
//inline boolean isEven(int i) { return ( (boolean)(!( i & 0x0001)) ); };

#define isOdd(i) ( i & 0x0001 )
#define isEven(i) (!( i & 0x0001))


#define max(a,b)	( (a > b) ? a : b)
#define min(a,b)	( (a < b) ? a : b)	





//----------------------------------------------------------------------
class PTNode;
class DF_Entry;

class GarbageCollector
{
	List pt;	// a list of PTNode base objects to be deleted.
	List df;	// a list of DF_Entry based objects to be deleted.


public:
	GarbageCollector(void);		// constructor
	~GarbageCollector(void);	// destructor
	void add(PTNode *x);
	void add(DF_Entry *x);
	void clean_it_up(void);
};
//----------------------------------------------------------------------
#endif




