// FILE: ERRORS.C

#include <stdio.h>
#include <stdlib.h>
#include "lconfig.h"

#ifndef __GNUC__
#include <string.h>
#endif

#include "errors.h"
#include "globals.h"

extern char *yytext;

int ErrorCount = 0;
int DuplicateErrorCount = 0;

int WarningCount = 0;
const int MaxErrorsAllowed = 10;

static char prev_yytext[256];
static int  prev_lineno = -1;
static int  prev_initialized = 0;

extern void closeAllFiles(void);

#ifndef lint
static char *sccsid = "@(#)errors.C	1.7 (University of Guelph, VLSI Dept., T. Ponzo) 93/06/09";
#endif

//----------------------------------------------------------------------------
void Compiler_Error(char *format, ...)
{
	va_list argptr;
	printf("Compiler Internal Error: ");

	va_start(argptr, format);
	vprintf(format, argptr);
	va_end(argptr);
	ErrorCount ++;

	closeAllFiles();
	exit(1);	/* exit from the compiler */
}
//----------------------------------------------------------------------------
void Fatal_Error(char *format, ...)
{
	va_list argptr;
	printf("Fatal Error: ");

	va_start(argptr, format);
	vprintf(format, argptr);
	va_end(argptr);
	ErrorCount ++;

	closeAllFiles();
	exit(1);	/* exit from the compiler */
}
//----------------------------------------------------------------------------
void Error(char *format, ...)
{
	if(ErrorCount >= MaxErrorsAllowed)
	{
		Fatal_Error("MAXIMUM ERROR COUNT REACHED. COMPILING HALTED.\n");
		return;
	}
	
	va_list argptr;
	printf("Error: ");

	va_start(argptr, format);
	vprintf(format, argptr);
	va_end(argptr);
	ErrorCount ++;

}
//----------------------------------------------------------------------------
void Error(int linenum, char *format, ...)
{
	if(ErrorCount >= MaxErrorsAllowed)
	{
		Fatal_Error("MAXIMUM ERROR COUNT REACHED. COMPILING HALTED.\n");
		return;
	}
	if(!prev_initialized)
	{
		prev_yytext[0] = '\0';
		prev_lineno = 0;
		prev_initialized = 1;
	}

	int duplicateflag = 0;
		
	if(	(prev_lineno == linenum) && 
			(strlen(yytext) < 255) && 
			(strcmp(prev_yytext,yytext) == 0) )
	{
		DuplicateErrorCount++;
		duplicateflag = 1;
	}

	
	// if not in debug mode, do not print duplicate errors.
	if(!CLFlags.Debug && duplicateflag)	
		return;
			
	if(duplicateflag)
		printf("Error (duplicate): Line %d: ",linenum);
	else
	{
		printf("Error: Line %d: ",linenum);
		ErrorCount++;
	}
	
	va_list argptr;

	va_start(argptr, format);
	vprintf(format, argptr);
	va_end(argptr);
		
	// set up the previous symbols
	prev_lineno = linenum;
	if(strlen(yytext) < 255)
		strcpy(prev_yytext,yytext);
	else
		strcpy(prev_yytext,"");
		
} /* end Error() */
//----------------------------------------------------------------------------
void Warning(char *format, ...)
{

	WarningCount ++;
	if(CLFlags.WarningsSuppress)
		return;
	
	va_list argptr;
	printf("Warning: ");

	va_start(argptr, format);
	vprintf(format, argptr);
	va_end(argptr);

}
//----------------------------------------------------------------------------
void Warning(int linenum, char *format, ...)
{

	WarningCount ++;
	if(CLFlags.WarningsSuppress)
		return;
	
	va_list argptr;
	printf("Warning: Line %d: ", linenum);

	va_start(argptr, format);
	vprintf(format, argptr);
	va_end(argptr);

}
//----------------------------------------------------------------------------

void debug(char *format, ...)
{
	if(CLFlags.Debug)
	{
		va_list argptr;
		printf("DEBUG: ");

		va_start(argptr, format);
		vprintf(format, argptr);
		va_end(argptr);
	}
}
//----------------------------------------------------------------------------
