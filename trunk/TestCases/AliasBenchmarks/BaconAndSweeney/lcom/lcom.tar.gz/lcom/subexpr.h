// FILE: subexpr.h 

#include "dfentry.h"

//OptrEntry *divideIntoSubexpressions(OptrEntry *me);
void divideIntoSubexpressions(OptrEntry *me);
