// FILE: sets.h

#ifndef SETS_H
#define SETS_H

#include <values.h>			// need MAXINT defined.

#define DEFAULT_INITIAL_CAPACITY 10
#define CHUNKSIZE						10

class BaseSet
{
protected:
	int count;	// number of elements in the set.
	int maxsize;	// maximum number of elements allowed without
						// having to allocate more memory.
						
	BaseSet(void)	// constructor
	{
		count = 0;
		maxsize = 0;
	};
	
public:
	
	int length(void)	{	return(count);	};

	int empty(void)	{	return ( (count == 0) ? 1 : 0 );	};

	int first(int &idx)	
	{	
		idx = 1;	// 1 is the first index.
		return( (count > 0) ? 1 : 0 );
	};

	int next(int &idx)
	{
		idx++;
		return( (idx <= count) ?  1 : 0);
	};

};


class IntSet : public BaseSet
{
	int *ptr;
	
	int compare(int item1, int item2);
					// return 0 if equal;
					// return -1 if item1 < item2
					// return +1 if item1 > item2
	
public:
	IntSet(int chunksize = DEFAULT_INITIAL_CAPACITY);
	IntSet(const IntSet&);
 
	~IntSet(void);	// destructor
					 
	int add(int item);	// add item, returning its index.
	void del(int item);	// delete item from the set.
	int contains(int item); // returns true if item is in the set.

	void clear(void);	// deletes all items from the set.


	int& operator () (int idx);	// returns reference to the item
 													// indexed by idx.
 
	int seek(int item);			// return index of this item,
 													// 0 if not found.

	void operator |= (IntSet& b);	
 					// a |= b, add all items of b to a
 					
	void operator -= (IntSet& b);	
 					// a -= b, deletes all items of b from a
 					
	void operator &= (IntSet& b);

	int operator == (IntSet& b);
 					// a == b, returns true if a and b contain all the same items.
 					
	int operator != (IntSet& b);
 					// a != b, returns true if a and b do not contain 
 					// all the same items.
 					
	int operator <= (IntSet& b); 
 					// a <= b, returns true if a is a subset of b.
 	
	int rangeCount(int min_item, int max_item = MAXINT);
};



class StringSet : public BaseSet
{
	char **ptr;
	
	int compare(const char *item1, const char *item2);
					// return 0 if equal;
					// return -1 if item1 < item2
					// return +1 if item1 > item2
	
public:
	StringSet(int chunksize = DEFAULT_INITIAL_CAPACITY);
	StringSet(const StringSet&);
 
	~StringSet(void);	// destructor
					 
	int add(const char *item);	// add item, returning its index.
	void del(const char *item);	// delete item from the set.
	int contains(const char *item); // returns true if item is in the set.

	void clear(void);	// deletes all items from the set.
										
	char* operator () (int idx);	// returns reference to the item
 													// indexed by idx.
 													
 
	int seek(const char *item);		// return index of this item,
 													// 0 if not found.

	void operator |= (StringSet& b);	
 					// a |= b, add all items of b to a
 					
	void operator -= (StringSet& b);	
 					// a -= b, deletes all items of b from a
 					
	void operator &= (StringSet& b);

	int operator == (StringSet& b);
 					// a == b, returns true if a and b contain all the same items.
 					
	int operator != (StringSet& b);
 					// a != b, returns true if a and b do not contain 
 					// all the same items.
 					
	int operator <= (StringSet& b); 
 					// a <= b, returns true if a is a subset of b.

 	
};


#endif
