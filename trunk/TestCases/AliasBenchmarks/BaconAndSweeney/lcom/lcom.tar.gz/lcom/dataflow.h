/********************************************************************************/
/* FILE: dataflow.h */
/********************************************************************************/

#ifndef DATAFLOW_H
#define DATAFLOW_H

// choose on of the following 2 options. The first should be used for debugging.
#ifdef NO_INLINE
#define INLINE 
#else
#define INLINE inline
#endif

#include "list.h"
#include "utils.h"
//#include "IntSet.h"
#include "sets.h"
#include "dfentry.h"

// Fucntion prototypes
int getDefaultPathWidth(DataType x);



/*****************************************************************************/
// Class Index
/*****************************************************************************/

class Index
{
	int value;
	int current;
	
public:
	Index(void);		// constructor 
	int nextIndex(void);
	int currentIndex(void);
	void reset(int x);
};



/*****************************************************************************/
// Class DataFlowGraph
/*****************************************************************************/


class DataFlowGraph
{
	void printList(List *x);	// call print for each element in the List.
//	void clearList(List *x);
	void clearCalls(void);
	void clearBlockList(void);
	
	boolean returnValueSet;	// was a return statement used.
	DF_Entry *returnValue;	// the return expression; may be null.
	
	char *id;
	
	Stack sstack, cstack, dstack;
	
	List blocklist;		// a list of both .CBLKs and .DBLKs	
	
	List symtbl;			// a list of .STEs
//	List calls;				// a list of .CALLS
	List params;			// a list of .PARAMs
	StringSet operatorCalls;	// a set of all the standard operators used in this dft.
	StringSet calls;			// a set of procedure calls and function calls.
	
	Index paramsIndex, paramsIndexIn, paramsIndexOut;
		
	friend class BlockEntry;
	friend class STEntry;
	friend class DF_Entry;
public:
	
	DataFlowGraph(char *procname);	// constructor
	~DataFlowGraph(void);	// destructor
	char *getProcName(void);
	
	void print(void);
	void printCalls(void);
	void printParams(void);
	void printDFST(void);
	
	void resolveIndices(void);
	
	Index blockIndex;	
	Index entryIndex;
	Index tempSymbols;
	
	void addToDBLK(DF_Entry *x);
	void addToSBLK(CtrlEntry    *x);
	void addToCBLK(DF_Entry *x);
	
	// add to the .CALLS list
	void addToCalls(char *str, boolean operator_flag = False);	
	//void addToCalls(int operationToken);	// add to the .OPCALL
	
	void addToParams(STEntry *ste, boolean in, boolean out);	
	
	void setReturn(DF_Entry *x);
	
	void pushCBLK(void);
	void pushDBLK(void);
//	void pushSBLK(void);
	void pushSBLK(boolean loopflag = False);
	void popBlockLevel(void);
	
	
	BlockEntry *peekTOS(void);
	SBlkEntry *peekTOSS(void);
	DBlkEntry *peekTODS(void);
	CBlkEntry *peekTOCS(void);
	
//	STEntry *locateConstDFST(long constval, int width);
//	DF_Entry *block_trace(STEntry *target_dfste);
//	STEntry *DFST_trace(STEntry *target_dfste);
	BlockEntry *getFirstUsableBlockEntry(void);
	DF_Entry *commSubExpr(DF_Entry *df);
//	DF_Entry *copyPropogate(STEntry *ste);
	void pruneDeadCode(void);		 
};
/*****************************************************************************/

#endif
