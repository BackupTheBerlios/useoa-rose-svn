/* FILE: DATAFLOW.C */

#include <stdio.h>
#include <stdlib.h>

#include "lconfig.h"
#ifndef __GNUC__
#include <string.h>
#endif

#include "errors.h"
#include "globals.h"
#include "blkentry.h"
#include "symtable.h"
#include "dataflow.h"

extern DataFlowGraph *CurrentDFG;

#ifdef DEBUG
#define DEBUGTHIS {if(!this)Compiler_Error("this = 0x00\n");}
#else
#define DEBUGTHIS {}
#endif

#define ENTRY_INDEX_START 100
#define BLOCK_INDEX_START   1

#ifndef lint
static char *sccsid = "@(#)dataflow.C	1.16 (University of Guelph, VLSI Dept., T. Ponzo) 93/06/09";
#endif /* lint */

/******************************************************************************/
// Class DataFlowGraph
/******************************************************************************/
DataFlowGraph::DataFlowGraph(char *pfname)
{
	id = mallocName(pfname);
	blockIndex.reset(BLOCK_INDEX_START);
	tempSymbols.reset(1);
	paramsIndex.reset(1);
	paramsIndexIn.reset(1);
	paramsIndexOut.reset(1);
	entryIndex.reset(ENTRY_INDEX_START);
	returnValue = NULL;	
	returnValueSet = False;
};

DataFlowGraph::~DataFlowGraph(void)
{
	if(id) { delete id; id = NULL; }
	params.clear();	
	symtbl.clear();	// only remove the nodes; leave the STEs in the symbol table.
	
	// do not delete the returnValue, since it is only a cross reference
	//if(returnValue)
	//{
	//	delete returnValue;
	//	returnValue = NULL;
	//}
	
	// Do not clear symtbl;
	
	clearCalls();
	clearBlockList( /* blocklist */);
};

char *
DataFlowGraph::getProcName(void)
{
	return(id);
};

// step thru the List, and delete each generic entry item, 
// as well as the List node's.

void
DataFlowGraph::clearCalls(void)
{
	calls.clear();
	operatorCalls.clear();
};

void
DataFlowGraph::clearBlockList(void)
{
	DEBUGTHIS;
	BlockEntry *z = (BlockEntry *)(blocklist.remove_rear());
	while(z)
	{
		delete z;
		z = (BlockEntry *)(blocklist.remove_rear());
	}


};

void 
DataFlowGraph::printList(List *x)
{
	DEBUGTHIS;
	DF_Entry *z;
	for(z = (DF_Entry *)(x->front()); z; z = (DF_Entry *)(x->succ()))
		z->print();
};


void 
DataFlowGraph::printDFST(void)
{
	List *crosslink = SymTbl.getCurrentCrossLink();
	
	Outfile->print(".STBL %d\n",SymTbl.getPrintCount());
	
	STEntry *ste = (STEntry *)crosslink->front();
	while(ste)
	{
		ste->print();	
		ste = (STEntry *)crosslink->succ();
	}
	Outfile->newline();

  
};

void 
DataFlowGraph::print(void)
{
	DEBUGTHIS;
	//1. print .PROC
	//2. print .PARAM
	//3. print .CALLS
	//4. print .STE
	//5. print .?BLK
	//6. print .END
	
	if(CLFlags.DeadCodePruning == True)
	{
		pruneDeadCode();	// before printing the dfg, prune any dead code.
	}
	resolveIndices();	// before printing the dfg, resolve all indices.
	
	// need to search global symbol table for this id, and find out whether 
	// this is a procedure or function or what?
	//STEntry *ste = SymTbl.lookup(id);
	
	char *str;
	if(returnValueSet)
		str = ".FUNC";
	else
		str = ".PROC";
		
	Outfile->print("%s %s\n\n",str,id);
	
	// Print sizes for blocks and data (min and max for each)
	Outfile->print(".SIZE %d %d  %d %d  %d\n\n",
							BLOCK_INDEX_START, blockIndex.currentIndex(),
							ENTRY_INDEX_START, entryIndex.currentIndex(),
							DFCount_getCount(Entry_optr));
	
	printParams();
	printCalls();
	if(returnValueSet)
	{
		Outfile->print(".RTN %d\n\n",
				(returnValue) ? returnValue->getIndex() : 0);
	}

//	printList(&symtbl);
	printDFST();
	
	// print block list.
	BlockEntry *z;
	for(z = (BlockEntry *)blocklist.front(); z; z = (BlockEntry *)blocklist.succ())
		z->print();
	
	Outfile->print(".END\n\n");
};

void 
DataFlowGraph::resolveIndices(void)
{
	// resolve the indices for the parameters
	STEntry *p;
	for(p = (STEntry *)params.front(); p; p = (STEntry *)params.succ() )
	{
		int in_index, out_index, index;
		p->param.getIndex(index, in_index, out_index);
	}
	
	// resolve indices for the dataflow symbol table.
	// - this will check that any OUT parameters are definitely set!
	List *crosslink = SymTbl.getCurrentCrossLink();
		
	STEntry *ste = (STEntry *)crosslink->front();
	while(ste)
	{
		ste->resolveIndices();	
		ste = (STEntry *)crosslink->succ();
	}

	
	// resolve indices for the block list.
	BlockEntry *z;
	
	// number the blocks in the order that they will be printed out.
	for(z = (BlockEntry *)blocklist.front(); z; z = (BlockEntry *)blocklist.succ())
	{
		if(z->isUsable())
			z->getIndex();
	}
	
	// resolve the data indices for each block.
	for(z = (BlockEntry *)blocklist.front(); z; z=(BlockEntry *)blocklist.succ())
	{
		z->resolveIndices();
	}
	
	// resolve indices for the return value.
	// (Return statements should be resolved after everything else!!)
	if(returnValueSet)
	{
		if(returnValue)
			returnValue->getIndex();
	}

};

void 
DataFlowGraph::pruneDeadCode(void)
{

	// for each parameter to the procedure, trace its dependencies
	// to prune any unnecessary code.
	STEntry *p;
	for(p = (STEntry *)params.front(); p; p = (STEntry *)params.succ() )
	{
		p->pruneDeadCode();
	}
	
	
	// trace the dependencies of the return statement
	// to prune any unnecessary code.
	if(returnValueSet)
	{
		if(returnValue)
			returnValue->pruneDeadCode();
	}


	

	// resolve indices for the block list.
///	BlockEntry *z;
	
	// number the blocks in the order that they will be printed out.
///	for(z = (BlockEntry *)blocklist.front(); z; z = (BlockEntry *)blocklist.succ())
///	{
///		if(z->isUsable())
///			z->getIndex();
///	}

	
	// Prune any unnecessary control blocks.
	BlockEntry *z;
	for(z = (BlockEntry *)blocklist.front(); z; z=(BlockEntry *)blocklist.succ())
	{
		z->pruneDeadCode();
	}
	
	// resolve indices for the return value.
	// (Return statements should be resolved after everything else!!)


};


void 
DataFlowGraph::printCalls(void)
{
	DEBUGTHIS;
	int len = calls.length();
	
	Outfile->newline();
	Outfile->print(".CALLS %3d      ",len);

	for(int i = 1; i<=len; i++)
	{
		char *s = calls(i);
		Outfile->print(" %s",s);
	}
		
	Outfile->newline();
	Outfile->newline();
	
	// now print the standard operators that were called.
	len = operatorCalls.length();
	
	Outfile->newline();
	Outfile->print(".OPCALLS %3d      ",len);
	
	for(i = 1; i<=len; i++)
	{
		char *s = operatorCalls(i);
		//char *s = operatorCalls.getItem(i);
		Outfile->print("  %s",s);
	}
	Outfile->newline();
	Outfile->newline();
	
};
void 
DataFlowGraph::addToCalls(char *name, boolean operator_flag)
{
	// insert the calls alphabetically, so that they are easy to search for.
	DEBUGTHIS;

	if(operator_flag == True)
		operatorCalls.add(name);
	else
		calls.add(name);
};

void
DataFlowGraph::printParams(void)
{
	DEBUGTHIS;
	Outfile->print(".PARAM %d\n", params.length());
	
	for(STEntry *p = (STEntry *)params.front(); p; p = (STEntry *)params.succ() )
	{
		int in_index, out_index, index;
		p->param.getIndex(index, in_index, out_index);
		
		int last_version_index = (out_index != 0) ? (p->getLastVersion())->getIndex() : 0;
		
		// print the .PARAM entries
		Outfile->print("%d %s",index,p->getName());
		
		// leave some spacing
		int len = strlen(p->getName());
		for(int i = len; i < 10; i++)
			Outfile->print(" ");
			
		Outfile->print("%2d %2d  %d\n",in_index, out_index, last_version_index);
	}

};
// keep a separate list of parameters to this data flow graph.
void
DataFlowGraph::addToParams(STEntry *ste, boolean in, boolean out)
{
	DEBUGTHIS;
	
	int index = paramsIndex.nextIndex();
	
	int inCount  = (in)  ? paramsIndexIn.nextIndex() : 0;
	int outCount = (out) ? paramsIndexOut.nextIndex() : 0;
	
	
	
	ste->param.setIndex(index, inCount, outCount);
	
	
	params.append(ste);
};

void 
DataFlowGraph::setReturn(DF_Entry *x)
{
	returnValueSet = True;
	returnValue = x;
};

BlockEntry *
DataFlowGraph::peekTOS(void)
{
	DEBUGTHIS;
	return( (BlockEntry *)blocklist.front() );
};

CBlkEntry *
DataFlowGraph::peekTOCS(void)
{
	DEBUGTHIS;
	return( (CBlkEntry *)(cstack.top()) );
};

DBlkEntry *
DataFlowGraph::peekTODS(void)
{
	DEBUGTHIS;
	return( (DBlkEntry *)(dstack.top()) );
};

SBlkEntry *
DataFlowGraph::peekTOSS(void)
{
	DEBUGTHIS;
	return( (SBlkEntry *)(sstack.top()) );
};

void
DataFlowGraph::pushCBLK(void)
{
	DEBUGTHIS;
	CBlkEntry *c = new CBlkEntry();
	SBlkEntry *s = (SBlkEntry *)sstack.top();

	// 's' is always the parent.
	if( s )
		c->setParentBlock(s);
	else
		Compiler_Error("Cannot push a CBlk without a previous SBlk.\n");	

	DBlkEntry *d = (DBlkEntry *)dstack.top();
	// 'd' is always the predecessor.
	if(d)
		c->setPredBlock(d);
	else
		Compiler_Error("Cannot push a CBlk without a previous DBlk.\n");	
		
	CtrlEntry *ce = new CtrlEntry(c);
	s->addTo(ce);
	
	cstack.push(c);
	
};

void
DataFlowGraph::pushDBLK(void)
{
	DEBUGTHIS;
	DBlkEntry *d = new DBlkEntry();
	SBlkEntry *s = (SBlkEntry *)(sstack.top());
	
	// assume that 's' is the parent, until s shows that it is unusable
	// since it only has one entry in it (in this case, ... ?).
	if( s )
		d->setParentBlock(s);
	else
		Compiler_Error("Cannot push a DBlk without a previous SBlk.\n");
	
	CtrlEntry *x = (CtrlEntry *)(s->getLastEntry());
	if(x)
		d->setPredBlock( x->getChildBlock() );
	else
		d->setPredBlock( s->getPredBlock() );
		
	// the control entry must be added only after the last entry is used.
	CtrlEntry *ce = new CtrlEntry(d);
	s->addTo(ce);
		
	dstack.push(d);
};


void
DataFlowGraph::pushSBLK(boolean loopflag)
{
	DEBUGTHIS;
	SBlkEntry *s = new SBlkEntry();
	CBlkEntry *c = (CBlkEntry *)(cstack.top());
	
	// the previous 'c' block is the parent of this 's' block.
	if(c)
		s->setParentBlock(c);
	else
		s->setParentBlock(NULL);
	
	
	// If loopflag is true, then this 's' block is part of a loop,
	// so the predecessor of this block should be the previous 
	// control block. Otherwise, the predecessor can be the previous
	// data block ( as in an if stmt.).
	if(loopflag == True)
	{
		if(c)
			s->setPredBlock(c);
		else
			s->setPredBlock(NULL);
	}
	else
	{
		// the previous 'd' block is the predecessor of this 's' block.
		DBlkEntry *d = (DBlkEntry *)(dstack.top());
		if(d)
			s->setPredBlock(d);
		else
			s->setPredBlock(NULL);
	}
	
	sstack.push(s);	
};

void
DataFlowGraph::popBlockLevel(void)
{

	DEBUGTHIS;
	BlockEntry *s = (BlockEntry *)(sstack.pop());
	if( !s )
		Compiler_Error("sstack empty!\n");

	
	int len = s->length();
	
	// len should be even since CBLKs and DBLKs added in pairs
	if(isOdd(len))
		Compiler_Error("Number of entries in SBLK is %d (should be even)\n");
		
	for(int i=0; i < (len/2); i++)
	{
		CBlkEntry *c = (CBlkEntry *)cstack.pop();
		DBlkEntry *d = (DBlkEntry *)dstack.pop();

		if(c && d)
		{
			blocklist.prepend(c);
			blocklist.prepend(d);
		}
		else
		{
			Compiler_Error("Not enough DBLK and CBLK pairs.\n");
		}
	}
	
	blocklist.prepend(s);
};


// Add an entry to the control block. If no previous control block
// exists, then add one.
void 
DataFlowGraph::addToCBLK(DF_Entry *x)
{
	DEBUGTHIS;
	BlockEntry *c = (BlockEntry *)(cstack.top());
	if(!c)
		Compiler_Error("cstack empty!\n");
	
	
	c->addTo(x);
	x->setLocalBlock(c);
//	x->setIndex( entryIndex.nextIndex() );
};

void 
DataFlowGraph::addToDBLK(DF_Entry *x)
{
	DEBUGTHIS;
	BlockEntry *d, *c;
	if(!(d = (BlockEntry *)dstack.top()))
		Compiler_Error("dstack empty!\n");

	if(!(c = (BlockEntry *)cstack.top()))
		Compiler_Error("cstack empty!\n");
		
	// An entry cannot be added to a data block after something has been added
	// to the data block's paired control block. Therefore, add a new pair of
	// data block / control block, and continue.
	
	if(!(c->empty()))
	{
		pushDBLK();
		pushCBLK();
		d = (BlockEntry *)dstack.top();
	}
	d->addTo(x);
	x->setLocalBlock(d);
//	x->setIndex( entryIndex.nextIndex() );
	
}
	
void 
DataFlowGraph::addToSBLK(CtrlEntry *x)
{
	DEBUGTHIS;
	BlockEntry *s = (BlockEntry *)sstack.top();
	if(!s)
		Compiler_Error("sstack empty!\n");
	s->addTo(x);
	x->setLocalBlock(s);
};
			
BlockEntry *
DataFlowGraph::getFirstUsableBlockEntry(void)
{
	
	// find the first usable block entry
		
	BlockEntry *b = CurrentDFG->peekTOSS();
	if(!(b->isUsable()))
	{
		b = CurrentDFG->peekTODS();
		if(!(b->isUsable()))
		{
			b = CurrentDFG->peekTOCS();
			if(!(b->isUsable()))
			{
				Compiler_Error("No usable block found for if stmt.\n");
			}
		}
	}
	return(b);		
};
	
DF_Entry *
DataFlowGraph::commSubExpr(DF_Entry *df)
{
	if(CLFlags.CommonSubExpr == True)
	{
   	DBlkEntry *dblk = peekTODS();
   	
		// only the first block is a local block
   	return(dblk->commSubExpr(df,True));	
	}
	else
		return(NULL);
};


/*****************************************************************************/
// Class Index
/*****************************************************************************/

Index::Index(void)	// constructor				
{ 
	value = 0; 
	current = 0; 
};		 

int 
Index::nextIndex(void) 		
{ 
	current = value; 
	return (value++);
};

int 
Index::currentIndex(void)		
{
	 return current; 
};

void 
Index::reset(int x)			
{ 
	value = x; 
	current = x;
};




/******************************************************************************/
