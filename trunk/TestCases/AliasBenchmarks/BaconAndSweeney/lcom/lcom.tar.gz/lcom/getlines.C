/******************************************************************************/
/* FILE : getlines.c */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#include "lconfig.h"
#include "getlines.h"
#include "utils.h"
#include "globals.h"

#define MAXFILES 5

struct line_info_S
{
	int in_use;
	int currentLine;
	FILE *fp;
	char *fn;
};

struct line_info_S sourceFile[MAXFILES];


char buffer[512];
/******************************************************************************/
// Constructor 

SourceInfo::SourceInfo(void)	// constructor
{	
	linenum = -1; 	// undefined so far
	//filenum = current file number;
};
	
SourceInfo::SourceInfo(int line)	// constructor
{	
	linenum = line; 
	//filenum = current file number;
};
	
SourceInfo::~SourceInfo(void) {};	// destructor
	
int SourceInfo::getLine(void) 		
{	return(linenum); };

void SourceInfo::setLine(int line)
{	 linenum = line; };

int SourceInfo::getFileNo(void)		
{	return(filenum); };

char *SourceInfo::getFileName(void)	
{	/* return(getFileName(filenum); */
		return("FileName?");
};	


/******************************************************************************/
int openSourceFile(char *fn)
{
	int i,fileId;
	int found = 0;	/* assume not found */
	struct line_info_S *myline;

	/* find a free source file entry */

	for(i=0;(i<MAXFILES && !found);i++)
	{
		if(!sourceFile[i].in_use)
		{
			fileId= i;
			found = 1;
		}
	}
	if(!found)
	{
		Error("Error in finding empty sourceFile structure\n");
		exit(1);
	}
	
	myline = &sourceFile[fileId];
	myline->in_use = 1;
	myline->currentLine = 0;
	myline->fp = fopen(fn,"r");

	if(!(myline->fp))
	{
		Fatal_Error("Unable to open source file '%s'.\n",fn);
		return(0);
	}
	else
	{
		myline->fn = mallocName(fn);

		yyin = myline->fp;	// set yyin for use in 'yyparse()'
		return(fileId);
	}


}
/******************************************************************************/

int closeSourceFile(int fileid)
{
	struct line_info_S *myfile;

	if(fileid >= MAXFILES || fileid < 0)
	{
	   Compiler_Error("Bad file id in closeFile(%d)\n",fileid);
	   return(0);
	}
	myfile = &sourceFile[fileid];

	fclose(myfile->fp);
	
	delete (myfile->fn);
	myfile->in_use = 0;
	myfile->currentLine = 0;
	return(0);
	


}
/******************************************************************************/
char *getFileName(int fileId)
{

	if(fileId >= MAXFILES || fileId < 0)
	{
		Compiler_Error("Bad file id in getFileName(%d)\n",fileId);
		return(NULL);
	}
	return(sourceFile[fileId].fn);
	

}
/******************************************************************************/

char *getSourceLine(struct sourceFile_S *source)
{
	static struct sourceFile_S prevSource = {-1,-1};

	struct line_info_S *myfile;
//	int scanCount;
	int i;
	char ch;

	if(source->fileId >= MAXFILES || source->fileId < 0)
	{
		Compiler_Error("Bad file id in closeFile(%d)\n",source->fileId);
		return(NULL);
	}

	if(source->fileId == prevSource.fileId && 
		source->lineNumber == prevSource.lineNumber)
	{
		return("..");
	}
	else
	{
		prevSource = *source;
	}

	myfile = &sourceFile[source->fileId];

	/* if current line has already scanned past the line number to look for,
		then reopen the file */
	if(myfile->currentLine > source->lineNumber)
	{
		rewind(myfile->fp);
		myfile->currentLine = 0;
	}

	/* keep reading in lines until we get to the line we are looking for */

	while(!feof(myfile->fp) && ( source->lineNumber > myfile->currentLine))
	{
		for(	ch = getc(myfile->fp),i=0;
			ch != '\n';
			ch = getc(myfile->fp),i++)
		{
			buffer[i] = ch;
		}

		buffer[i] = '\0';
	/*	scanCount = fscanf(myfile->fp,"%[^\n]\n",buffer);*/
		myfile->currentLine ++;


	}
	if( source->lineNumber != myfile->currentLine)
		buffer[0] = '\0';

	return(buffer);


}
/******************************************************************************/
void initSourceLineInfo(void)
{
	int i;
	for(i=0;i<MAXFILES;i++)
		sourceFile[i].in_use = 0;


}

/******************************************************************************/

