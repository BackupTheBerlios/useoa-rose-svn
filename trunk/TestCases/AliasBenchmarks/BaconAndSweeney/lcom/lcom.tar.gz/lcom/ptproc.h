
// FILE: PTPROC.H - PARSE TREE PROCEDURE NODES


#ifndef PTPROC_H 
#define PTPROC_H


#include "tokens.h"
#include "boolean.h"
#include "dataflow.h"

#ifdef __TURBOC__
#include "dfentry.h"
#endif

//-----------------------------------------------------------------------
// The following classes are defined in this file, in this order.
//
class PTProcDecl;		// base class
//class PTFuncDecl;
class PTLocalDecls;
class PT_ProcCall;
class PT_Return;

//-----------------------------------------------------------------------
// Other parse tree classes derived from PTNode, but defined elsewhere.
class PTIdent;

//-----------------------------------------------------------------------
// Function prototypes

//-----------------------------------------------------------------------

class PTLocalDecls : public PTNode
{
	DataType currentDataType;

	PTIdent *idList;
	
	boolean isParam;	// these two booleans are mutually exclusive.
	boolean isConst;
	PTNode *const_expr;
	
	boolean readaccess, writeaccess;
	
public:
	PTLocalDecls(int lineno = 0);
	~PTLocalDecls(void);
	VIRTUAL void dumpTree(void);	
	
	void setDataType(DataType dt);
	void setIdentList(PTIdent *id);
	void setConstList(PTIdent *id, PTNode *expr);
	
	void setParameter(boolean param = False);
	void setAccessMode(boolean readable, boolean writeable);
	void setAccessMode(int rwmode);				

	VIRTUAL void semanticCheck(void);
/////////////////	void calcLvalueList(List *list);
	VIRTUAL DF_Entry *dataflow(int message = 0); 
	void cleanUp(void);

	void start_args(void);
	boolean get_arg(int count,int &readStatus, int &writeStatus, DataType &dt);
	char *get_arg_id(int count);
	
	VIRTUAL PTNode *make_clone(int message = 0);
};

//-----------------------------------------------------------------------

class PTProcDecl : public PTNode
{

	PTLocalDecls *params, *locals;
	PTStmt *stmts;
	PTIdent *procname;
	List lvalueList;
	
	PTNode *returnExpr;
	DataType returnDataType;
	boolean returnStmtFound;
	
	boolean functionMode;
	PTProcDecl *oldPF;
	
	int internalErrorCount;
	
public:

	PTProcDecl(	PTIdent *id,
						PTLocalDecls *parms,
						PTLocalDecls *loc,
						PTStmt *st,
						int start_lineno);		// constructor
	~PTProcDecl(void);					// destuctor
	VIRTUAL void printMe(void);
	VIRTUAL void dumpTree(void);
	VIRTUAL void semanticCheck(void);
	VIRTUAL DF_Entry *dataflow(int message = 0); 
//	void cleanUp(void);
///////////	List *getLvalueList(void);
	boolean get_arg(int count,int &readStatus, int &writeStatus, DataType &dt);
//	void setFunctionMode(DataType dt, PTNode *retExpr);
	void setFunctionMode(DataType dt);
	boolean isFunction(void);
	boolean isProcedure(void);
	
	void setReturnFound(void);
	VIRTUAL PTNode *make_clone(int message = 0);
	
	void compile(int message = 0);
	void getInlineCode(PTNodePtr *arglist, int argcount,
							 PTNodePtr *inlineCode, PTNodePtr *returnCode);
							 
	int getInternalErrorCount(void);
	void setInternalErrorCount(int count);
};

//-----------------------------------------------------------------------
class PT_ProcCall : public PTNode
{
	char *ident;
//	PTNode *exprlist;
	PTNodePtr *inputlist, *outputlist;
	int argcount;
	
	PTProcDecl *myprocdecl;
	boolean functionMode;
	boolean inlineFlag;
	PTNode *inlineCode, *returnCode;	// returnCode applies to functions only.
	
public:
	PT_ProcCall(char *id, boolean inlineflag, int lineno);
	~PT_ProcCall(void);
	void setExprList(PTNode *exprlst);
	void setExprArray(PTNodePtr *exprlst, int count);
	VIRTUAL void semanticCheck(void);
	VIRTUAL DF_Entry * dataflow(int message = 0);
	void setFunctionMode(void);	//if set, this is actually a function call.
	boolean isFunction(void);
	boolean isProcedure(void);
	VIRTUAL PTNode *make_clone(int message = 0);
	VIRTUAL void dumpTree(void);
	VIRTUAL boolean testProcArg(boolean readstat, boolean writestat);
};

//-----------------------------------------------------------------------
class PT_Return : public PTNode
{
	PTNode *expr;
public:
	PT_Return(PTNode *ret_expr, int lineno = 0);
	~PT_Return(void);
	
	VIRTUAL void dumpTree(void);
	DF_Entry *dataflow(int message = 0); 
	void semanticCheck(void);
	VIRTUAL PTNode *make_clone(int message = 0);
	VIRTUAL PTNode *getChild(int count, boolean unlinkflag);
};


//-----------------------------------------------------------------------

#endif
