// FILE: ERRORS.H
// ERROR CODES, ERROR DESCRIPTIONS, and ERROR FUNCTIONS

#ifndef ERRORS_H
#define ERRORS_H

#include <stdarg.h>

/////// Error functions

extern int ErrorCount;
extern int DuplicateErrorCount; // used for parser debugging.
extern int WarningCount;
//extern int MaxErrorsAllowed;


void Compiler_Error(char *format, ...);

void Fatal_Error(char *format, ...);

void Error(char *format, ...);

void Error(int linenum, char *format, ...);

void Warning(char *format, ...);

void Warning(int linenum, char *format, ...);

/////// Debugging functions

void debug(char *format, ...);

//#define DEBUG if(FlagDebug)debug
//#define DEBUG debug


#endif
