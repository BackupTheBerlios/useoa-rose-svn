// globals.c

#include <stdlib.h>
#include "lconfig.h"
#include "globals.h"

struct CommandLine_S
{
	boolean flag;
	const char *description;


};

CommandLineFlags::CommandLineFlags(void)
{
	// initialize all flags with default values.
	
	
	 TokenStream = False;	/* -t */
	 Debug       = False;	/* -d */
	 YaccDebug	  = False;	/* -y */
	 NewHashSize = 0;	/* -hx   where x is a prime number */
	 WarningsSuppress = False; 	/* -w */
	 DumpParseTree = False;		/* -p */
	 QuietMode = False;		/* -q */
	 CommonSubExpr = True; 		/* +c */
	 CopyPropogation = True;	/* +e */
	 DefinitelySet = True;		/* +s */
	 DeadCodePruning = True;	/* +f */
	 InlineCode = True;		/* +i */
	 N_AryOperators = True;		/* +n */
	 LogicSequential = True;	/* +l */
	 FrequencyReduction = True;	/* +g */
	 OptimizeAll = True;		/* +-o */
	 count = 0;

};

void
CommandLineFlags::setFlag(char *s)
{
	// s[0] has already been shown to be either '-' or '+' from main,
	// but check anyways.
	char flagchar = s[0];
	if(flagchar != '-' && flagchar != '+')
	{
		Compiler_Error("Bad command line option '%s'\n",s);
	}
	boolean flag = (flagchar == '-') ? False : True;
	
	count ++;

	switch(s[1])
	{
	case 'c':	// +-c
		CommonSubExpr = flag;
		break;
		
	case 'e':	// +-e
		CopyPropogation = flag;
		break;
		
	case 'h':	// -h211
		NewHashSize = abs( atoi(s+2) );
		break;
		
	case 't':	// +-t	
		TokenStream = flag;
		break;

	case 'd':	// +-d
		Debug = flag;
		break;
	
	case 's':	// +-s
		DefinitelySet = flag;
		break;
		
	case 'y':	// +-y
		YaccDebug = flag;
		break;
	
	case 'w':	// +-w
		WarningsSuppress = flag;
		break;
	case 'p':	// +-p
		DumpParseTree = flag;
		break;
	
	case 'f':	// +-f
		DeadCodePruning = flag;
		break;
	
	case 'i':	// +-i
		InlineCode = flag;
		break;
	
	case 'l':	// +-l
		LogicSequential = flag;
		break;
		
	case 'n':	// +-n
		N_AryOperators = flag;
		break;

	case 'g':	// +-g
		FrequencyReduction = flag;
		break;

	case 'o':	// +-o	(Turn on/off all optimizations at once)
		CommonSubExpr = flag;
		CopyPropogation = flag;
		DeadCodePruning = flag;
		InlineCode = flag;
		N_AryOperators = flag;
		FrequencyReduction = flag;
		OptimizeAll = flag;
		break;

	case 'q':	// +-q (quiet mode)
		QuietMode = flag;
		break;
		
	default:
		Error("Unknown Command Line Option `%s'\n",s);
		break;
	}
}; 

#define ON_OFF(x) (x==True?" [on]":" [off]")

#define PRINT_USAGE(code,mesg1,mesg2)	{\
		fprintf(stderr,"\t%s\t%s%s.\n",code,mesg1,mesg2);}


void 
CommandLineFlags::displayUsage(char *progname)
{
	fprintf(stderr,
		"Usage: %s [flags] sourcefile \n",
				progname);
	fprintf(stderr,"Flags: [default]\n");
	fprintf(stderr,"Optimization Flags:\n");
	PRINT_USAGE("+-c","Common Subexpression Elimination",ON_OFF(CommonSubExpr));
	PRINT_USAGE("+-e","Copy Propogation",		ON_OFF(CopyPropogation));
	PRINT_USAGE("+-s","Definitely Set",			ON_OFF(DefinitelySet));
	PRINT_USAGE("+-f","Prune Any Dead Code",	ON_OFF(DeadCodePruning));
	PRINT_USAGE("+-i","Allow Inline Code",		ON_OFF(InlineCode));
	PRINT_USAGE("+-n","Allow N-ary Operators",ON_OFF(N_AryOperators));
	PRINT_USAGE("+-l","Logic Sequential",		ON_OFF(LogicSequential));
	PRINT_USAGE("+-o","All Optimizations",		ON_OFF(OptimizeAll));
	
	fprintf(stderr,"\nOther Options:\n");
	PRINT_USAGE("+-w","Suppress warnings",		ON_OFF(WarningsSuppress));
	PRINT_USAGE("+-d","Debugging Mode",			ON_OFF(Debug));
	PRINT_USAGE("+-t","Show stream of tokens",ON_OFF(TokenStream));
	PRINT_USAGE("+-y","Yacc debugging on",		ON_OFF(YaccDebug));
	PRINT_USAGE("+-p","Display the Parse tree",ON_OFF(DumpParseTree));
	PRINT_USAGE("+-q","Quiet Mode (informational messages)",ON_OFF(QuietMode));
	PRINT_USAGE("-hX","Define hash table size <X>","");
//	PRINT_USAGE("+- ","",ON_OFF( ));
	
}
