// FILE : LIST.C

#include "list.h"


list_node::list_node (void)
{
   item = predecessor = successor = NULL;
};

List::List(void)
{
	head = tail = current = NULL;
}

list_node *
List::locateNode(void *item)
/*
   this function locates a specific 'list_node' in a List.
   Argument: a pointer to the task incidence to locate
   Returns:  a pointer to the 'list_node' structure if found or NULL if not
             found.
*/
{
   list_node *thisNode = head;
   while (thisNode && thisNode->item != item)
      thisNode = thisNode->successor;
   return(current = thisNode);
}

void *
List::get_current(void)
{
   return (current ? current->item : NULL);
}

void *
List::pred(void)
{
   if (current)
      if (current->predecessor)
      {
         current = current->predecessor;
         return(current->item);
      }
   return(0);
}

void *
List::succ(void)
{
   if (current)
      if (current->successor)
      {
         current = current->successor;
         return(current->item);
      }
   return(0);
}

void *
List::rear(void)
{
   if (tail)
   {
      current = tail;
      return(tail->item);
   }
   else
      return(0);
}

void *
List::front(void)
{
   if (head)
   {
      current = head;
      return(head->item);
   }
   else
      return(0);
}
// deletes and returns the item stored at the head of the List.
void * 
List::remove_front(void)   
{
   list_node *temp = head;
   if (head)
   {
      head = current = head->successor;
      if (head == NULL)
         tail = NULL;
      void *item = temp->item;
      delete temp;
      return(item);
   }
   return(0); // List is empty;
}


// delete the first element without returning it.
unsigned 
List::del_front(void)   
{
   list_node *temp = head;
   if (head)
   {
      head = current = head->successor;
      if (head == NULL)
         tail = NULL;
      delete temp;
      return(1);
   }
   return(0); // List is empty;
}

// deletes and returns the item stored at the head of the List.
void * 
List::remove_rear(void)
{
   list_node *temp = tail;
   if (tail)
   {
      tail = current = tail->predecessor;
      if (tail == NULL)
         head = NULL;
      void *item = temp->item;
      delete temp;
      return(item);
   }
   return(0); // List is empty;
}

// delete the last element without returning it.
unsigned 
List::del_rear(void)
{
   list_node *temp = tail;
   if (tail)
   {
      tail = current = tail->predecessor;
      if (tail == NULL)
         head = NULL;
      delete temp;
      return(1);
   }
   return(0); // List is empty;
}

unsigned 
List::prepend(void *item)
/*
   add a 'list_node' to the front of the List;
   argument: a void pointer to a user structure;
   returns: 0 if not enough memory or 'item' already present in List,
   else returns 1;
*/
{
   list_node *newNode = new list_node();

   if (newNode == NULL)
   {
      fprintf(stderr,"List: prepend: Out of Memory!");
      exit(1);
   }

   newNode->item  = item;
   newNode->predecessor = NULL;
   newNode->successor = head;
   if (head)
      head->predecessor = newNode;
   head    = newNode;
   current = head;
   if (!tail)   // is this the first list_node in the List?
      tail = current;
   return 1;
}


unsigned 
List::append(void *item)
/*
   add a 'list_node' to the back of the List;
   argument: a void pointer to a user structure;
   returns: 0 if not enough memory or 'item' already present in List,
   else returns 1;
*/
{
   list_node *newNode;

   if ((newNode = new list_node) == NULL)
   {
      fprintf(stderr,"List: append: Out of Memory!");
      exit(1);
   }
   newNode->item  = item;
   newNode->predecessor = tail;
   newNode->successor = NULL;
   if (tail)
      tail->successor = newNode;
   tail    = newNode;
   current = tail;
   if (!head)   // is this the first list_node in the List?
      head = current;
   return(1);
}

unsigned 
List::ins_before(void *item)
/*
   insert a 'list_node' before the 'current' list_node in the List;
   argument: a void pointer to a user structure;
   returns: 0 if not enough memor, else returns 1;
*/
{
   list_node *newNode;

   if (!current || (current == head))
      return(prepend(item));

   if ((newNode = new list_node) == NULL)
   {
      fprintf(stderr,"List: insertNext: Out of Memory!");
      exit(1);
   }
   newNode->item = item;

   if (current->predecessor)
      current->predecessor->successor = newNode;
   newNode->predecessor = current->predecessor;
   newNode->successor = current;
   current->predecessor = newNode;
   current = newNode;

   return(1);
}

unsigned 
List::ins_after(void *item)
/*
   insert a 'list_node' immediately after the 'current' list_node in the List;
   argument: a void pointer to a user structure;
   returns: 0 if not enough memory,  else returns 1;
*/
{
   list_node *newNode;

   if (!current || (current == tail))
      return(append( item ));

   if ((newNode = new list_node) == NULL)
   {
      fprintf(stderr,"List: insertPrev: Out of Memory!");
      exit(1);
   }
   newNode->item = item;

   newNode->predecessor = current;
   newNode->successor = current->successor;
   if (current->successor)
      current->successor->predecessor = newNode;
   current->successor = newNode;
   current = newNode;

   return 1;
}

unsigned 
List::del(void *item)
/*
   remove a list_node from the List,
   can be from anywhere in the List.

   Argument: the item contents of the list_node to be removed.
   Returns:  0 if list_node is not found.
*/
{
   list_node *thisNode = locateNode(item);
   if (thisNode == NULL)
      return (0);
   if (thisNode == head)
   {
      if (thisNode != tail)
      {
         head = thisNode->successor;
         head->predecessor = NULL;
         current = head;
      }
      else
         head = tail = current = NULL;
   }
   else
      if (thisNode == tail)
         {
            tail = thisNode->predecessor;
            tail->successor = NULL;
            current = tail;
         }

      else
      {
         current = thisNode->predecessor;
         thisNode->predecessor->successor = thisNode->successor;
         thisNode->successor->predecessor = thisNode->predecessor;
      }

   delete thisNode;
   return(1);
}

unsigned 
List::del(void)
/*
   remove 'current' list_node from the List,

   Argument: None.
   Returns:  0 if list_node is not found.
*/
{
   list_node *thisNode = current;
   if (thisNode == NULL)
      return (0);
   if (thisNode == head)
   {
      if (thisNode != tail)
      {
         current = head = thisNode->successor;
         head->predecessor = NULL;
      }
      else
         head = tail = current = NULL;
   }
   else
   if (thisNode == tail)
      {
         current = tail = thisNode->predecessor;
         tail->successor = NULL;
      }
   else
   {
      thisNode->predecessor->successor = thisNode->successor;
      current = thisNode->predecessor;
      thisNode->successor->predecessor = thisNode->predecessor;
   }
   delete thisNode;
   return(1);
}


List::~List()
{
   clear();
}

void List::dump_List(void)
{
    char string[80];

    list_node *temp;
    temp = head;
    sprintf(string,"head = %p; tail = %p; current = %p;\n", head, tail,
       current);
    //ttyString(string);
    printf(string);
    for(; temp;)
    {
       sprintf(string,"list_node %p: pred = %p; succ = %p; item = %p\n",
          temp, temp->predecessor, temp->successor, temp->item);
       //ttyString(string);
       printf(string);
       temp = temp->successor;
       if (temp == head)
          break;
    }
   //ttyString("\n\r");
   printf("\n");
}
int
List::length(void)   // the number of items in this List.
{
   int i = 0;
	void *n = front();
	while(n)
	{
		n = succ();
		i++;
	}
	return(i);
}


// place all list_nodes from List x to the end of this List,
// simultaneously emptying List x.

void
List::join(List *x)
{
	void *xn = x->remove_front();
	while(xn)
	{
		append(xn);
		xn = x->remove_front();
	};

};

int
List::empty(void)
{
   return( head ? 0 : 1);
};

void 
List::clear(void)  // clear all items from the List.
{
   list_node *temp;

   while (tail)
   {
      temp = tail;
      tail = tail->predecessor;
      delete temp;
   };
   head = tail = current = NULL;
   
};             


// implement a simple bubble sort with a pointer to a comparison
// function setup by the user.
// (similar to qsort())

// return values expected from comparison function
// < 0 if *elem1  < *elem2
// = 0 if *elem1 == *elem2
// > 0 if *elem1  > *elem2 // only exchange in this case


void List::sort(int(*fcmp)(const void *, const void *))
{
	int sorted = 0;
	int numPasses = 0;

	while(!sorted)
   {
      sorted = 1;    // assume sorted for now

      list_node *thisNode = head;
      list_node *succNode = thisNode->successor;

      while(thisNode && succNode)
      {
         if(fcmp(thisNode->item, succNode->item) > 0 )
         {
            //  swap the 2 records

            void *temp = thisNode->item;
            thisNode->item = succNode->item;
            succNode->item = temp;

            sorted = 0;    // obviously not sorted
         }

         thisNode = succNode;
         succNode = succNode->successor;

      }/* end while */

      numPasses ++;

   }/* end while */
};
// A Stack and a Queue are both a restricted type of List,
// and should not use List as its base class to avoid access
// to the object thru the public methods in List that do not
// pertain to Stack and Queue (ie, append(), getCurrent() , etc). 

Stack::Stack(void){ /* do nothing */};    // constructor
Stack::~Stack(void){ /* do nothing */};      // destructor
      
void Stack::push(void *x) { s.prepend(x); };
         /* pushes x onto the stack */
         
void* Stack::pop(void) { return s.remove_front(); };
         /* pops and returns top of stack */

int Stack::empty(void) { return s.empty(); };
         /* returns true if the stack is empty */

int Stack::full(void) { return(0); };
         /* never full */

int Stack::length(void) { return s.length(); }; 
         /* returns current number of elements on the stack */

void* Stack::top(void)  { return s.front(); };
         /* returns reference to the top of stack */
         
void Stack::del_top(void) { s.del_front() ; };
         /* pops, but does not return the top of stack */
         
void Stack::clear(void) { s.clear(); };
         /* remove all elements from the stack */



Queue::Queue(void){ /* do nothing */};    // constructor
Queue::~Queue(void){ /* do nothing */};      // destructor
      
void Queue::enq(void *x) { q.prepend(x); };
         /*enqueues x on Queue q */
         
void* Queue::deq(void) { return q.remove_front(); };
         /* pops and returns top of stack */

int Queue::empty(void) { return q.empty(); };
         /* returns true if the Queue is empty */

int Queue::full(void) { return(0); };
         /* never full */

int Queue::length(void) { return q.length(); }; 
         /* returns current number of elements in the Queue */

void* Queue::front(void)   { return q.front(); };
         /* returns reference to the top of stack */
         
void Queue::del_front(void) { q.del_front() ; };
         /* pops, but does not return the top of stack */
         
void Queue::clear(void) { q.clear(); };
         /* remove all elements from the stack */
