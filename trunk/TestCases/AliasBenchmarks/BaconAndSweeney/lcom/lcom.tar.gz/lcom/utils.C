/* FILE : utils.c              Utility functions */

#include "ptnode.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>


#include "utils.h"
#include "errors.h"
#include "globals.h"

/******************************************************************************/
//char *mallocName(char *name)
// Allocate enough space for the string 'char *name'.
/******************************************************************************/
char *mallocName(char *name)
{
	char *temp = new char[strlen(name) + 1];
	strcpy(temp,name);
	
	return(temp);	
}

/******************************************************************************/
//char *mallocName(char *name, char *suffix)
// Allocate enough space for the string 'char *name', and the 
// 'char *suffix' (if it exists).
/******************************************************************************/
char *mallocName(char *name, char *suffix)
{
	char *temp;

	temp = new char[strlen(name) + strlen(suffix) + 1];
	strcpy(temp,name);
	strcat(temp,suffix);
	
	return(temp);	
}
/******************************************************************************/
//char *mallocName(char *name, int counter = -1)
// Allocate enough space for the string 'char *name'. 
// If counter has a non-negative value, then concatenate the numbered
// string to the end of the name (used in creating temporary symbols).
/******************************************************************************/
char *mallocName(char *prefix, int counter)
{
	char buffer[20]; // no integer should be longer than this ?
	
	sprintf(buffer,"%d",counter);
	char *temp = new char[strlen(prefix) + strlen(buffer) + 1];
	sprintf(temp,"%s%s",prefix,buffer);
	return(temp);	
}


/******************************************************************************/
//char *mallocNameTemp(char *prefix)
// Allocate enough space for the string 'char *prefix' with the suffix
// being a unique integer determined in a sequence by TempCounter.
// If prefix is "" then use "_T" as the standard prefix.
/******************************************************************************/
static unsigned int TempCounter = 1;

char *mallocNameTemp(char *prefix)
{
	char buffer[20]; // no integer should be longer than this ?
	char *name;
	int y = 0;
	for(int x = 0; x < 5; x++)
	{
		y = y + x;
	}
	if(strlen(prefix) == 0)
		name = "_T";
	else
		name = prefix;
	//name = (strlen(prefix) == 0) ? "_T" : prefix;
	sprintf(buffer,"%d",TempCounter++);
	char *temp = new char[strlen(name) + strlen(buffer) + 1];
	sprintf(temp,"%s%s",name,buffer);
	return(temp);	
}


OutputFile::OutputFile(char *filename)
{
	fn = filename;
	fp = fopen(fn,"w");
};

OutputFile::OutputFile(FILE *fileptr)
{
	fp = fileptr;
	if(!fp)
		Compiler_Error("Bad FILE pointer\n");
	
};

OutputFile::~OutputFile(void)
{
	delete fn;
	fclose(fp);
};

int
OutputFile::fileOK(void)
{
	return( fp ? 1 : 0 );
};

void
OutputFile::close(void)
{
	if(fp) fclose(fp);
	fp = 0;
};
	
void
OutputFile::newline(void)
{
	putc('\n',fp);
	
	if(CLFlags.Debug)
		putc('\n',stdout); 
};

void
OutputFile::print(char *format, ...)
{
	
	va_list argptr;
	
	va_start(argptr, format);
	
	vfprintf(fp,format, argptr);
	
	if(CLFlags.Debug)
		vprintf(format,argptr);
	
	va_end(argptr);

};

#define COMMENT "## "

void
OutputFile::comment(char *format, ...)
{

	va_list argptr;
	
	va_start(argptr, format);
	
	fprintf(fp,COMMENT);	
	vfprintf(fp,format, argptr);
	
	// for debugging
	if(CLFlags.Debug)
	{
		printf(COMMENT);
		vprintf(format,argptr);
	}
	
	va_end(argptr);
	

};

/******************************************************************************/

GarbageCollector::GarbageCollector(void)		// constructor
{	
	/* don't do anything special here */ 
};

GarbageCollector::~GarbageCollector(void)	// destructor
{
	clean_it_up();
};

void 
GarbageCollector::add(PTNode *x)
{	
	pt.append(x);
};

void 
GarbageCollector::add(DF_Entry *x)
{	
	df.append(x);
};

void 
GarbageCollector::clean_it_up(void)
{
	PTNode *p;
	while(p = (PTNode *)pt.remove_front())
	{
		delete p;
	}
	
	DF_Entry *d;
	while(d = (DF_Entry *)df.remove_front())
	{
		delete d;
	}
	
};


/******************************************************************************/
