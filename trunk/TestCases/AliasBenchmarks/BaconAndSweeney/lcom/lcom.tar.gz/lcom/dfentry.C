
/* FILE: DFENTRY.C */

#include <stdio.h>
#include <stdlib.h>
#include "lconfig.h"
#include "errors.h"
#include "globals.h"
#include "blkentry.h"
#include "dfentry.h"
#include "build.h"

extern DataFlowGraph *CurrentDFG;

#ifndef lint
static char *sccsid = "@(#)dfentry.C	1.19 (University of Guelph, VLSI Dept.) 93/10/22";
#endif /* lint */

//-------------------------------------------------------------------------
// Each class listed in this file is shown below, in order of use.
//-------------------------------------------------------------------------
// Class DF_Entry;
// Class OptrEntry;
// Class OptrUnaryEntry;
// Class OptrAssignEntry;
// Class OptrProcEntry;
// Class OpndEntry;
// Class IfEntry;
// Class MergeEntry;
// Class LoopMergeEntry;
// Class ParEntry;
// Class CtrlEntry;

/******************************************************************************/
/* Function prototypes */
boolean equivalentOpnds(DF_Entry *opnd1, DF_Entry *opnd2);

/******************************************************************************/
// function getDefaultPathWidth();
/******************************************************************************/

int getDefaultPathWidth(DataType x)
{
	int w = 0;
	switch(x)
	{
		case Data_int:				w = 32;		break;
		case Data_bit:				w =  1;		break;
		case Data_real:			w = 64;		break;
		case Data_generic:		w = 32;		break;
		default:
			Compiler_Error("Unknown datatype\n");
			break;
	}	
	return(w);
};	
/******************************************************************************/
OpndEntry *storeOptrInTempOpnd(OptrEntry *optr, int stepnum, char *prefix);

/******************************************************************************/
static long DATAFLOW_COUNT[NUM_ENTRY_TYPES];

long DFCount_getCount(EntryType x)
{
	return(DATAFLOW_COUNT[x]);
};

void DFCount_reset(EntryType x)
{
	DATAFLOW_COUNT[x] = 0L;
};

void DFCount_resetAll(void)
{
	for(int i=0; i<NUM_ENTRY_TYPES; i++)
	{
		DATAFLOW_COUNT[i] = 0;
	}

};

void DFCount_increment(EntryType x)
{
	DATAFLOW_COUNT[x] += 1;
};


/******************************************************************************/
// Class DF_Entry
/******************************************************************************/

DF_Entry::DF_Entry(EntryType t, int line_no)
{
	index = -1;
	entryType = t;
	dfg = CurrentDFG;
	resolvedFlag = False;	// set to True after being resolved.
//	DFCount_increment(t);	// Increment the number of types `t`.
	sourceinfo.setLine(line_no);			// copy the source information!
	
	// if the flag is TRUE, then assume this is dead code, until proven false.
	// if the flag is FALSE, then this cannot be dead code.
	deadCodeFlag = CLFlags.DeadCodePruning;		
	
	mylocalblock = NULL;
};

DF_Entry::~DF_Entry(void)
{
	/* only need to define this as a virtual destructor, so that
		the classes derived from this class can implement their
		own destructors, and have them used when the data type
		of the object to be deleted is only the DF_Entry().
	*/
};

int 
DF_Entry::getIndex(void)
{
	if((index == (-1)) && (deadCodeFlag == False))
		index = CurrentDFG->entryIndex.nextIndex();
//		index = dfg->entryIndex.nextIndex();
	return(index);
};

EntryType 
DF_Entry::getType(void)
{ 
	return(entryType);
};

void 
DF_Entry::setIndex(int i)	
{ 
	index = i; 
};

	
void 
DF_Entry::print(void)
{
	Compiler_Error("Virtual function DF_Entry::print() called!\n");
};

void 
DF_Entry::resolveIndices(void)
{
	Compiler_Error("Virtual function DF_Entry::resolveIndices() called!\n");
};

void 
DF_Entry::setSourceList(DF_Entry *x, int paramCount)
{
	Compiler_Error("Virtual function DF_Entry::setSourceList() called!\n");

};

//boolean
//DF_Entry::isUsable(void)
//{
//	return(True);	// assume True unless a specific block has another reason.
//};

VIRTUAL DataType
DF_Entry::getDataType(void)
{
		Compiler_Error("Virtual call to DF_Entry::getDataType().\n");
		return(Data_int);
};

VIRTUAL int
DF_Entry::getPathWidth(void)
{
		Compiler_Error("Virtual call to DF_Entry::getPathWidth().\n");
		return(0);
};

VIRTUAL boolean
DF_Entry::isDefinitelySet(boolean printFlag)
{
	Compiler_Error("Virtual call to DF_Entry::isDefinitelySet()\n");
	return(False);
};

char *
DF_Entry::getName(void)
{
//	if(dfste)
//		return(dfste->getName());
//	else
		return("Unknown?");
};

VIRTUAL DF_Entry *
DF_Entry::block_trace(STEntry *ste, boolean searchPred)
{
	Compiler_Error("Virtual call to DF_Entry::block_trace()\n");
	return(NULL);
};

VIRTUAL DF_Entry *
DF_Entry::commSubExpr(DF_Entry *df, boolean localBlock)
{
	return(NULL);
};

VIRTUAL DF_Entry *
DF_Entry::copyPropogate(void)
{
	Compiler_Error("Virtual call to DF_Entry::copyPropogate()\n");
	return(NULL);
};

VIRTUAL boolean
DF_Entry::isConstant(void)
{
	return(False);
};

VIRTUAL void
DF_Entry::appendMergePt(DF_Entry *x)
{
	Compiler_Error("Virtual call to DF_Entry::appendMergePt()\n");
};

VIRTUAL void
DF_Entry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
};

VIRTUAL boolean
DF_Entry::fixedTimeExecution(void)
{
	return(True);
};

void 
DF_Entry::setLocalBlock(BlockEntry *block)
{
	mylocalblock = block;
};

VIRTUAL DF_Entry *
DF_Entry::getRealSource(void)
{
	Compiler_Error("Virtual call to DF_Entry::getRealSource()\n");
	return(NULL);
};

/******************************************************************************/
// Class OptrEntry
//
// Declarations:
//		List arglist;	// list of sources for this operation.
//		char *id;
/******************************************************************************/
	
OptrEntry::OptrEntry(int opToken, int line_no) 
	: DF_Entry(Entry_optr, line_no)  // constructor
{
	operationToken = opToken;
	
	// try to get the string, but do not flag an error
	// if the token is not actually a binary operation.
	// Derived classes will assign there own strings.
	operationStr = getBinOptrStr(operationToken,False);
};

OptrEntry::~OptrEntry(void)	// destructor
{
	arglist.clear();
};

char *
OptrEntry::getId(void)
{
	if(operationStr == NULL)
		operationStr = getBinOptrStr(operationToken,True);
	return(operationStr);
};

void 
OptrEntry::print(void)
{
	if(deadCodeFlag == True)
		return;
		
	Outfile->print(".OPTR %4d %s %4d",getIndex(),getId(),arglist.length());
	
	DF_Entry *x;
	for(x = (DF_Entry *) arglist.front(); x; x=(DF_Entry *)arglist.succ())
	{
		Outfile->print(" %d",x->getIndex());
	}
	Outfile->newline();
	
	for(x = (DF_Entry *) results.front(); x; x=(DF_Entry *)results.succ())
	{
		x->print();
	}
};

void
OptrEntry::resolveIndices(void)
{
	if(!resolvedFlag && (deadCodeFlag == False))
	{
		// get the indices for anything that feeds into this operator.
		DF_Entry *x; 
		for(x = (DF_Entry *)arglist.front(); x; x=(DF_Entry *)arglist.succ())
		{
			if(x->isDefinitelySet(False) == False)
				Error(sourceinfo.getLine(),"Expression not definitely set!\n");
			x->getIndex();
		}
		
		// get the index for this entry.
		getIndex();		
		
		// get the indices for anything that this operator feeds into.
		for(x = (DF_Entry *)results.front(); x; x=(DF_Entry *)results.succ())
		{
			x->resolveIndices();
		}
		
		CurrentDFG->addToCalls(getId(),True);	// add to the operator list.
		
		DFCount_increment(entryType);	// Increment the number operations
		
		resolvedFlag = True;
	}
};

void 
OptrEntry::setSourceList(DF_Entry *opnd, int paramCount)
{
	if(isCommutativeOptr(operationToken) && opnd->isConstant())
		arglist.prepend(opnd);
	else
		arglist.append(opnd);
};

void 
OptrEntry::setResultsList(DF_Entry *opnd)
{
	results.append(opnd);
};


VIRTUAL DataType
OptrEntry::getDataType(void)
{
	return(datatype);
};

VIRTUAL int
OptrEntry::getPathWidth(void)
{
	return(pathwidth);
};


void
OptrEntry::setResultType(DataType dt, int pathw)
{
	datatype = dt;
	pathwidth = pathw;
};

VIRTUAL boolean
OptrEntry::isDefinitelySet(boolean printFlag)
{
	boolean flag = True;
	if(CLFlags.DefinitelySet)
	{
		DF_Entry *x =(DF_Entry*)arglist.front(); 
		while(x && (flag==True))
		{
			flag = x->isDefinitelySet(printFlag);
			x=(DF_Entry *)arglist.succ();
		}
	}
	return(flag);
};

VIRTUAL DF_Entry *
OptrEntry::block_trace(STEntry *ste, boolean searchPred)
{
	// check thru the operands assigned from this operation.
	DF_Entry *x = (DF_Entry *)results.front();
	while(x)
	{
		DF_Entry *y = x->block_trace(ste);
		if(y)
		{
			return(y);
		}
		x = (DF_Entry *)results.succ();
	};
	return(NULL);
};

// Return a pointer to a common subexpression, or
// return NULL if no expression is in common.

VIRTUAL DF_Entry *
OptrEntry::commSubExpr(DF_Entry *df, boolean localBlock)
{
	// test the top level of the expression
	// Check the command line flag, and the operator 
	if((CLFlags.CommonSubExpr == False) ||(df->getType() != Entry_optr))
	{
		return(NULL);
	}
	
	// check for an equivalent operation
	OptrEntry *df_optr = (OptrEntry *)df;
	if(getOptrToken() != df_optr->getOptrToken())	// same operation
	{
		return(NULL);
	}
	
	DF_Entry *result;	// store the answer
	
	// check that there are at least as many operands as the expression
	// being searched for!
	int num_opnds1 = arglist.length();
	int num_opnds2 = df_optr->arglist.length();
	if(num_opnds1 < num_opnds2)
	{	
		result = NULL;
	}
	
	
	// each of the operands must match.
	else if(num_opnds1 == num_opnds2)
	{
		DF_Entry *myopnd = (DF_Entry *)arglist.front();
		DF_Entry *youropnd = (DF_Entry *)(df_optr->arglist.front());
		boolean is_match = True;	// assume this is a match.
			
		for(int i=0; (i<num_opnds1) && (is_match == True);i++)
		{
			if(myopnd && youropnd && equivalentOpnds(myopnd,youropnd))
			//if(myopnd && youropnd && (myopnd == youropnd))
			{
				//	is_match = True;
					
				// get the next pair!
				myopnd = (DF_Entry *)arglist.succ();
				youropnd = (DF_Entry *)(df_optr->arglist.succ());			
			}/* end if */
			else
			{
				is_match = False;
			}
		} /* end for */
				
		if(is_match)
		{
			if(localBlock == True)
			{
				// return the actual operation!
				result = this;	
			}
			else
			{	
				// return where the answer is stored!		
				result = (DF_Entry *)results.front();	
			}
					
		} /* end if */	
		else
		{
			result = NULL;
		}		
	}/* end else if */
	else	// num_opnds1 > num_opnds2
	{
		// create an array of boolean flags
		boolean *opnd_match = new boolean[num_opnds1];
		for(int i=0; i<num_opnds1; i++)
		{
			opnd_match[i] = False;	// initialize to false
		}
			
		DF_Entry *opnd2 = (DF_Entry *)(df_optr->arglist.front());
		boolean is_match = True;
		
		// must try to match all of the args in the df_optr		
		for(int j=0; (j<num_opnds2) && (is_match == True); j++)
		{
			boolean match_found = False;
			DF_Entry *opnd1 = (DF_Entry *)arglist.front();
			for(i = 0; (i<num_opnds1) && (match_found == False); i++)
			{
				if((opnd_match[i] == False) && (opnd1 == opnd2))
				{
					opnd_match[i] = True;
					match_found = True;
				}
			
				opnd1 = (DF_Entry *)arglist.succ();
			
			}/* end for */
			
			if(match_found)
			{
				opnd2 = (DF_Entry *)(df_optr->arglist.succ());
			}
			else
			{
				is_match = False;
			}
		}/* end for */
	
	
		// num_opnds2 matches found. Indicated in array opnd_match.
		// Need to break this into 2 operators now!
		if(is_match)
		{
			OptrEntry *newoptr = new OptrEntry(operationToken,sourceinfo.getLine());
			newoptr->setResultType(getDataType(),getPathWidth());
			List templist;

			DF_Entry *opnd = (DF_Entry *)arglist.front();
			for(int k = 0; k<num_opnds1; k++)
			{
				// every opnd in the arglist will get
				// added to the newoptr or the templist
				if(opnd_match[k] == True)
				{
					// move the operand from the big expression to the subexpression
					newoptr->setSourceList(opnd);
				}
				else
				{
					// copy from arglist to templist
					templist.append(opnd);
				}
				arglist.del_front();
				opnd = (DF_Entry *)arglist.front();
			}	
			// the subexpression is now an operand in the big expression.
			
			mylocalblock->insertEntryBefore(newoptr,this);
			
			result = storeOptrInTempOpnd(newoptr,sourceinfo.getLine(),"");
			// delete the arglist
			arglist.clear();

			// now copy the templist back to the arglist
			arglist.join(&templist);

			setSourceList(result);// result of the subexpression
						// is now an arg in the big expr.

		}
		else
		{
			result = NULL;
		}
	
	
	
	
	}/* end else */
	return(result);
};

//VIRTUAL DF_Entry *
//OptrEntry::commSubExpr(DF_Entry *df, boolean localBlock)
//{
//	DF_Entry *result = NULL;
//	// test the top level of the expression
//	if(CLFlags.CommonSubExpr && (df->getType() == Entry_optr))
//	{
//		OptrEntry *df_optr = (OptrEntry *)df;
//		if(getOptrToken() == df_optr->getOptrToken())	// same operation
//		{
//			int num_opnds = arglist.length();
//			if(num_opnds == df_optr->arglist.length())
//			{
//			
//				DF_Entry *myopnd = (DF_Entry *)arglist.front();
//				DF_Entry *youropnd = (DF_Entry *)(df_optr->arglist.front());
//				boolean is_match = True;	// assume this is a match.
//			
//				for(int i=0; (i<num_opnds) && (is_match == True);i++)
//				{
//					if(myopnd && youropnd && (myopnd == youropnd))
//					{
//						//	is_match = True;
//					
//						// get the next pair!
//						myopnd = (DF_Entry *)arglist.succ();
//						youropnd = (DF_Entry *)(df_optr->arglist.succ());			
//					}/* end if */
//					else
//					{
//						is_match = False;
//					}
//				} /* end for */
//				
//				if(is_match)
//				{
//					if(localBlock == True)
//					{
//						// return the actual operation!
//						result = this;	
//					}
//					else
//					{	
//						// return where the answer is stored!		
//						result = (DF_Entry *)results.front();	
//					}
//					
//				}		
//			} /* end if */			
//		}/* end if */
//	}/* end if */
//	return(result);
//};

int 
OptrEntry::getOptrToken(void)
{
	return(operationToken);
};

VIRTUAL DF_Entry *
OptrEntry::copyPropogate(void)
{
	return(NULL);
};

VIRTUAL void
OptrEntry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
	
	deadCodeFlag = False;		// this is no longer dead code!

	DF_Entry *x =(DF_Entry*)arglist.front(); 
	while(x)
	{
		x->pruneDeadCode();
		x=(DF_Entry *)arglist.succ();
	}
};

// An operator can be calculated in fixed time iff each of its operands
// can be calculated in fixed time.
// (This is almost always true, except for when the operand is a function call)

VIRTUAL boolean
OptrEntry::fixedTimeExecution(void)
{
	boolean flag = True;
	DF_Entry *x =(DF_Entry*)arglist.front(); 
	while(x && (flag==True))
	{
		flag = x->fixedTimeExecution();
		x=(DF_Entry *)arglist.succ();
	}
	return(flag);
};

VIRTUAL DF_Entry *
OptrEntry::getRealSource(void)
{
	return(this);
};

/******************************************************************************/
// Class OptrUnaryEntry
// (based on OptrEntry, is designed specifically for unary operations).
/******************************************************************************/
OptrUnaryEntry::OptrUnaryEntry(int opToken, int line_no) 
	: OptrEntry(opToken, line_no)
{
	/* use the same constructor as the base class */
};

OptrUnaryEntry::~OptrUnaryEntry(void)
{
	/* use the same destructor as the base class */
};

VIRTUAL DF_Entry *
OptrUnaryEntry::commSubExpr(DF_Entry *df, boolean localBlock)
{
	if(CLFlags.CommonSubExpr)
		return(OptrEntry::commSubExpr(df,localBlock));
	else
		return(NULL);
};

VIRTUAL char *
OptrUnaryEntry::getId(void)
{
	return(getUnaryOptrStr(operationToken));
};



/******************************************************************************/
// Class OptrAssignEntry
//
// Declarations:
//		DF_Entry *source;	// list of sources for this operation.
/******************************************************************************/
	
OptrAssignEntry::OptrAssignEntry(int line_no) 
	: OptrEntry(ASSIGNEQUALS, line_no)  // constructor
{ 
	operationStr = ":=";
};

OptrAssignEntry::~OptrAssignEntry(void)	// destructor
{ /* do nothing */};

VIRTUAL char *
OptrAssignEntry::getId(void)
{
	return(operationStr);
};

void 
OptrAssignEntry::print(void)
{
	if(deadCodeFlag == True)
		return;
			
	Outfile->print(".OPTR %4d %s %4d %d\n",
			getIndex(),getId(),1,source->getIndex());

	DF_Entry *x;
	for(x = (DF_Entry *) results.front(); x; x=(DF_Entry *)results.succ())
	{
		x->print();
	}
	
};

void
OptrAssignEntry::resolveIndices(void)
{
	if(!resolvedFlag && (deadCodeFlag == False))
	{
		if(source->isDefinitelySet(False) == False)
		{
			Error(sourceinfo.getLine(),
				"Assignment of value that is not definitely set!\n");
		}
		source->getIndex();
		
		// get the index for this entry.
		getIndex();		
		
		// get the indices for anything that this operator feeds into.
		DF_Entry *x;
		for(x = (DF_Entry *)results.front(); x; x = (DF_Entry *)results.succ())
		{
			x->resolveIndices();
		}
		
		CurrentDFG->addToCalls(getId(),True);
		DFCount_increment(entryType);	// Increment the number operations
		
		resolvedFlag = True;
	}
};

void 
OptrAssignEntry::setSourceList(DF_Entry *opnd, int paramCount)
{
	source = opnd;
};

void 
OptrAssignEntry::setResultsList(DF_Entry *opnd)
{
	results.append(opnd);
};

VIRTUAL boolean
OptrAssignEntry::isDefinitelySet(boolean printFlag)
{
	if(CLFlags.DefinitelySet)
		return(source->isDefinitelySet(printFlag)); 
	else
		return(True);
};

VIRTUAL DF_Entry *
OptrAssignEntry::copyPropogate(void)
{
	if(CLFlags.CopyPropogation == True)
		return(source->copyPropogate());
	else
		return(NULL);
};

VIRTUAL DF_Entry *
OptrAssignEntry::commSubExpr(DF_Entry *df, boolean localBlock)
{
	return(source->commSubExpr(df,localBlock));
};

VIRTUAL void
OptrAssignEntry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
	deadCodeFlag = False;
	source->pruneDeadCode();

};

// An OptrAssignEntry is only fixed time if what its source is.

VIRTUAL boolean
OptrAssignEntry::fixedTimeExecution(void)
{
	return(source->fixedTimeExecution());
};

VIRTUAL DF_Entry *
OptrAssignEntry::getRealSource(void)
{
	return(source->getRealSource());
};

/******************************************************************************/
// Class OpndEntry
/******************************************************************************/
// | .OPND | index | symtblIndex | sourceOptr | optrParam |
/******************************************************************************/
//	DF_Entry *source;
// static int nextTempId;

OpndEntry::OpndEntry(STEntry *ste, int line_no) 
	: DF_Entry(Entry_opnd, line_no) // constructor
{	
	source = NULL;
	parameterNumber = 0;
	dfste = ste;
	dfste->setLastVersion(this);
};

VIRTUAL char*
OpndEntry::getName(void)
{
	return(dfste->getName());
};

void 
OpndEntry::print(void)
{
	if(deadCodeFlag == True)
		return;
				
	Outfile->print(".OPND %4d %4d %4d %4d\n",
					getIndex(),
					 (dfste ? dfste->getIndex() : -1),
					 (source ? source->getIndex() : -1),
					 parameterNumber);
};

void
OpndEntry::resolveIndices(void)
{
	if(!resolvedFlag && (deadCodeFlag == False))
	{

		if(dfste)
			dfste->getIndex();
		else
			Compiler_Error("No `dfste' available: OpndEntry::resolveIndices()\n");
			
		if(source)
			source->getIndex();
		else
			Compiler_Error("No `source' assigned: OpndEntry::resolveIndices()\n");
			
		getIndex();	// get the index of this operand.
		
		resolvedFlag = True;
	}
};

void
OpndEntry::setSourceList(DF_Entry *src, int paramCount)
{
	if(source)
		Compiler_Error("OpndEntry::setSourceList() should ",
							"only ever have 1 source.");
	else
	{
		source = src;
		parameterNumber = paramCount;
	}
};

OpndEntry *
OpndEntry::locate(char *lookfor)
{
	return(0);	///// for now
};

VIRTUAL boolean
OpndEntry::isDefinitelySet(boolean printFlag)
{
	// an operand is definitely set if and only if it's source is definitely set.
	if(CLFlags.DefinitelySet)
		return(source->isDefinitelySet(printFlag));
	else
		return(True);
};

VIRTUAL DF_Entry *
OpndEntry::block_trace(STEntry *ste, boolean searchPred)
{
	DF_Entry *result = NULL;
	
	if((dfste != NULL) && (dfste == ste))
	{
		result = this;
	}
	return(result);
};

VIRTUAL DF_Entry *
OpndEntry::commSubExpr(DF_Entry *df, boolean localBlock)
{
	DF_Entry *result = NULL;
//	if(CLFlags.CommonSubExpr == False)
//		result = NULL;
//	else if(this == df)
//		result = this;
//	else if(equivalentOpnds(this,df))
//		result = this;

	if((CLFlags.CommonSubExpr == True)&&(equivalentOpnds(this,df)))
		result = this;
	return(result);
};

VIRTUAL DataType 
OpndEntry::getDataType(void)
{
	return(dfste->getDataType());
};

VIRTUAL int
OpndEntry::getPathWidth(void)
{
	return(dfste->getPathWidth());
};

VIRTUAL DF_Entry *
OpndEntry::copyPropogate(void)
{
	DF_Entry *result = NULL;
	if(CLFlags.CopyPropogation == True)
	{
		result = source->copyPropogate();
	}
	if(result)
		return result;
	else
		return this;

	//return(result ? result : this);
};

boolean
OpndEntry::isMergePoint(void)
{
	return(False);
};

VIRTUAL void
OpndEntry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
	deadCodeFlag = False;
	source->pruneDeadCode();	
	dfste->pruneDeadCode();		// make sure the symbol table entry gets printed.
};

VIRTUAL DF_Entry *
OpndEntry::getRealSource(void)
{
	return(source->getRealSource());
};

/******************************************************************************/
// Class IfEntry
/******************************************************************************/
// | .BRA | index | numbranches | { condition blockindex }numbranches |
/******************************************************************************/
IfEntry::IfEntry(int count, int line_no) 
	: DF_Entry(Entry_if, line_no)
{
	
	branchCount = count;
	
	condSrc = new DF_EntryPtr[branchCount];
	block   = new BlockEntryPtr[branchCount];

	for(int i = 0; i< branchCount; i++)
	{
		condSrc[i] = NULL;
		block[i] = NULL;
	}
};

void
IfEntry::print(void)
{
//	if(deadCodeFlag == True)
//		return;
	
	Outfile->print(".BRA   %d %d",getIndex(),branchCount);
	for(int i = 0; i<branchCount; i++)
	{
		Outfile->print("     %d %d",
					(condSrc[i] ? (condSrc[i])->getIndex() : 0),
					(block[i] ? (block[i])->getIndex() : 0) );
	}
	Outfile->newline();
	DF_Entry *x = (DF_Entry *)mergeList.front();
	while(x)
	{
		x->print();
		x = (DF_Entry *)mergeList.succ();
	}
};

void 
IfEntry::resolveIndices(void)
{
	if(!resolvedFlag)
	{
		getIndex();
		for(int i = 0; i<branchCount; i++)
		{
			if(condSrc[i])
				(condSrc[i])->getIndex();
			if(block[i])
			{
				(block[i])->resolveIndices();
				(block[i])->getIndex() ;
			}
		}
		
		DF_Entry *x = (DF_Entry *)mergeList.front();
		while(x)
		{
			x->resolveIndices();
			x = (DF_Entry *)mergeList.succ();
		}
		resolvedFlag = True;
	}


};

void 
IfEntry::setCondBlock(int i, DF_Entry *c, BlockEntry *b)
{
	if(i >= branchCount)
		Compiler_Error("Too many branches set in class IfEntry()\n");
	
	condSrc[i] = c;
	block[i] = b;	

};


IfEntry::~IfEntry(void)
{
	delete condSrc;
	delete block;
	DF_Entry *x = (DF_Entry *)mergeList.remove_front();
	while(x)
	{
		delete x;
		x = (DF_Entry *)mergeList.remove_front();
	}
};

VIRTUAL DF_Entry *
IfEntry::block_trace(STEntry *ste, boolean searchPred)
{
	DF_Entry *x = (DF_Entry *)mergeList.front();
	while(x)
	{
		DF_Entry *y = x->block_trace(ste);
		if(y)
			return(y);
		x = (DF_Entry *)mergeList.succ();
	}
	return(NULL);
};

VIRTUAL void
IfEntry::appendMergePt(DF_Entry *x)
{
	mergeList.append(x);
};


VIRTUAL void
IfEntry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
	deadCodeFlag = False;

	// since no IF statements are pruned (YET) then make
	// sure that any conditions get calculated also!
	for(int i = 0; i<branchCount; i++)
	{
		if(condSrc[i])
			(condSrc[i])->pruneDeadCode();
	}
};

// An IF statement can only be executed in fixed time if each of its possible
// branches can be executed in fixed time.

VIRTUAL boolean
IfEntry::fixedTimeExecution(void)
{

	for(int i = 0; i<branchCount; i++)
	{
		//if(condSrc[i])	// may need to test the conditions later on too.
		
		if(block[i])	// make sure the block is not empty!
		{
			boolean flag = (block[i])->fixedTimeExecution();
			if(flag == False)
				return(False);
		}
	}

	return(True);

};

/******************************************************************************/
// Class MergeEntry
/******************************************************************************/
// | .MRG | index | symtblIndex | ifIndex | numbranches | { opnd }numbranches |
/******************************************************************************/
MergeEntry::MergeEntry(int numbranches, STEntry *ste, int line_no) 
			  : OpndEntry(ste, line_no)
{
	branchCount = numbranches;
	
	condSrc = new DF_EntryPtr[branchCount];
	change_pt = new DF_EntryPtr[branchCount];
	
	for(int i = 0; i < branchCount; i++)
	{
		condSrc[i] = NULL;
		change_pt[i] = NULL;
	}
};

MergeEntry::~MergeEntry(void)
{
	delete condSrc;
	delete change_pt;
};

void
MergeEntry::setCondBlock(int i, DF_Entry *cond, DF_Entry *chng_pt)
{

	if(i >= branchCount)
		Compiler_Error("Merge entry index too high!\n");
	
	condSrc[i] = cond;
	change_pt[i] = chng_pt;
	
};

void
MergeEntry::print(void)
{
	if(deadCodeFlag == True)
		return;
	
	Outfile->print(".MRG  %3d %3d     %d   ",
			getIndex(),dfste->getIndex(),branchCount);
	
	for(int i=0;i<branchCount;i++)
	{
		Outfile->print(" %d", (change_pt[i])->getIndex() );
	}	
	Outfile->newline();
				
};

void
MergeEntry::resolveIndices(void)
{
	if(!resolvedFlag && (deadCodeFlag == False))
	{

		dfste->getIndex();
	
		for(int i=0;i<branchCount;i++)
		{
			(change_pt[i])->getIndex() ;
		}	
		getIndex();
		resolvedFlag = True;
	}
};

VIRTUAL boolean
MergeEntry::isDefinitelySet(boolean printFlag)
{
	boolean flag = True;
	if(CLFlags.DefinitelySet)
	{
		int count = 0;
		for(int i=0;(i<branchCount);i++)
		{
			if( (change_pt[i])->isDefinitelySet(False) == False)
			{
				if(printFlag == True)
				{
					char *str = (dfste) ? dfste->getName() : NULL;
					if(str)
					{
						Error("Value for '%s' is not definitely set on branch %d\n",
							str,i);
					}
					else
						Error("Value is not definitely set on branch %d\n",str,i);
				}
				flag = False;
			}
		}
	}
	return(flag);

};

VIRTUAL boolean
MergeEntry::isMergePoint(void)
{
	return(True);
};

VIRTUAL DF_Entry *
MergeEntry::copyPropogate(void)
{
	DF_Entry *result = this;
	if(CLFlags.CopyPropogation == True)
	{
		DF_Entry *c1 = (change_pt[0])->copyPropogate();
		for(int i=1; (i<branchCount) && (c1); i++)
		{
			DF_Entry *c2 = (change_pt[i])->copyPropogate();
			if(!c2 || c2 != c1)
				c1 = NULL;
		}/* end for */
		if(c1 != NULL)
			result = c1;
	} /* end if */
	
	return(result);
};

VIRTUAL DF_Entry *
MergeEntry::commSubExpr(DF_Entry *df, boolean localBlock)
{
	return(NULL);
};

VIRTUAL void
MergeEntry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
	
	deadCodeFlag = False;
	
	for(int i=0; i<branchCount; i++)
	{
		(change_pt[i])->pruneDeadCode();
	}/* end for */
	
	dfste->pruneDeadCode();		// make sure the symbol table entry gets printed.
};

VIRTUAL DF_Entry *
MergeEntry::getRealSource(void)
{
	return(this);
};

/******************************************************************************/
/* Class LoopEntry */
/******************************************************************************/

LoopEntry::LoopEntry(int line_no) 
	: DF_Entry(Entry_loop, line_no)
{
	loopConditionBlock = NULL;
	loopConditionSignal = NULL;
	loopBody = NULL;
};

LoopEntry::~LoopEntry(void)
{
	// a loopCondition and loopBody are BlockEntry's and 
	// should be deleted from the data flow graph 
	// (ie, LoopEntry does not own these BlockEntry's.
//	if(loopConditionBlock)
//	{
//		delete loopConditionBlock;
//		loopConditionBlock = NULL;
//	}
//	if(loopBody)
//	{
//		delete loopBody;
//		loopBody = NULL;
//	};
	DF_Entry *x = (DF_Entry *)mergeList.remove_front();
	while(x)
	{
		delete x;
		x = (DF_Entry *)mergeList.remove_front();
	}
};

void 
LoopEntry::print(void)
{
//	if(deadCodeFlag == True)
//		return;
	
	Outfile->print(".LOOP  %3d %3d %3d %3d\n", 
		getIndex(),
	loopConditionBlock->getIndex(), 
	loopConditionSignal->getIndex(),
	loopBody->getIndex());
	
	DF_Entry *x = (DF_Entry *)mergeList.front();
	while(x)
	{
		x->print();
		x = (DF_Entry *)mergeList.succ();
	}
};

void 
LoopEntry::resolveIndices(void)
{
	if(!resolvedFlag)
	{
		getIndex();	// get the index of the loop stmt itself
		loopConditionBlock->getIndex();
		loopConditionSignal->getIndex();
		
		
		loopBody->resolveIndices();
		loopBody->getIndex();

		DF_Entry *x = (DF_Entry *)mergeList.front();
		while(x)
		{
			x->resolveIndices();
			x = (DF_Entry *)mergeList.succ();
		}
	
		resolvedFlag = True;
	}
};

void 
LoopEntry::setCondBlock(BlockEntry *b, DF_Entry *c)
{
	if(!b)
		Compiler_Error("LoopEntry::setCondBlock(NULL) called!\n");
	loopConditionBlock = b;
	loopConditionSignal = c;
};

void 
LoopEntry::setBodyBlock(BlockEntry *b)
{
	if(!b)
		Compiler_Error("LoopEntry::setBodyBlock(NULL) called!\n");
	loopBody = b;
};

VIRTUAL DF_Entry*
LoopEntry::block_trace(STEntry *ste, boolean searchPred)
{
	DF_Entry *x = (DF_Entry *)mergeList.front();
	while(x)
	{
		DF_Entry *y = x->block_trace(ste);
		if(y)
			return(y);
		x = (DF_Entry *)mergeList.succ();
	}
	return(NULL);
};

VIRTUAL void
LoopEntry::appendMergePt(DF_Entry *x)
{
	mergeList.append(x);
};

VIRTUAL void
LoopEntry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
	
	deadCodeFlag = False;
	loopConditionSignal->pruneDeadCode();
};

VIRTUAL boolean
LoopEntry::fixedTimeExecution(void)
{

	return(False);	// usually the case, but may not be.
};

/******************************************************************************/
LoopMergeEntry::LoopMergeEntry(STEntry *ste, int line_no) 
	: OpndEntry(ste, line_no)
{
	pre = NULL;
	post = NULL;
	recursivePropogateFlag = False;
};

LoopMergeEntry::~LoopMergeEntry(void)
{

	// Warning: pre and post should not be deleted since they are
	// only references to other entry objects owned by others.
//	if(pre) delete pre;
//	pre = NULL;
//	
//	if(post) delete post;
//	post = NULL;

};

void 
LoopMergeEntry::print(void)
{
	if(deadCodeFlag == True)
		return;
	
	int preIndex = 0, postIndex = 0;
	int z = getIndex();
	
	if(pre)
		preIndex = pre->getIndex();
	else
		Error("LoopMergeEntry::print() pre never set!\n");
	if(post)
		postIndex = post->getIndex();
	else
		Error("LoopMergeEntry::print() post never set!\n");
				
	Outfile->print(".LMRG  %3d %3d    %3d %3d\n",
		z, dfste->getIndex(), preIndex, postIndex);	
};

void 
LoopMergeEntry::resolveIndices(void)
{
	if(!resolvedFlag && (deadCodeFlag == False))
	{

		if(pre)
			pre->getIndex();
		else
			Error("LoopMergeEntry::resolveIndices() pre never set!\n");
		
		if(post)
			post->getIndex();
		else
			Error("LoopMergeEntry::resolveIndices() post never set!\n");
				
		dfste->getIndex();
		getIndex();		
		resolvedFlag = True;
	}
};

void 
LoopMergeEntry::set(DF_Entry *before, DF_Entry *after)
{
	if(before)
		pre = before;
	if(after)
		post = after;
};

VIRTUAL boolean
LoopMergeEntry::isDefinitelySet(boolean printFlag)
{
	if(CLFlags.DefinitelySet)
		return(pre->isDefinitelySet(printFlag));
	else
		return(True);
};

VIRTUAL boolean
LoopMergeEntry::isMergePoint(void)
{
	return(True);
};

VIRTUAL DF_Entry *
LoopMergeEntry::copyPropogate(void)
{
	if(recursivePropogateFlag == True)
		return(NULL);
	else
		recursivePropogateFlag = True;
	
	DF_Entry *result = NULL;
	if(CLFlags.CopyPropogation == True)
	{
		DF_Entry *c1 = pre->copyPropogate();
		if(c1)
		{
			// - post is not set if we are still building this loop!
			// - make sure not to get into a recursive definition 
			if(post && post != this)			
			{
				DF_Entry *c2 = post->copyPropogate();
		
				if(c2 && (c1 == c2))
				{
					result = c1;
				}
			}
		}
	}

	recursivePropogateFlag = False;
	return(result);

};

VIRTUAL DF_Entry *
LoopMergeEntry::commSubExpr(DF_Entry *df, boolean localBlock)
{
	return(NULL);
};

VIRTUAL void
LoopMergeEntry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
	deadCodeFlag = False;
	pre->pruneDeadCode();
	post->pruneDeadCode();
	
	dfste->pruneDeadCode();		// make sure the symbol table entry gets printed.
};

VIRTUAL DF_Entry *
LoopMergeEntry::getRealSource(void)
{
	return(this);
};


/******************************************************************************/
// Class ParEntry
/******************************************************************************/
// | .PAR | index | numbranches | { condition blockindex }numbranches |
/******************************************************************************/
ParEntry::ParEntry(int branch_count, int cojoin_count, int line_no)
	 : DF_Entry(Entry_if, line_no)
{
	
	branchCount = branch_count;
	cojoinCount = cojoin_count;
	
	condSrc = new DF_EntryPtr[branchCount];
	block   = new BlockEntryPtr[branchCount];

	for(int i = 0; i< branchCount; i++)
	{
		condSrc[i] = NULL;
		block[i] = NULL;
	}
};

void
ParEntry::print(void)
{
//	if(deadCodeFlag == True)
//		return;
	
	Outfile->print(".PAR\t%d\t%d\n",getIndex(),branchCount);
	for(int i = 0; i<branchCount; i++)
	{
		char *semaphore_name = mallocNameTemp("_S");
		Outfile->print(".THRD\t%s\t%d\t%d\n",
					semaphore_name,
					(condSrc[i] ? (condSrc[i])->getIndex() : 0),
					(block[i] ? (block[i])->getIndex() : 0) );
	}
	Outfile->print(".JOIN\t%d\n",cojoinCount);
	Outfile->newline();
};

void 
ParEntry::resolveIndices(void)
{
	if(!resolvedFlag)
	{
		getIndex();
		for(int i = 0; i<branchCount; i++)
		{
			if(condSrc[i])
				(condSrc[i])->getIndex();
			if(block[i])
			{
				(block[i])->resolveIndices();
				(block[i])->getIndex() ;
			}
		}
		resolvedFlag = True;
	}


};

void 
ParEntry::setCondBlock(int i, DF_Entry *c, BlockEntry *b)
{
	if(i >= branchCount)
		Compiler_Error("Too many branches set in class ParEntry()\n");
	
	condSrc[i] = c;
	block[i] = b;	

};


ParEntry::~ParEntry(void)
{
	delete condSrc;
	delete block;
};

VIRTUAL DF_Entry *
ParEntry::block_trace(STEntry *ste, boolean searchPred)
{
	for(int i = 0; i<branchCount; i++)
	{
		if(block[i])
		{
			DF_Entry *x = (block[i])->block_trace(ste,False);
			if(x && (x != ste))
				return(x);
		}
	}
	return(NULL);
};


VIRTUAL void
ParEntry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
	deadCodeFlag = False;
	
	// if any branches need a condition, make sure they are not pruned.
	for(int i = 0; i<branchCount; i++)
	{
		if(condSrc[i])
			(condSrc[i])->pruneDeadCode();
	}
};

VIRTUAL boolean
ParEntry::fixedTimeExecution(void)
{

	for(int i = 0; i<branchCount; i++)
	{
		if(block[i])
		{
			boolean flag = (block[i])->fixedTimeExecution();
			if(flag == False)
				return(False);
		}
	}
	return(True);



};

/******************************************************************************/
// Class CtrlEntry
/******************************************************************************/
// | .CTRL | blockindex |
/******************************************************************************/
CtrlEntry::CtrlEntry(void) : DF_Entry(Entry_ctrl)
{
	block = NULL;
};

CtrlEntry::CtrlEntry(BlockEntry *childblock) : DF_Entry(Entry_ctrl)
{
	block = childblock;
};

void 
CtrlEntry::setChildBlock(BlockEntry *b)
{
	if(block)
		Compiler_Error("CtrlEntry::setBlock() should only be called once.\n");
	else
		block = b;
};

BlockEntry *
CtrlEntry::getChildBlock(void)
{
	if(block)
		return(block);
	else
		Compiler_Error("CtrlEntry::getChildBlock(void) - block never set!\n");
	return(NULL);	
};

void 
CtrlEntry::print(void)
{
	//	if(isUsable())
	//		Outfile->print(".CTRL %3d\n",( block ? block->getIndex() : -1) );
//	if(deadCodeFlag == True)
//		return;
	
	if(isUsable())
		Outfile->print(" %d",( block ? block->getIndex() : -1) );
};

void 
CtrlEntry::resolveIndices(void)
{
	if(!resolvedFlag)
	{
		if(isUsable() && (block))
			block->getIndex();
			
		resolvedFlag = True;
	}
};

boolean
CtrlEntry::isUsable(void)
{
	return ( (block && block->isUsable() ) ? True : False ) ;
};



VIRTUAL DF_Entry *
CtrlEntry::block_trace(STEntry *ste, boolean searchPred)
{
	if(block)
		return(block->block_trace(ste,searchPred));
	else
		return(NULL);
};

VIRTUAL void
CtrlEntry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
	deadCodeFlag = False;
	
	if(block)
		block->pruneDeadCode();
};

VIRTUAL boolean
CtrlEntry::fixedTimeExecution(void)
{
	if(block)
		return(block->fixedTimeExecution());
	else
		return(True);
};
/******************************************************************************/

OptrProcEntry::OptrProcEntry(char *name, int line_no) : OptrEntry(-1,line_no)
{
	id = mallocName(name);
};

OptrProcEntry::~OptrProcEntry(void)
{
	if(id)
	{
		delete id;
		id = NULL;
	}

};

VIRTUAL char *
OptrProcEntry::getId(void)
{
	return(id);
};

VIRTUAL void 
OptrProcEntry::setSourceList(DF_Entry *opnd, int paramCount)
{
		arglist.append(opnd);
};

VIRTUAL boolean 
OptrProcEntry::isDefinitelySet(boolean printFlag)
{
	// if this is a proc/func call, then assume the result
	// is definitely set. The compilation of the actual source
	// code for the called proc/func will have determined 
	// if anything was not definitely set!
	
	return(True);

};

void
OptrProcEntry::resolveIndices(void)
{
	if(!resolvedFlag && (deadCodeFlag == False))
	{
		// get the indices for anything that feeds into this operator.
		DF_Entry *x; 
		for(x = (DF_Entry *)arglist.front(); x; x=(DF_Entry *)arglist.succ())
		{
			// assume any arg used in a procedure call has been definitely set!
			// x->isDefinitelySet();
			// get the index for the arg.
			x->getIndex();
		}
		
		// get the index for this entry.
		getIndex();		
		
		// get the indices for anything that this operator feeds into.
		for(x = (DF_Entry *)results.front(); x; x=(DF_Entry *)results.succ())
		{
			x->resolveIndices();
		}
		
		// let the data flow graph know that this procedure has been called.
		CurrentDFG->addToCalls(getId());
		
		DFCount_increment(entryType);	// Increment the number operations
		
		resolvedFlag = True;
	}
};


VIRTUAL void
OptrProcEntry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
	deadCodeFlag = False;

	DF_Entry *x; 
	for(x = (DF_Entry *)arglist.front(); x; x=(DF_Entry *)arglist.succ())
	{
		// all the inputs to this procedure must be needed.
		x->pruneDeadCode();
	}
};


// Since a procedure entry will be treated as a separate functional unit,
// the execution time is not known here.

VIRTUAL boolean
OptrProcEntry::fixedTimeExecution(void)
{
	return(False);
};

/******************************************************************************/
boolean equivalentOpnds(DF_Entry *opnd1, DF_Entry *opnd2)
{
	boolean result;
	if(opnd1 == opnd2)
		result = True;
	else if(opnd1->getRealSource() == opnd2->getRealSource())
		result = True;
	else
		result = False;

	return(result);
};
/******************************************************************************/
