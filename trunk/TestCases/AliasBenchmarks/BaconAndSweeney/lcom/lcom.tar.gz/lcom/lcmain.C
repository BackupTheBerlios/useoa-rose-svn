/* FILE: lcmain.c */

/* MAIN defined for use in declarations in file 'globals.h' */
#define MAIN		

//#define COMPILER_VERSION "0.74"	// as of JUNE 12, 1992.
//#define COMPILER_VERSION "0.80"	// as of JUNE 28, 1992.
//#define COMPILER_VERSION "0.81"	// as of JUNE 28, 1992.
//#define COMPILER_VERSION "0.82"	// as of JULY 6, 1992.
//#define COMPILER_VERSION "0.83"	// as of JULY 9, 1992.
//#define COMPILER_VERSION "0.84"	// as of JULY 10, 1992.
	// Changed default sizes of integers, generics, and reals.
	// Fixed bug with inline procedure calls.
	// Fixed bug with use of constants.
//#define COMPILER_VERSION "0.85"	// as of JULY 16, 1992.
	// Added .OPCALLS to dataflow tables;
//#define COMPILER_VERSION "0.86"	// as of JULY 17, 1992.
	// Added last version reference to *OUT parameters.
//#define COMPILER_VERSION "0.87"	// as of AUG 6, 1992.
	// Fixed bug in nloops
//#define COMPILER_VERSION "0.88"	// Dec 28, 1992.
	// Added flags for Frequency Reduction and "Optimize All"
//#define COMPILER_VERSION "0.90"	// Jan 2, 1993.
	// Parse REALS correctly; Output $array$ operator for reading arrays
#define COMPILER_VERSION "1.00" // June 10, 1993


#if defined(__TURBOC__)
#include <string.h>
#include <stream.h>
#else

// Common includes for UNIX systems
#include <stream.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <time.h>
#include <iostream.h>
//#include <new.h>

#if defined(__GNUC__)
#include <sys/uio.h>
#include <builtin.h>
#include <time.h>
#else	// _AIX or HP
#include <string.h>
#endif

#include "lconfig.h"

#endif



#ifdef MYTURBOC
#include <time.h>
#include <string.h>
#endif



#include "yystype.h"
#include "tokens.h"
#include "utils.h"
#include "ptnode.h"
#include "ptproc.h"
#include "dataflow.h"
#include "getlines.h"
#include "symtable.h"
#include "globals.h"

#ifndef lint
static char *sccsid = "@(#)lcmain.C	1.28 (University of Guelph, VLSI Dept.) 93/06/10";
#endif /* lint */


// global variable (do not include in 'globals.h' for now) 
PTNode 			*RootOfTree;	
DataFlowGraph 	*CurrentDFG;
PTProcDecl 		*CurrentPF;

/******************************************************************************/
//prototypes for scanner 

int yyparse(void);

/******************************************************************************/
#define DEFAULT_HASH_SIZE 101


#ifdef MYTURBOC
#define DFEXT "df"
#else
#define DFEXT ".df"
#endif
/******************************************************************************/
void printHeader(void)
{

	cerr << "******************************************\n";
	cerr << "* L (HDL) Compiler, version " ;
	cerr <<     COMPILER_VERSION <<          "        *\n";
	cerr << "*  (c) University of Guelph, VLSI Dept.  *\n";
	cerr << "******************************************\n\n";
}

/******************************************************************************/
/* close source and output files */

void closeAllFiles(void)
{
//	fclose(yyin);
	closeSourceFile(0);
	delete Outfile;
	delete SourceFileName;
};

/******************************************************************************/
void parseCommandLine(int argc, char **argv)
{
	int i;
	int fileNameFound = 0;
	
	if(argc == 1) 
	{
		CLFlags.displayUsage(argv[0]);
		exit(1);
	}

	/* argv starts counting from 0 */
	for(i = 1; i<argc; i++)
	{
		char *s = argv[i];
		if(s[0] == '-' || s[0] == '+')
		{
				CLFlags.setFlag(s);
		}
		else /* assume this is a file name */
		{	
			fileNameFound = 1;

			SourceFileName = mallocName(s);
			openSourceFile(SourceFileName);
			DestinationFileName = mallocName(SourceFileName,DFEXT);

			Outfile = new OutputFile(DestinationFileName);
			if(!Outfile->fileOK())
			{
				cerr << "Error: cannot open destination file '";
				cerr << DestinationFileName << "'\n";
				exit(1);
			}
		}
	}

	if(!fileNameFound)
	{
		Error("No file name specified!\n");
		exit(1);
	}

	// print file header

	Outfile->comment("FILE: %s\n",DestinationFileName);
        time_t lt = time(NULL);
        struct tm *ptr = localtime(&lt);
        char timestr[35];
        // copy the string
        strcpy(timestr,asctime(ptr));
        // make sure to remove any '\n', just in case.
        for (char *s1 = timestr; *s1; *s1++)
        {
                if(*s1 == '\n')
                        *s1 = '\0';
        }
        Outfile->comment("Creation Date: %s.\n",timestr);
        Outfile->comment("Compiler Version %4s.\n",COMPILER_VERSION);
        Outfile->comment("Command Line Args: ");
        for(i = 1; i<argc; i++)
        {
                Outfile->print(" %s",argv[i]);
        }
	Outfile->newline();
	Outfile->newline();

};

/******************************************************************************/
void printSummary(time_t startTime)
{
	printf("\nCompilation Summary:\n\n");
	printf("Source File = '%s'.\n",SourceFileName);
	printf("Dest. File  = '%s'.\n",DestinationFileName);
	printf("Number of lines is %d.\n",CurrentSourceFile.lineNumber);
	printf("Symbol Table Hash Size = %d.\n", 
		(CLFlags.NewHashSize > 0) ? CLFlags.NewHashSize : DEFAULT_HASH_SIZE );
	
	time_t endTime = time(NULL);
	printf("Compilation time: %ld seconds.\n",(endTime - startTime) );

	if(WarningCount > 0)
		printf("Warning Count = %d.\n",WarningCount);
	else
		printf("No Warnings Found!\n");
		
	if(ErrorCount > 0)
		printf("Error Count = %d.\n",ErrorCount);
	else
		printf("No Errors Found!\n");

	if(CLFlags.Debug && DuplicateErrorCount > 0)
		printf("Duplicate Error Count = %d.\n",DuplicateErrorCount);


};

/******************************************************************************/
int main(int argc, char **argv)
{
	time_t startTime = time(NULL);
	
#ifdef YYDEBUG
	extern int yydebug;
	yydebug = 1;
#endif
	parseCommandLine(argc, argv);
	
	if(!CLFlags.QuietMode)
		printHeader();

#ifdef YYDEBUG
	yydebug = (CLFlags.YaccDebug) ? 1 : 0;
#endif

	if(CLFlags.TokenStream)
	{
		getTokenStream();
		RootOfTree = NULL;
	}
	else
	{
		RootOfTree = new PTNode(ptreeRoot);
		CurrentDFG = NULL;
		CurrentPF = NULL;

		if(CLFlags.NewHashSize > 0)
			SymTbl.initialize(CLFlags.NewHashSize,True);
		else
			SymTbl.initialize(DEFAULT_HASH_SIZE, True);
	
		initSourceLineInfo();
		CurrentSourceFile.lineNumber = 1;
		CurrentScope = 1; // initialize to global scope
	
		// Begin parsing
		yyparse();

	}
	
	if(!CLFlags.QuietMode)
		printSummary(startTime);

	if(RootOfTree)
		delete RootOfTree;
	
	closeAllFiles();	/* close source and output files */
	
	if(ErrorCount > 0)
		return(1);
	else
		return(0);	// a return value of zero indicates exit status OK.
};
/******************************************************************************/

