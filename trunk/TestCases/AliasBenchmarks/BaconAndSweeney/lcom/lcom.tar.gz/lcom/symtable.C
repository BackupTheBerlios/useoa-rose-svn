// FILE: SYMTABLE.C

// This file contains the object for a symbol table.
// A symbol table is used to keep track of the 'scope' and
// 'binding information' about identifiers used in the program.
// There is only one symbol table allowed in the compiler.

// 1. A hash table consists of a fixed array of 'hashTableSize' pointers
// to table entries.
// 2. Table entries are organized into 'hashTableSize' separate linked lists,
// called buckets.  Each name inserted into the symbol table can appear
// at most once.

#include <stdio.h>
#include <stdlib.h>
#include "lconfig.h"

#ifdef __GNUC__
#include <builtin.h>
#else
#include <string.h>
#endif

#include "symtable.h"
#include "dfentry.h"
#include "dataflow.h"
#include "globals.h"

extern DataFlowGraph *CurrentDFG;

#ifndef lint
static char *sccsid = "@(#)symtable.C	1.18 (University of Guelph, VLSI Dept.) 93/03/21";
#endif /* lint */



#ifdef DEBUG
#define DEBUGTHIS {if(!this)Compiler_Error("this = 0x00\n");}
#else
#define DEBUGTHIS {}
#endif

#ifndef __XXXGNUC__
// define these prototypes (gnu c++ has these defined in <builtin.h>
unsigned hashpjw(char *name);
unsigned foldhash(double x);
#endif

//-------------------------------------------------------------------
// OBJECT SYMBOLTABLE
//-------------------------------------------------------------------
#define SYMBOL_TABLE_STARTING_SCOPE 1

SymbolTable::SymbolTable(void) 
{
   hashTableSize = 0;
   
   
   // initialize the following so that get_Next_Lvalue() is
   // guaranteed to return NULL if start_Lvalue_List()
   // was not called to initialize the Lvalue list.
   
   next_ste_in_crosslink = NULL;
   next_ste_currentScope = 0;
   
   counts = NULL;
   hashBuckets = NULL;
   
};

SymbolTable::~SymbolTable(void)
{
   // make sure the symbol table is empty
   while(currentScope >= 1)
   {
      deleteScope(currentScope); 
      currentScope--;
   }
   if(entryCount > 0)
   {
      Warning("Symbol table left %d symbols.\n",entryCount);
   }
   
   if(hashBuckets) 
   {
   	delete hashBuckets; 
   }
     
   if(counts)
   {  
   	delete counts; 
   }
};

void
SymbolTable::initialize(int size, boolean keepStats) 
{
   if(hashTableSize > 0)
      Compiler_Error("Cannot initialize symbol table more than once!\n");
      
   hashTableSize = size;
	hashBuckets = new STEptr[hashTableSize];
   for(unsigned j = 0; j < hashTableSize; j++)
   {
      hashBuckets[j] = NULL;
   }
   
   if(!hashBuckets)
      Compiler_Error("Not enough memory to create symbol table.\n");
   
   keepStatistics = keepStats;
   if(keepStatistics)
   {
		counts = new int[hashTableSize];
      if(!counts)
      	Compiler_Error("Not enough memory for hash table statistics!\n");
      for(unsigned i=0;i<hashTableSize;i++) // initialize to zero
		{
        counts[i] = 0;
		}
   }

   currentScope = SYMBOL_TABLE_STARTING_SCOPE;
   entryCount = 0;      // no symbols yet.
};

List *
SymbolTable::getCurrentCrossLink(void)
{
   return(&crossLink[currentScope]);
};


STEntry *
SymbolTable::lookup(char *name)
{
   DEBUGTHIS;
   
//   if(curr_inline_scope > 0)
//   {
//   	name = mallocName(name, inline_prefix);  
//   }
   name = mallocName(name);  
   int hashValue = getHashValue(name) ;
   STEntry *ste = hashBuckets[hashValue];
   while(ste)
   {
   	char *tempstr = ste->getName();
      if(tempstr && strcmp(tempstr, name) == 0)
         return(ste);
      
      ste = ste->next;
   }

   if(Inline.curr_scope > 0)
   {
		delete name;
   }
    
   return(NULL);   // not found


};

STEntry *
SymbolTable::lookupProc(char *name)
{
   DEBUGTHIS;
   
   int hashValue = getHashValue(name) ;
   STEntry *ste = hashBuckets[hashValue];
   while(ste)
   {
   	char *tempstr = ste->getName();
      if(tempstr && strcmp(tempstr, name) == 0)
         return(ste);
      
      ste = ste->next;
   }

    
   return(NULL);   // not found


};

STEntry *
SymbolTable::lookup(long constval, int pwidth)
{
   DEBUGTHIS;
   int hashValue = getHashValue(constval);
   STEntry *ste = hashBuckets[hashValue];
   while(ste)
   {
     if(  ste->isConstant() &&
     		(ste->getConstantValue() == constval) && 
         (ste->getPathWidth() == pwidth ))
          return ( ste );
      
     ste = ste->next;   // get the next bucket;
   }
    
   return(NULL);   // not found

};

STEntry * 
SymbolTable::insert(char *name)
{
   DEBUGTHIS;
   if(CLFlags.Debug)
      printf("SYMBOL TABLE: inserting '%s'\n",name);
   
//   if(curr_inline_scope > 0)
//   {
//   	name = mallocName(name,inline_prefix);  
   	name = mallocName(name);  
//   } 
   
   int hashValue = getHashValue(name);
   STEntry *ste = new STEntry(name);
   ste->setScope(currentScope);
   ste->setSymbolType(ptreeIdent);  // assume this is a simple ident for now.

   // make this new ste the first of the buckets.
   ste->next = hashBuckets[hashValue];
   ste->prev = NULL;
   hashBuckets[hashValue] = ste;
   ste->hashval = hashValue;
   
   // add this ste to the crosslinks
   crossLink[currentScope].append(ste);
   
   // one more entry has been added.
   entryCount++;
   
   if(keepStatistics)
      incStatistics(hashValue);

	if(Inline.curr_scope > 0)
	{
		delete name;
	}
	
   return(ste);
};

STEntry * 
SymbolTable::insertProc(char *name)
{
   DEBUGTHIS;
   if(CLFlags.Debug)
      printf("SYMBOL TABLE: inserting proc/func '%s'\n",name);
    
   int hashValue = getHashValue(name);
   STEntry *ste = new STEntry(name);
   ste->setScope(0);
   ste->setSymbolType(ptreeIdent);  // assume this is a simple ident for now.

	// insert the proc/func at the end of the hash list
	// (local variables are added to the beginning of the list so that
	// they can be easily removed.
	
	STEntry *temp1, *temp2;
	temp2 = NULL;
	temp1 = hashBuckets[hashValue];
	
	while(temp1)
	{
		temp2 = temp1;
		temp1 = temp1->next;
	};
	
	if(temp2)	// temp2 is the current last node.
	{
		temp2->next = ste;	// add to the end.
		ste->next = NULL;
		ste->prev = temp2;
	}
	else	// add to an empty bucket.
	{
		ste->next = NULL;
		ste->prev = NULL;
		hashBuckets[hashValue] = ste;
	}
	
	ste->hashval = hashValue;	// note the hashvalue.
	
   
   // add this ste to the crosslinks
   crossLink[SYMBOL_TABLE_STARTING_SCOPE].append(ste);
   
   // one more entry has been added.
   entryCount++;
   
   if(keepStatistics)
      incStatistics(hashValue);

   return(ste);
};

STEntry*
SymbolTable::insert(long constantval, int pwidth, char *name)
{
   DEBUGTHIS;
   if(CLFlags.Debug)
   {
      if(name)
         printf("SYMBOL TABLE: inserting constant symbol '%s'\n",name);
      else
         printf("SYMBOL TABLE: inserting constant '%ld'\n",constantval);
   } 
  
   int hashValue;
   
   if(name)
      hashValue = getHashValue(name);
   else  
      hashValue = getHashValue(constantval);
      
   STEntry *ste = new STEntry(constantval,pwidth,name);
   ste->setScope(currentScope);
   ste->setSymbolType(ptreeConst);

  // make this new ste the first of the buckets.
   ste->next = hashBuckets[hashValue];
   ste->prev = NULL;
   hashBuckets[hashValue] = ste;
   ste->hashval = hashValue;
   
   // add this ste to the crosslinks
   crossLink[currentScope].append(ste);
   
   // one more entry has been added.
   entryCount++;
   
   if(keepStatistics)
     incStatistics(hashValue);
   return(ste);
};

void 
SymbolTable::deleteCurrentScope(void)  
{
   deleteScope(currentScope);
};

void 
SymbolTable::deleteScope(int dscope)
{
   DEBUGTHIS;
   // traverse the current crossLink and remove each ste from its bucket.
   // The crossLink is traversed in reverse order since the most recent
   // addition to a bucket list is at the head.
   
   List *cl = &crossLink[dscope];
   STEntry *ste = (STEntry *)cl->remove_rear();
   while(ste)
   {
      hashBuckets[ste->hashval] = ste->next;
      delete ste;
      entryCount--;
   
      ste = (STEntry *)cl->remove_rear();
   };
};

int  
SymbolTable::incScope(void)
{ 
   DEBUGTHIS;
   currentScope++;
   debug("SYMBOL TABLE incremented to Scope %d.\n",currentScope);
   if(currentScope >= MAX_SCOPE_DEPTH)
   {
      Compiler_Error("Scope depth defined to maximum of '%d'\n",
                     MAX_SCOPE_DEPTH);
      return(0);
   }
   
   return(currentScope);
};

int  
SymbolTable::decScope(void)
{
   DEBUGTHIS;
   if(!crossLink[currentScope].empty())
   {
      Compiler_Error("Decrementing scope value for non-empty crosslink.\n");
      return(0);
   }
   

   currentScope--;
   if(currentScope < 0)
      Compiler_Error("Scope dipped below zero!\n");
   debug("SYMBOL TABLE decremented to Scope %d.\n",currentScope);
   return(currentScope);
}; 

void 
SymbolTable::dump(int dscope)
{
   DEBUGTHIS;
   printf("******* DUMP OF SYMBOL TABLE for scope(%d) ********\n",dscope);
   for(unsigned i = 0; i<hashTableSize; i++)
   {
      STEntry * ste = hashBuckets[i];
      while(ste && (ste->getScope() == dscope))
      {
      	char *tempstr = ste->getName();
   		if(!tempstr)
   			tempstr = mallocNameTemp();
         printf("<%d> '%s'\n",i,tempstr);
         ste = ste->next;
      };
      
   }
   printf("******* END OF SYMBOL TABLE DUMP ************\n");

};

void 
SymbolTable::dumpAll(void)
{
   DEBUGTHIS;
   printf("******* DUMP OF ENTIRE SYMBOL TABLE ********\n");
   for(unsigned i = 0; i<hashTableSize; i++)
   {
      STEntry * ste =  hashBuckets[i];
      while(ste)
      {
			char *tempstr = ste->getName();
			if(!tempstr)
				tempstr = mallocNameTemp();
			printf("<%d> '%s' (%d)\n",i,tempstr,ste->getScope());
			ste = ste->next;
      };
      
   }
   printf("******* END OF SYMBOL TABLE DUMP ************\n");



};

unsigned 
SymbolTable::getHashValue(char *name)
{
   DEBUGTHIS;
   unsigned h = hashpjw(name);
   return(h % hashTableSize);
};

unsigned 
SymbolTable::getHashValue(long constval)
{
   DEBUGTHIS;
   unsigned h = foldhash( (double)constval );
   return(h % hashTableSize);
};


void 
SymbolTable::incStatistics(unsigned hashValue)
{
   DEBUGTHIS;
  counts[hashValue] += 1;
};


void 
SymbolTable::dumpStats(void)
{
   DEBUGTHIS;
   int biggest = 0, empty = 0, ttl = 0;

   
   printf("Hash Table Statistics!\n");
   if(!keepStatistics)
   {
      printf("None Kept!");
   }
   else
   {
      printf("POSITION \tCOUNT\n");

      for(unsigned i=0;i<hashTableSize;i++)
      {
         int c = counts[i];
         printf("[%d] \t\t%d\n", i,c);
         if(c > biggest)
            biggest = c; // is this the largest bucket
         if(c == 0) 
            empty++; // was this bucket always empty
         ttl += c;      // increment total inserts
      }
      printf("MAX = %d. EMPTY = %d. TOTAL ENTRIES = %d.\n", 
         biggest,empty,ttl);
   }
};

void
SymbolTable::start_Lvalue_List(void)
{
   next_ste_currentScope = currentScope;
   next_ste_in_crosslink = (STEntry *)crossLink[next_ste_currentScope].front();
};

STEntry *
SymbolTable::get_Next_Lvalue(void)
{
   STEntry *current_ste = next_ste_in_crosslink;
   
   // find the symbol table entry that has write access.
   while(current_ste && (!current_ste->writeaccess))
   {
      current_ste = (STEntry *)crossLink[next_ste_currentScope].succ();
      
      // if there is no current_ste, then the current cross link
      // must be finished, so go to the next crosslink.
      if(!current_ste)
      {
         next_ste_currentScope--;
         // if there are no more cross links, return NULL;
         if(next_ste_currentScope >= SYMBOL_TABLE_STARTING_SCOPE)
	    current_ste = (STEntry*)crossLink[next_ste_currentScope].front();
      }
      
   }
   
   // if we have found a current_ste, set up the next ste.
   // (otherwise, just set the next_ste_in_crosslink to NULL
   // so that any subsequent call to this method will continue
   // to return NULL; )
   
   if(!current_ste)
   {
      next_ste_in_crosslink = NULL;
   }
   else
   {
      next_ste_in_crosslink = (STEntry *)crossLink[next_ste_currentScope].succ();
      
      while(!next_ste_in_crosslink && 
            next_ste_currentScope >= SYMBOL_TABLE_STARTING_SCOPE)
      {
         next_ste_currentScope--;
         if(next_ste_currentScope >= SYMBOL_TABLE_STARTING_SCOPE)
	    next_ste_in_crosslink = (STEntry *)crossLink[next_ste_currentScope].front();
      }
   }
      
   return(current_ste);
};

int
SymbolTable::getPrintCount(void)
{
	int count = 0;
	List *x = &crossLink[currentScope];
	STEntry *ste = (STEntry *)x->front();
	while(ste)
	{
		if((ste->printFlag == True) && (ste->deadCodeFlag == False))
			count++;
		ste = (STEntry *)x->succ();
	}
	
	return(count);

};

//void 
//SymbolTable::resetCopyPropInRange(int step1, int step2)
//{
//	start_Lvalue_List();
//	STEntry *ste = get_Next_Lvalue();
//	
	// make sure that any variable that was altered in this
	// branch does not have a copy propogation value.
//	while(ste)
//	{
//		if(ste->step_altered.inRange(step1,step2))   
//		{
//			ste->copyProp.set(NULL);
//		}
//        
//		ste = get_Next_Lvalue();
//	}; /* end while */
//};

//--------------------------------------------------------------------
#ifndef __XXXGNUC__

unsigned hashpjw(char *name)
{
   unsigned hash = 0, g;
   
   for(char *p = name; *p; p++)
   {
      hash = (hash << 4) + *p;
      // assumes 32 bit int size
      if( g = hash & 0xf0000000)
      {
         hash ^= g >> 24;
         hash ^= g;
      }
   }
   return(hash);
};

unsigned foldhash(double x)
{
   double t = x;
   unsigned h = 0;
   while(t > 0)
   {
      h += (int)t % 10;
      t /= 10.0;
   }

   return(h);
};
#endif

//-------------------------------------------------------------------
// OBJECT Parameter
//-------------------------------------------------------------------
   
Parameter::Parameter(void) // constructor
{
   p_in = 0;
   p_out = 0;
   p_index = 0;
   p_is_a_param = False;
};

void
Parameter::setIndex(int overall_index, int in_index, int out_index) 
{
   DEBUGTHIS;
   if(!p_is_a_param) 
      Compiler_Error("Cannot assign a param_index to a non-parameter.\n");
      
   p_index = overall_index;
   p_in    = in_index;
   p_out   = out_index; 
};

int
Parameter::getIndex(void) 
{   
   return (p_index);
};

int
Parameter::getIndex( int &overall_index, int &in, int &out) 
{   
   in = p_in;
   out = p_out;
   overall_index = p_index;
   
   return(overall_index);
};

void
Parameter::setIsParameter(boolean tf) 
{  
   p_is_a_param = tf; 
};
   
boolean 
Parameter::isParameter(void)     
{ 
   return(p_is_a_param); 
};

//-------------------------------------------------------------------
// OBJECT SYMBOL TABLE ENTRY
//-------------------------------------------------------------------


STEntry::STEntry(char *name) : DF_Entry(Entry_symtbl)
{   
   DEBUGTHIS;
   id = mallocName(name);
   token = 0;
   scope = 0;  // scope should be set by the symbol table on insertion.
   
   symbolType = ptreeIdent;   // assume for now
   
   datatype = Data_int; // assume integer for now
   isConst = False;
   pathwidth = getDefaultPathWidth(datatype);
   constantValue = 0;    
   readaccess = True;
   writeaccess = True;
   printFlag = False;	// assume false until set to true.
   
   next = prev = NULL;
   hashval = -1;
   ptnode = NULL;
   lastVersion = NULL;

   
};

STEntry::STEntry(long constantval, int pwidth, char *name) 
         : DF_Entry(Entry_symtbl)
{
   
   DEBUGTHIS;
   if(name)
      id = mallocName(name);
   else
      id = NULL; // id = mallocNameTemp();

   token = 0;
   scope = 0;  // scope should be set by the symbol table on insertion.
   
   datatype = Data_int;
   isConst = True;
   pathwidth = pwidth;
   constantValue = constantval;
   readaccess = True;
   writeaccess = False;
   
   next = prev = NULL;
   hashval = -1;
   ptnode = NULL;
   lastVersion = NULL;

};

STEntry::~STEntry(void)
{
   if(id) 
   { 
      delete id; 
      id = NULL; 
   };
   // if the value of 'this' is null before a return, then the member
   // and base class destructors are not invoked, and operator 'delete'
   // is not called.
};

void
STEntry::setSymbolType(PtreeNodeType symtype)
{
   symbolType = symtype;

};

PtreeNodeType
STEntry::getSymbolType(void)
{
   return(symbolType);
};

void 
STEntry::setPTNode(PTNode *p)
{
   ptnode = p;
};

PTNode *
STEntry::getPTNode(void)
{
   return(ptnode);
};


void 
STEntry::print(void)
{
// print the entry only if the variable had been accessed (or is a constant).
   if(printFlag && (deadCodeFlag ==  False))
   {
      
//    Outfile->print("%d \"%s\"", getIndex(),getName()); // use quotes
      Outfile->print("%d %s", getIndex(),getName());  // no quotes
      
      // leave some spacing
      int len = strlen(getName());
      for(int i = len; i < 10; i++)
         Outfile->print(" ");
      
      int temp_constantflag = (isConst) ? 1 : 0;   
		int temp_constantvalue = (isConst) ? getConstantValue() : 0;
      
      Outfile->print(" %2d %3d    %1d 0x%x      %d\n",
         getDataType(),getPathWidth(),
         temp_constantflag, temp_constantvalue,
         param.getIndex() );
         
//      Outfile->print(" %2d %3d    %1d 0x%x         %d %d\n",
//       getDataType(),getPathWidth(),	
//       isConstant(), getConstantValue(),
//       param.getIndex(),
//       lastVersion ? lastVersion->getIndex() : 0 );	// last value of OUT param
   }
};

// Any variables that were declared and used, should be printed out.
// Any constants may be folded out, even if they were used. In this case,
// they are not printed out. If a constant was declared, but never used,
// then skip it also. 

void 
STEntry::resolveIndices(void)
{
// resolve the entry only if the variable had been accessed (or is a constant).

   boolean notUsedFlag = False;
   printFlag = False;
   
   if( isConst )
   {
      if(!step_accessed.empty() ) 
      {
         printFlag = True;
         // if it has to be printed, it must be given a name!
         if(id == NULL)
         	id = mallocNameTemp();
         
      }
      else if(step_used.empty())
      {
         notUsedFlag = True;
      }
   }
   else  // not a constant (a variable)
   {
      if( 	(step_accessed.empty() == False) || 
      		(step_altered.empty() == False) 	)
      {
         printFlag = True;
      }
      else if(step_used.empty() == True)
      {
         notUsedFlag = True;
      }
      
      if(param.isParameter() && (lastVersion != NULL) &&
      	(lastVersion->isDefinitelySet(False) == False))
      {
      		Error("Parameter '%s' not definitely set!\n",id);      	
      }
/***********
      if(param.isParameter() )
      {
      	BlockEntry *b = CurrentDFG->getFirstUsableBlockEntry();
      	DF_Entry *x = b->block_trace(this);
      	if(x->isDefinitelySet(False) == False)
      	{
      		Error("Parameter '%s' not definitely set!\n",id);      	
      	}
      }
***********/
   }
   
   if(notUsedFlag == True)
   {
      if(param.isParameter())
      {
      	Error("In '%s', parameter '%s' never used.\n",
                  CurrentDFG->getProcName(), getName());
      }
      else if(!isConstant())
      {
      	Warning("In '%s()', '%s' never used.\n", 
                  CurrentDFG->getProcName(), getName());
      }
   }

   if(printFlag == True)
   {
      getIndex();
      param.getIndex();
   }
};

void 
STEntry::setDataType(DataType dt)   {  datatype = dt; };

DataType 
STEntry::getDataType( void )  {  return datatype; };

VIRTUAL boolean 
STEntry::isConstant(void)  { return isConst; };

void 
STEntry::setConstantValue(long cv)     
{  
   DEBUGTHIS;
   constantValue = cv;
   isConst = True;
};

long
STEntry::getConstantValue(void)
{ 
	if(isConst == False)
		Compiler_Error("Attempt to read constant from a non-constant symbol!\n");
	return(constantValue); 
};

void 
STEntry::setPathWidth(int pw) {  pathwidth = pw; };

int 
STEntry::getPathWidth(void)   {  return(pathwidth); };

char *
STEntry::getModeStr(void)
{
   DEBUGTHIS;
   if(readaccess && writeaccess)
      return("inout");
   else if(readaccess)
      return("in");
   else if(writeaccess)
      return("out");
   else
      return("inout-trouble");
};

boolean 
STEntry::isWriteable(void)             { return (writeaccess); };

void 
STEntry::setModeAccess(boolean readable, boolean writeable)
{
   DEBUGTHIS;
   if(isConst)
      Compiler_Error("Attempting to set rw mode for a constant!\n");
      
   readaccess = readable;
   writeaccess = writeable;
};


VIRTUAL boolean
STEntry::isDefinitelySet(boolean printMsgFlag)
{
   boolean flag;
   if( isConst || (CLFlags.DefinitelySet == False))
   {
		flag = True;
   }
   else  // not a constant (a variable)
   {	// if this is an OUT parameter, then false.
   	if(param.isParameter() && (readaccess == False) && (writeaccess == True))
   	{
   		flag = False;
   		if(printMsgFlag == True)
   			Error("OUT parameter '%s' used in expression without being set!\n",
   			getName());
      }
      else if(param.isParameter() && (readaccess == True))
      {
      	flag = True;
      }
      else if(param.isParameter() == False)
      {
  			flag = False;
   		if(printMsgFlag == True)
   			Error("Uninitialized symbol '%s' used in expression!\n", getName());
		}
   }
   return(flag);
};

VIRTUAL DF_Entry *
STEntry::copyPropogate(void)
{
	if(isConst || param.isParameter() || CLFlags.CopyPropogation)
		return(this);
	else
		return(NULL);
};

void
STEntry::setLastVersion(DF_Entry *x)
{
	lastVersion = x;
};

DF_Entry *
STEntry::getLastVersion(void)
{
	return(lastVersion);
};

VIRTUAL void
STEntry::pruneDeadCode(void)
{
	if(deadCodeFlag == False)	// if this node has already been visited, go back
		return;
	
	deadCodeFlag = False;		// this is no longer dead code!
   
	if(param.isParameter() && (lastVersion != NULL))
      	lastVersion->pruneDeadCode();
};

VIRTUAL DF_Entry *
STEntry::getRealSource(void)
{
	return(this);
};

//---------------------------------------------------------------------------
// Class StepCheck
//---------------------------------------------------------------------------
StepCheck::StepCheck(void)	// constructor
{
	/* this object can only be created by a STEntry object */
};

void
StepCheck::setNum(int stepnum)
{
	num.add(stepnum);
};

boolean
StepCheck::inRange(int minstep, int maxstep)
{
	if(num.rangeCount(minstep, maxstep)>0) 
		return True;
	else
		return False;
};


boolean
StepCheck::empty(void)
{
	return(num.empty());
};

//---------------------------------------------------------------------------
// CLASS ST_InLine
// ST_InLine is a subclass of SymbolTable. It takes care of the 
// inline prefixes. 
//---------------------------------------------------------------------------

ST_InLine::ST_InLine(void)	// constructor
{
	reset();
};	

// get the current inline scope.
int
ST_InLine::getScope(void)
{
	return(curr_scope);
};

// set the curr_scope 
void
ST_InLine::setScope(int other_scope)
{
	curr_scope = other_scope;
	if(curr_scope > 0)
		sprintf(prefix,"_P%d",curr_scope);
	else
		prefix[0] = '\0';	// when scope is 0, no prefix.
};

// get the next number in the sequence.
int
ST_InLine::incScope(void)
{
	int retval = curr_scope;
	curr_scope = next_scope++;
	sprintf(prefix,"_P%d",curr_scope);
	return(retval);
};

char *
ST_InLine::getPrefix(void)
{
	return(prefix);
};
   
void 
ST_InLine::reset(void)
{
   next_scope = 1;
   curr_scope = 0;
   prefix[0] = '\0';
};

//---------------------------------------------------------------------------
