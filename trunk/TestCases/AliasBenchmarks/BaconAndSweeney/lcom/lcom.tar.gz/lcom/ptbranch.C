
// FILE: PTNODE.C - PARSE TREE NODES

#include <stdio.h>
#include "lconfig.h"
#include "ptbranch.h"
#include "globals.h"
#include "build.h"

class DF_Entry;

extern DataFlowGraph *CurrentDFG;
extern PTNode        *CurrentPF;

// CLASS PT_if
// CLASS PT_Switch
// CLASS PT_CoBegin

#ifndef lint
static char *sccsid = "@(#)ptbranch.C	1.15 (University of Guelph, VLSI Dept.) 93/06/09";
#endif /* lint */

//------------------------------------------------------------------------
// CLASS CondBranch()  NB: internal only to this file.
//------------------------------------------------------------------------

class CondBranch
{
   PTNodePtr *conds;             // pointer to array of conditions
   DF_EntryPtr *condSource;   // pointer to array of calculated conditions
   PTNodePtr *stmts;             // pointer to array of statement blocks
   BlockEntryPtr *start_block;   // pointer to array of blocks...
                                 //  where branch begins.
   int count;
   boolean testIndex(int num);
   
public:
   CondBranch(int num);
   ~CondBranch(void);
   
   void setCond(int i, PTNode *c);
   PTNode *getCond(int i);

   void setCondSource(int i, DF_Entry *c);
   DF_Entry *getCondSource(int i);
   
   void setStmts(int i, PTNode *c);
   PTNode *getStmts(int i);
   
   void setStartBlock(int i, BlockEntry *c);
   BlockEntry *getStartBlock(int i);

   int getSize(void);
};


//------------------------------------------------------------------------
// CLASS PT_Branch()
//------------------------------------------------------------------------
PT_Branch::PT_Branch(PtreeNodeType btype, int lineno): PTNode(btype, lineno)
{ 
	defaultCase = False;	// assume the default case does not exist
};

   
PT_Branch::~PT_Branch(void)
{ /* do nothing */ };   

// The dataflow can be shared by the IF statements and the SWITCH statements.
// May also be possible to patch some code in for use by COBEGIN.

DF_Entry *
PT_Branch::dataflow(int message)
{
	DATAFLOW_INIT();
	
   // add each condition to the previous data block
   for(int i = 0; i < branchCount; i++)
   {
      PTNode *c = cond_stmt->getCond(i);
      if(c)
      {
         DF_Entry *df = c->dataflow();
//			if(df)
//			{
//				df->isDefinitelySet();	// test to see that the condition is set!
//      	}
         cond_stmt->setCondSource(i, df);
      }
      else
         cond_stmt->setCondSource(i, NULL);
      
   }
   
   if(ErrorCount > 0 )	// do not continue if there was an error.
   {
   	return(NULL);
   }
   
   IfEntry *if_node = new IfEntry(branchCount, getSourceLineNum());
   CurrentDFG->addToCBLK(if_node); 
   
   for(i = branchCount-1; i >= 0 ;  i--)
   {
      CurrentDFG->pushSBLK();
      CurrentDFG->pushDBLK();
      CurrentDFG->pushCBLK();
      
      PTNode *stmt = cond_stmt->getStmts(i);
      if(stmt)
         stmt->dataflow();
         
		if(ErrorCount > 0 )	// do not continue if there was an error.
			return(NULL);

      // find the first usable block entry
      BlockEntry *b = CurrentDFG->getFirstUsableBlockEntry();
      
      cond_stmt->setStartBlock(i,b);   // cond_stmt[i].start_block = b;
      if_node->setCondBlock(i,cond_stmt->getCondSource(i), b);

      CurrentDFG->popBlockLevel();
      
   }
   
   // Need one merge entry for each variable that has changed inside 
   // this IF statement.
      
	SymTbl.start_Lvalue_List();
	STEntry *ste = SymTbl.get_Next_Lvalue();
	
	while(ste)
	{
      if(ste->step_altered.inRange(getStepStartNum(), getStepEndNum()))   
      {
      	int count = branchCount + ((defaultCase == True) ? 0 : 1);
         MergeEntry *merge = new MergeEntry(count, ste, getSourceLineNum());
         
         for (i = 0; i < branchCount; i++)
         {
            DF_Entry *ge = (cond_stmt->getStartBlock(i))->block_trace(ste);
            merge->setCondBlock(i,cond_stmt->getCondSource(i), ge );
         }
         if(defaultCase == False)
         {
		CBlkEntry *cblk = CurrentDFG->peekTOCS();

            DF_Entry *ge = (cblk->getPredBlock())->block_trace(ste);
            merge->setCondBlock(i,NULL, ge );
         }
         //CurrentDFG->addToCBLK(merge);
         if_node->appendMergePt(merge);
      
      }
		ste = SymTbl.get_Next_Lvalue();
   }; /* end while */


   // make sure the data blocks come before the control blocks
   // in the sequential block.
   
   
   CurrentDFG->pushDBLK();
   CurrentDFG->pushCBLK();
   
   if(nextStmt)
      nextStmt->dataflow();
   return(NULL);
};
   
void
PT_Branch::dumpTree(void)
{
   for(int i = 0; i < branchCount; i++)
   {
      PTNode *c = cond_stmt->getCond(i);
      if(c)
      {
      	c->dumpTree();
     	}
     	else
     	{
     		dumpLine("No Condition\n");
     	}
      
      PTNode *s = cond_stmt->getStmts(i);
      if(s)
      {
      	s->dumpTree();
      }
      else
      {
      	dumpLine("NO stmts\n");
      }
  }
};

//------------------------------------------------------------------------
// CLASS PT_if()
//------------------------------------------------------------------------

PT_if::PT_if(PT_tuple *if_then_pairs, int lineno) 
   : PT_Branch(ptreeIf, lineno)     // constructor
{
   if_thens = if_then_pairs;
   branchCount = if_thens->nextCount();
   cond_stmt = new CondBranch(branchCount);
};

void 
PT_if::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();
	setStepNum();
	
   PT_tuple *t = if_thens;
   for(int i=0;i<branchCount;i++)
   {
      t->constantFoldCond(0);		// constant fold the branch condition
      PTNode *c =  t->getTuple(0);	// get the branch condition
      cond_stmt->setCond(i,c);      // 
      if(c)
      {
      	 c->semanticCheck();		// semantic check the condition
      }
      else	// this must be the 'else' case.
      {
      	if(defaultCase == True)
      		Compiler_Error("More than one default case found (?)\n");
      	defaultCase = True;
      }
      
      PTStmt *s = (PTStmt *)(t->getTuple(1));	// get the branch body
      cond_stmt->setStmts(i,s);     // 
         
      int step1,step2;
      step1 = setStepNum();
      if(s) s->semanticCheck();		// semantic check the branch body.
      step2 = setStepNum();
      
      t = (PT_tuple *)(t->getNext());// get the next condition/body pair.
   }
   setStepNum();
   if(nextStmt)
      nextStmt->semanticCheck();

};

PT_if::~PT_if(void)        // destructor
{

   if(if_thens)
   {
      delete if_thens;
      if_thens = NULL;
   }

};

void 
PT_if::dumpTree(void)
{
	incDumpIndent();
	dumpLine("IF\n");
	PT_Branch::dumpTree();
	dumpLine("ENDIF\n");
	decDumpIndent();
	if(nextStmt)
		nextStmt->dumpTree();

};

PTNode *
PT_if::make_clone(int message)
{
	PT_tuple *if_then_clones = (PT_tuple *)(if_thens->make_clone());
	PT_if *clone = new PT_if(if_then_clones,getSourceLineNum());
	clone->copy_baseClass(this,message);
	return(clone);
};

//------------------------------------------------------------------------
// CLASS PT_Switch()
//------------------------------------------------------------------------
PT_Switch::PT_Switch(PTNode *expr, PT_tuple *cases, int lineno) :
   PT_Branch(ptreeSwitch, lineno)
{
   sw_exprvar = expr;
   sw_cases = cases;
   branchCount = sw_cases->nextCount();
   cond_stmt = new CondBranch(branchCount);

};

PT_Switch::~PT_Switch(void)
{
   if(sw_exprvar)
   {
      delete sw_exprvar;
      sw_exprvar = NULL;
   }
   if(sw_cases)
   {
      delete sw_cases;
      sw_cases = NULL;
   }
   
};

void 
PT_Switch::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();
	setStepNum();
	
   sw_exprvar = sw_exprvar->cfold();
   sw_exprvar->semanticCheck();
   
   IntSet x;   // create a set of integers to store all the case constants used.
   int defaultCaseCount = 0;
   
   PT_tuple *t = sw_cases;
   for(int i=0; i<branchCount; i++)
   {
      t->constantFoldCond(0);
      PTNode *cond = t->getTuple(0);
      PTNode *temp_expr = NULL;
      
      while(cond)
      {
         // check that the case is constant.
         if(cond->getNodeType() != ptreeConst)
         {
            Error(cond->getSourceLineNum(),"Case must be a constant!\n"); 
         }
         else
         {
            // check that the case is not duplicated.
            int val = cond->getValue();
            if( x.seek(val) )
               Error(cond->getSourceLineNum(),"Duplicate case (%d)\n",val);
            else
            {
               x.add(val);
               cond->semanticCheck();
            }
         }
         
         PTBinOptr *equals_op = new PTBinOptr(COMPEQUALS, getSourceLineNum());
         char *name = ((PTIdent *)sw_exprvar)->getName();
         PT_Rvalue *dup_expr = new PT_Rvalue(name,cond->getSourceLineNum());
         equals_op->linkChild(dup_expr, cond);
                  
         if(temp_expr)
         {
            PTBinOptr *or_op = new PTBinOptr(OR,getSourceLineNum());
            or_op->linkChild(temp_expr, equals_op);
            temp_expr = or_op;
         }
         else
         {
            temp_expr = equals_op;
         }
         
         cond = cond->getNext();
      }  /* end while */
      
      
      // test to see if this is the "default" case (ie, no expression)
      // and make sure: 
      // 1> that only one is used;
      // 2> that it is the last case in the switch statement
      
      if(!temp_expr)
      {
         if(defaultCaseCount > 0)
         {
            Error(t->getSourceLineNum(),
               "Only one default case allowed per switch statement!\n");
         }
         if(i != branchCount - 1)
         {
            Error(t->getSourceLineNum(),
               "Default case MUST be the last case in a SWITCH statement!\n");
         }
         defaultCaseCount++;
	 defaultCase = True;
      }  
      else
      {
         // build a condition.
         
         temp_expr = new PT_Cond(temp_expr);
         temp_expr->semanticCheck();   // adds symbols to symbol table, if nec.
      }
      
      PTNode *stmt = t->getTuple(1);
      
      int step1, step2;
      step1 = setStepNum();
      if(stmt)
         stmt->semanticCheck();
      step2 = setStepNum();
      
      cond_stmt->setCond(i,temp_expr);
      cond_stmt->setStmts(i,stmt);
      
      t = (PT_tuple *)(t->getNext());
   }/* end for */
   
   caseCount = x.length();
   
   setStepNum();		// get step for end of switch
   
   if(nextStmt)
      nextStmt->semanticCheck();

};

void 
PT_Switch::dumpTree(void)
{
	incDumpIndent();
	dumpLine("SWITCH\n");
	PT_Branch::dumpTree();
	dumpLine("ENDSWITCH\n");
	decDumpIndent();
	if(nextStmt)
		nextStmt->dumpTree();

};


PTNode *
PT_Switch::make_clone(int message)
{
	PTNode *expr_clone = sw_exprvar->make_clone();
	PT_tuple *cases_clone = (PT_tuple *)(sw_cases->make_clone());
	PT_Switch *clone = new PT_Switch(expr_clone, cases_clone,
				getSourceLineNum());
	clone->copy_baseClass(this,message);
	return(clone);
};

//------------------------------------------------------------------------
// CLASS PT_CoBegin
//------------------------------------------------------------------------
PT_CoBegin::PT_CoBegin(PT_tuple *possibleBranches, PTNode *cojoin_expr, 
               int lineno)
            : PT_Branch(ptreeCobegin, lineno)
{
   branches = possibleBranches;
   branchCount = branches->nextCount();
   cojoin = cojoin_expr;
   cond_stmt = new CondBranch(branchCount);
};

            
PT_CoBegin::~PT_CoBegin(void)
{
   if(branches)
      delete branches;
   if(cojoin)
      delete cojoin;


};
void 
PT_CoBegin::semanticCheck(void)
{
	SEMANTIC_CHECK_INIT();
	setStepNum();
	
   PT_tuple *t = branches;
   
   for (int i = 0; i<branchCount; i++)
   {
      PTNode *c = t->getTuple(0);   // get the condition
      if(c)
      {
         c->semanticCheck();
         t->constantFoldCond(0);
         c = t->getTuple(0);
      }
      
      cond_stmt->setCond(i,c);
      
      PTNode *s = t->getTuple(1);   // get the statement block
      if(s)
         s->semanticCheck();
      cond_stmt->setStmts(i,s);
   
      t = (PT_tuple *)(t->getNext());
   };
   
   
   // Need to add a check to see that variables can only be altered in
   // one of the branches!!!!!
   
   // the cojoin expression should be a constant, and its value should
   // not exceed the number of parallel branches..
   if(!cojoin)
   {
      cojoin = new PTConst(branchCount,getDefaultPathWidth(Data_int));
   }
   else
   {
      cojoin = cojoin->cfold();
      if(cojoin->isConstant())
      {
         long num_cojoins = cojoin->getValue();
         if(num_cojoins > branchCount)
         {
            Error(cojoin->getSourceLineNum(),
               "Cojoin expression must be <= number of COBEGIN branches.\n");
         }
         else if(num_cojoins < 1)
         {
            Error(cojoin->getSourceLineNum(),
               "Cojoin expression must >= 1.\n");
         }
      }
      else
      {
         Error(cojoin->getSourceLineNum(),
            "Cojoin expression must be a constant!\n");
      }
   }
   
   setStepNum();
   
   if(nextStmt)
      nextStmt->semanticCheck();

};


DF_Entry *
PT_CoBegin::dataflow(int message)
{
	DATAFLOW_INIT();
	
   // add each condition to the previous data block
   for(int i = 0; i < branchCount; i++)
   {
      PTNode *c = cond_stmt->getCond(i);
      if(c)
      {
         DF_Entry *df = c->dataflow();
         cond_stmt->setCondSource(i, df);
      }
      else
         cond_stmt->setCondSource(i, NULL);
      
   }
   
   ParEntry *x = new ParEntry(branchCount,cojoin->getValue(),getSourceLineNum());
   CurrentDFG->addToCBLK(x); 
   
   for(i = branchCount-1; i >= 0 ;  i--)
   {
      CurrentDFG->pushSBLK();
      CurrentDFG->pushDBLK();
      CurrentDFG->pushCBLK();
      
      PTNode *s = cond_stmt->getStmts(i);
      if(s)
         s->dataflow();
         
      // find the first usable block entry
      BlockEntry *b = CurrentDFG->getFirstUsableBlockEntry();
      
      cond_stmt->setStartBlock(i,b);   // cond_stmt[i].start_block = b;
      x->setCondBlock(i,cond_stmt->getCondSource(i), b);

      CurrentDFG->popBlockLevel();
      
      
   }
   // make sure the data blocks come before the control blocks
   // in the sequential block.
   
   
   CurrentDFG->pushDBLK();
   CurrentDFG->pushCBLK();
   
   if(nextStmt)
      nextStmt->dataflow();
   return(NULL);
}; 

void 
PT_CoBegin::dumpTree(void)
{
	incDumpIndent();
	dumpLine("COBEGIN\n");
	PT_Branch::dumpTree();
	dumpLine("COEND\n");
	decDumpIndent();
	if(nextStmt)
		nextStmt->dumpTree();

};

PTNode *
PT_CoBegin::make_clone(int message)
{
	PT_tuple *branches_clone = (PT_tuple *)(branches->make_clone());
	
	// The cojoin statement may be null.
	PTNode *cojoin_clone = (cojoin) ? cojoin->make_clone() : NULL;
	PT_CoBegin *clone = new PT_CoBegin(branches_clone, cojoin_clone,
			getSourceLineNum());
			
	clone->copy_baseClass(this,message);
	return(clone);
};


//------------------------------------------------------------------------
// CLASS CondBranch
//------------------------------------------------------------------------

CondBranch::CondBranch(int num)
{
   count       = num;
   
   conds       = new PTNodePtr[count];
   condSource  = new DF_EntryPtr[count];
   stmts       = new PTNodePtr[count];
   start_block = new BlockEntryPtr[count];
   
   // initialize all blocks to null
   for(int i=0;i<count;i++)
   {
      conds[i]       = NULL;
      condSource[i]  = NULL;
      stmts[i]       = NULL;
      start_block[i] = NULL;
   }
}; 

CondBranch::~CondBranch(void)
{
   delete conds;
   delete condSource;
   delete stmts;
   delete start_block;

};
int 
CondBranch::getSize(void)
{  
   return(count);
}

boolean 
CondBranch::testIndex(int num)
{
   if(num > count+1 || num < 0)
   {
      Compiler_Error("CondBranch: %d out of range\n",num);
      return(False);
   }
   return(True);
};

void  
CondBranch::setCond(int i, PTNode *c)
{
   testIndex(i);
   conds[i] = c;
};

PTNode * 
CondBranch::getCond(int i)
{
   testIndex(i);
   return(conds[i]);
};

void  
CondBranch::setCondSource(int i, DF_Entry *c)
{
   testIndex(i);
   condSource[i] = c;
   
};

DF_Entry * 
CondBranch::getCondSource(int i)
{
   testIndex(i);
   return(condSource[i]);
};

void  
CondBranch::setStmts(int i, PTNode *c)
{
   testIndex(i);
   stmts[i] = c;
};

PTNode * 
CondBranch::getStmts(int i)
{
   testIndex(i);
   return(stmts[i]);
};

void  
CondBranch::setStartBlock(int i, BlockEntry *c)
{
   testIndex(i);
   start_block[i] = c;
};

BlockEntry * 
CondBranch::getStartBlock(int i)
{
   testIndex(i);
   return(start_block[i]);
};




/******************************************************************************/
// PTNode *setupSwitchStmt() is used here as a function to simplify the
// grammar, but also to ensure that the expression variable used in the
// switch statement does not have to be re-evaluated for each test case
// if that expression variable is anything more complex than a single
// constant or identifier.  This function returns a segment of a parse
// tree in one of the two following forms:
//
// 1: if the expression variable does not need any recalculation (ie,
//    it is a constant or identifier), then the parse tree segment is
//    only a PT_Switch node.
// 2: Otherwise, the parse tree segment becomes two parse tree nodes
//    linked together. The first is a PTAssign node with the statement
//    _Temp1 := exprvar.  To this PTAssign node is chained (nextStmt)
//    the PT_Switch node, with its expression variable being set
//    to the temporary variable (_Temp1) assigned to in the preceding
//    statement.

/******************************************************************************/
PTNode *setupSwitchStmt(PTNode *exprvar, PT_tuple *cases, 
                        int startline)
{
   PT_Switch *sw;
   
   PtreeNodeType type = exprvar->getNodeType();
   if((type == ptreeBinOptr) || (type == ptreeUnaryOptr) ||
      (type == ptreeProcCall))
   {
      char *name = mallocNameTemp();
      
      PTAssign *assign = new PTAssign(startline);
      assign->linkChild( new PT_Lvalue(name,startline), exprvar);

      sw = new PT_Switch(new PT_Rvalue(name,startline),
                              cases, startline);

      assign->linkNext(sw);
      delete name;

      return(assign);
   }
   else
   {
         
      sw = new PT_Switch(exprvar,cases, startline);
      return(sw);
   }

};


/******************************************************************************/

