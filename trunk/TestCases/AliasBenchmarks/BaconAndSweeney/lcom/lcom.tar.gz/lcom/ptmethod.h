
// FILE: PTMETHOD.H - PARSE TREE NODES FOR METHODS AND MODULES


#ifndef PTMETHOD_H 
#define PTMETHOD_H


#include "tokens.h"
#include "boolean.h"
#include "dataflow.h"

//-----------------------------------------------------------------------
// The following classes are defined in this file, in this order.
//
//////////////////////// Not Implemented Yet!
class PTMethodDecl;
class PTMethodList;
class PTImplementation;
class PTInterfaceMap;
class PTProcName;
class PTConstraint;
class PTVersionConstraint;
	

//-----------------------------------------------------------------------
class PTMethodDecl : public PTNode
{
public:
	PTMethodDecl(void);

};
//-----------------------------------------------------------------------
class PT_VersionID : public PTNode
{
	char *proc;
	char *version;
	int 	count;
	boolean	oneof;
	
public:
	PT_VersionID(char *procname, char *version_name, int countx); // constructor
	~PT_VersionID(void);	// destructor
	void print(void);
	void setOneOf(void);
};
//-----------------------------------------------------------------------
class PT_VersionDecl : public PTNode
{
	char *version;
	char *proc;
	
	boolean areaDefined;
	int maxarea;
	
	boolean timeDefined;
	int maxtime;
	
	List mustuse;
	List mayuse;
	List closedModule;
	List replace;
	List nocost;

	void printList(char *title, List &mylist);
	void appendList(List &mylist, PT_VersionID *id);
	
public:
	PT_VersionDecl(char *version, char *proc);	// constructor
	~PT_VersionDecl(void);	// destructor
	
	void setMustUse(PT_VersionID *list);						
	void setMayUse(PT_VersionID *list); 								
	void setClosedModule(PT_VersionID *list); 							
	void setReplace(PT_VersionID *id, PT_VersionID *list);							
	void setNoCost(PT_VersionID *list); 							
	void setArea(int area, int lineno);							
	void setTime(int time, int lineno);
	
	void print(void);
	VIRTUAL void semanticCheck(void);
};

//-----------------------------------------------------------------------
class PT_OneOf : public PTNode
{

	PT_VersionID 	*vlist;
	int 				count;

public:
	PT_OneOf(PT_VersionID *listOfVersionIds);	// constructor
	~PT_OneOf(void);	// destructor

};

//-----------------------------------------------------------------------
class PTMethodList : public PTNode
{
public:
	PTMethodList(void);
};
//-----------------------------------------------------------------------
class PTImplementation : public PTNode
{
public:
	PTImplementation(void);
};
//-----------------------------------------------------------------------
class PTInterfaceMap : public PTNode
{
public:
	PTInterfaceMap(void);

};
//-----------------------------------------------------------------------
class PTProcName : public PTNode
{
public:
	PTProcName(void);

};
//-----------------------------------------------------------------------
class PTConstraint : public PTNode
{
public:
	PTConstraint(void);

};
//-----------------------------------------------------------------------
class PTVersionConstraint : public PTNode
{
public:
	PTVersionConstraint(PTNode *version, PTNode *constraints);

};
//-----------------------------------------------------------------------


#endif
