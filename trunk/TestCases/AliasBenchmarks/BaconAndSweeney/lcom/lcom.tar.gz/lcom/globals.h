/* FILE: globals.h */


#ifndef GLOBALS_H
#define GLOBALS_H

#ifndef MAIN
#define EXTERN extern
#else
#define EXTERN
#endif


#include <stdio.h>
#include "boolean.h"
#include "errors.h"



EXTERN struct sourceFile_S	CurrentSourceFile;

EXTERN char 		*SourceFileName;
EXTERN char 		*DestinationFileName;

class OutputFile;
EXTERN OutputFile *Outfile;

EXTERN int 	CurrentScope;

class SymbolTable;
EXTERN SymbolTable SymTbl;

class GarbageCollector;
EXTERN GarbageCollector Trash;

/* Compiler Flags */

class CommandLineFlags
{

 public:

	 boolean Debug;				// -d
	 boolean TokenStream;		// -t
	 boolean YaccDebug;			// -y
	 int		NewHashSize;		// -hX
	 boolean MemDebug;			// -m
	 boolean WarningsSuppress;	// -w
	 boolean DumpParseTree;		// -p
	 boolean CommonSubExpr;		// -c
	 boolean CopyPropogation;	// -e
	 boolean DefinitelySet;		// -s
	 boolean DeadCodePruning;	// -f
	 boolean InlineCode;			// -i
	 boolean N_AryOperators;	// -n
	 boolean LogicSequential;	// -l
	boolean FrequencyReduction;	// -g
	boolean OptimizeAll;		// -o
	boolean QuietMode;		// -q
	 
	 int count;	// number of flags that have been set.
	 
	 CommandLineFlags(void);	// constructor
	 void setFlag(char *s);
	 void displayUsage(char *progname);
};

EXTERN CommandLineFlags CLFlags;


// the following are always extern, even to the main program.

extern FILE 		*yyin;

#endif
