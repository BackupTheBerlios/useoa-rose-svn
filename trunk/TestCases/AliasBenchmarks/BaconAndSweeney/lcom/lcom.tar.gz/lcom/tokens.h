// FILE: TOKENS.H

#ifndef TOKENS_H
#define TOKENS_H

#include "yystype.h"
#include "lgrammar.h"

// The following are defined in 'tokenstr.c'
//extern char *TokenString[];
//extern int MAXTOKEN, MINTOKEN;

// These are defined in 'tokens.c'
char *getTokenStr(int token);
void getTokenStream(void);

char *getBinOptrStr(int operationToken, boolean flagError = True);
char *getUnaryOptrStr(int operationToken, boolean flagError = True);


#endif
