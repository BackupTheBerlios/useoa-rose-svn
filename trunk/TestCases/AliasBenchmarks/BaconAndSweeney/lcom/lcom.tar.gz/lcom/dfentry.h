/*****************************************************************************/
/* FILE: dfentry.h */
/*****************************************************************************/

#ifndef DFENTRY_H
#define DFENTRY_H

#include "list.h"
#include "utils.h"
#include "getlines.h"
#include "blkentry.h"
#include "virtual.h"

class STEntry; // defined in file symtable.h, but needed for forwarding.

#define MAXBRANCHCOUNT 10

// Entry Types
enum enumEntryType {Entry_optr, Entry_opnd, Entry_symtbl, 
                     Entry_if,  Entry_ctrl, Entry_loop, Entry_none};
                     
typedef enum enumEntryType EntryType;

// Define the number of entry types.
#define NUM_ENTRY_TYPES (Entry_none + 1)

// Data Types
enum enumDataType { Data_generic = 1, Data_bit, Data_int, Data_real };
typedef enum enumDataType DataType;

class BlockEntry;
typedef BlockEntry*     BlockEntryPtr;

// list of classes declared in this file (for forwarding purposes).
class DF_Entry;
class OptrEntry;
class OptrUnaryEntry;
class OptrAssignEntry;
class OptrProcEntry;
class OpndEntry;
class IfEntry;
class ParEntry;
class LoopEntry;
class MergeEntry;
class LoopMergeEntry;
class CtrlEntry;

class BlockEntry;
class SBlkEntry;
class DBlkEntry;
class CBlkEntry;

class DataFlowGraph;

typedef DF_Entry*    DF_EntryPtr;


/*****************************************************************************/

// Fucntion prototypes
int getDefaultPathWidth(DataType x);

/*****************************************************************************/
// Class DF_Entry
/*****************************************************************************/

class DF_Entry
{
   
protected:
   int index;
   DataFlowGraph *dfg;
   EntryType entryType;
//   STEntry *dfste;
   boolean resolvedFlag;
   MagicNumber magic;
   
   boolean	deadCodeFlag;
   BlockEntry *mylocalblock;
   
   // constructor (should only be created by an inherited class).
   DF_Entry(EntryType ttype, int line_no = 0);

public:
   // destructor should be virtual, so that derived classes
   // can use their own destructors, if necessary.
   virtual ~DF_Entry(void);   
      
   void setIndex(int i);
   
   EntryType getType(void);
   
   int      getIndex(void);
//   void     setDFSTEntry(STEntry *st);
//   STEntry  *getDFSTEntry(void);
//   boolean  testDFSTEntry(STEntry *st);
   
   virtual void print(void);
   virtual void resolveIndices(void);
   virtual void setSourceList(DF_Entry *x, int paramCount = 0);
   
   virtual DataType  getDataType(void);
   virtual int       getPathWidth(void);
   
   virtual boolean isDefinitelySet(boolean printFlag = True);
   virtual DF_Entry *block_trace(STEntry *ste, boolean searchPred = True);
   virtual DF_Entry *commSubExpr(DF_Entry *df, boolean localBlock);
	virtual DF_Entry *copyPropogate(void);
	virtual boolean isConstant(void);
	virtual void appendMergePt(DF_Entry *x);
	virtual void pruneDeadCode(void);
 	virtual boolean fixedTimeExecution(void);
 	  
   virtual char *getName(void);
   SourceInfo sourceinfo;
   
 	void setLocalBlock(BlockEntry *block);
 	virtual DF_Entry *getRealSource(void);
   
};


/*****************************************************************************/
// An OptrEntry represents a single line in the operand table of the 
// dataflow graph.
/*****************************************************************************/
class OptrEntry : public DF_Entry
{
private:   
   DataType datatype;
   int      pathwidth;
   
protected:	// can only be accessed by a derived class.
   List     arglist; // list of sources for this operation.
   List		results;	// list of where results of operation are stored.
   int 		operationToken;
   char 		*operationStr;

	friend void divideIntoSubexpressions(OptrEntry *me);
  
public:
   OptrEntry(int opToken, int line_no) ; // constructor
 //  OptrEntry(char *name) ; // constructor
   ~OptrEntry(void); // destructor
   
   void print(void);
   void resolveIndices(void); 
   
   virtual void setSourceList(DF_Entry *operand, int paramCount = 0); 
   virtual void setResultsList(DF_Entry *operand);
   virtual char *getId(void);
   
   void	setResultType(DataType dt, int pathw);
   
   VIRTUAL DataType  getDataType(void);
   VIRTUAL int       getPathWidth(void);
    
   VIRTUAL boolean isDefinitelySet(boolean printFlag = True);
   VIRTUAL DF_Entry *block_trace(STEntry *ste, boolean searchPred = True);
   VIRTUAL DF_Entry *commSubExpr(DF_Entry *df, boolean localBlock);
	VIRTUAL DF_Entry *copyPropogate(void);
	int getOptrToken(void);   
	VIRTUAL void pruneDeadCode(void);
 	VIRTUAL boolean fixedTimeExecution(void);
 	VIRTUAL DF_Entry *getRealSource(void);
 	
};
/*****************************************************************************/
class OptrUnaryEntry : public OptrEntry
{
public:
	OptrUnaryEntry(int opToken, int line_no);
	~OptrUnaryEntry(void);
	VIRTUAL DF_Entry *commSubExpr(DF_Entry *df, boolean localBlock);
	VIRTUAL char *getId(void);
//	VIRTUAL void pruneDeadCode(void);
};

/*****************************************************************************/
// An OptrAssignEntry is a special case of the OptrEntry.
// It handles only simple assignment statements ( a := b );
/*****************************************************************************/
class OptrAssignEntry : public OptrEntry
{
   DF_Entry *source;
 //  DF_Entry *destination;
   
   DataType datatype;
   int      pathwidth;
   
public:
   OptrAssignEntry(int line_no) ; // constructor
   ~OptrAssignEntry(void); // destructor
   
   VIRTUAL void print(void);
   VIRTUAL void resolveIndices(void); 
   
   VIRTUAL void setSourceList(DF_Entry *operand, int paramCount = 0); 
   VIRTUAL void setResultsList(DF_Entry *operand);
	VIRTUAL boolean isDefinitelySet(boolean printFlag = True);
	VIRTUAL DF_Entry *copyPropogate(void);
   VIRTUAL DF_Entry *commSubExpr(DF_Entry *df, boolean localBlock);
	VIRTUAL char *getId(void); 
	VIRTUAL void pruneDeadCode(void);
 	VIRTUAL boolean fixedTimeExecution(void);
 	VIRTUAL DF_Entry *getRealSource(void);
};

/*****************************************************************************/
// An OptrProcEntry is a special case of an OptrEntry.
// It deals only with procedure calls and function calls.
/*****************************************************************************/
class OptrProcEntry : public OptrEntry
{
	char *id;
public:
   OptrProcEntry(char *name, int line_no) ; // constructor
   ~OptrProcEntry(void); // destructor
   VIRTUAL char *getId(void);
   VIRTUAL void setSourceList(DF_Entry *operand, int paramCount = 0); 
   VIRTUAL boolean isDefinitelySet(boolean printFlag = True);
   VIRTUAL void resolveIndices(void);
	VIRTUAL void pruneDeadCode(void);
 	VIRTUAL boolean fixedTimeExecution(void);
};

/*****************************************************************************/
// An OpndEntry represents a single line in the operand table of the 
// dataflow graph.
/*****************************************************************************/
class OpndEntry : public DF_Entry
{
   DF_Entry *source; // can be an optr or ST.
   int parameterNumber;

protected:
   STEntry *dfste;
   
public:
   OpndEntry(STEntry *ste, int line_no); // constructor
   void print(void);
   void resolveIndices(void); 
   void setSourceList(DF_Entry *src, int paramCount = 0);
// void add(void);
// void setId(char *opnd);
   OpndEntry *locate(char *name);
   
   VIRTUAL DataType getDataType(void);
   VIRTUAL int getPathWidth(void);
   virtual boolean isMergePoint(void);
   
   VIRTUAL boolean isDefinitelySet(boolean printFlag = True);
   VIRTUAL DF_Entry *block_trace(STEntry *ste, boolean searchPred = True);
   VIRTUAL DF_Entry *commSubExpr(DF_Entry *df, boolean localBlock);
	VIRTUAL DF_Entry *copyPropogate(void);
	VIRTUAL void pruneDeadCode(void);
// 	VIRTUAL boolean fixedTimeExecution(void);
	VIRTUAL char *getName(void);
 	VIRTUAL DF_Entry *getRealSource(void);
};

/*****************************************************************************/
// Class IfEntry
/*****************************************************************************/

class IfEntry : public DF_Entry
{
   int branchCount;
// DF_Entry *condSrc[MAXBRANCHCOUNT];
// BlockEntry   *block[MAXBRANCHCOUNT];
   DF_EntryPtr    *condSrc;
   BlockEntryPtr  *block;
   List mergeList;
   
public:
   IfEntry(int count, int line_no);
   ~IfEntry(void);   // destructor

   void print(void);
   void resolveIndices(void); 
   void setCondBlock(int index, DF_Entry *c, BlockEntry *b);
   VIRTUAL DF_Entry *block_trace(STEntry *ste, boolean searchPred = True);
   VIRTUAL void appendMergePt(DF_Entry *x);
	VIRTUAL void pruneDeadCode(void);
 	VIRTUAL boolean fixedTimeExecution(void);
};

/*****************************************************************************/
// Class MergeEntry
/*****************************************************************************/

class MergeEntry : public OpndEntry
{
   int branchCount;
   DF_EntryPtr *condSrc;
   DF_EntryPtr *change_pt;
   
public:
   MergeEntry(int count, STEntry *dfst, int line_no);
   ~MergeEntry(void);   // destructor
   
   void print(void);
   void resolveIndices(void); 
   void setCondBlock(int index, DF_Entry *cond, DF_Entry *chge_pt);
   VIRTUAL boolean isMergePoint(void);
   VIRTUAL boolean isDefinitelySet(boolean printFlag = True);
	VIRTUAL DF_Entry *copyPropogate(void);
   VIRTUAL DF_Entry *commSubExpr(DF_Entry *df, boolean localBlock);
	VIRTUAL void pruneDeadCode(void);
 	VIRTUAL DF_Entry *getRealSource(void);
};
/*****************************************************************************/
// Class LoopEntry
/*****************************************************************************/

class LoopEntry : public DF_Entry
{  
   BlockEntry *loopConditionBlock;
   DF_Entry   *loopConditionSignal;
   BlockEntry *loopBody;
   List mergeList;
   
public:
   LoopEntry(int line_no);
   ~LoopEntry(void);
   void print(void);
   void resolveIndices(void); 
   void setCondBlock(BlockEntry *block, DF_Entry *condition);
   void setBodyBlock(BlockEntry *block);
   VIRTUAL DF_Entry *block_trace(STEntry *ste, boolean searchPred = True);
   VIRTUAL void appendMergePt(DF_Entry *x);
	VIRTUAL void pruneDeadCode(void);
 	VIRTUAL boolean fixedTimeExecution(void);
};
/*****************************************************************************/
// Class LoopMergeEntry
/*****************************************************************************/

class LoopMergeEntry : public OpndEntry
{
   DF_Entry *pre, *post;
   boolean recursivePropogateFlag;
  
public:
   LoopMergeEntry(STEntry *dfst, int line_no);
   ~LoopMergeEntry(void);
   void print(void);
   void resolveIndices(void); 
   void set(DF_Entry *before, DF_Entry *after);
   VIRTUAL boolean isMergePoint(void);
   VIRTUAL boolean isDefinitelySet(boolean printFlag = True);
   VIRTUAL DF_Entry *commSubExpr(DF_Entry *df, boolean localBlock);
	VIRTUAL DF_Entry *copyPropogate(void);
	VIRTUAL void pruneDeadCode(void);
 	VIRTUAL DF_Entry *getRealSource(void);
};

/*****************************************************************************/
// Class ParEntry
/*****************************************************************************/

class ParEntry : public DF_Entry
{
   int branchCount;
   int cojoinCount;
   DF_EntryPtr    *condSrc;
   BlockEntryPtr  *block;
   
public:
   ParEntry(int branch_count, int cojoin_count, int line_no);
   ~ParEntry(void);  // destructor

   void print(void);
   void resolveIndices(void); 
   void setCondBlock(int index, DF_Entry *c, BlockEntry *b);
   VIRTUAL DF_Entry *block_trace(STEntry *ste, boolean searchPred = True);
	VIRTUAL void pruneDeadCode(void);
 	VIRTUAL boolean fixedTimeExecution(void);
};


/*****************************************************************************/
// Class CtrlEntry
/*****************************************************************************/


class CtrlEntry : public DF_Entry
{
   BlockEntry *block;
public:
   CtrlEntry(void);
   CtrlEntry(BlockEntry *childblock);
   void setChildBlock(BlockEntry *b);
   BlockEntry *getChildBlock(void);
   void print(void);
   void resolveIndices(void); 
   boolean isUsable(void);
   VIRTUAL DF_Entry *block_trace(STEntry *ste, boolean searchPred = True);
	VIRTUAL void pruneDeadCode(void);
 	VIRTUAL boolean fixedTimeExecution(void);
};




/*****************************************************************************/
//  DFCount... functions (maybe this should be an object ?)
/*****************************************************************************/
long DFCount_getCount(EntryType x);
void DFCount_reset(EntryType x);
void DFCount_resetAll(void);
void DFCount_increment(EntryType x);




#endif
