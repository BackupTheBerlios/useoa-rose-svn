/* cbase.h */

#ifndef CBASE

#define CBASE

#define BOOLEAN int
#define TRUE 1
#define FALSE 0

extern "C" {
#include <stdio.h>
#include <ctype.h>
#include <assert.h>
}
#endif
