/* rbase.h */
#ifndef RBASE

//#define ALL_VIRTUALS 1

# ifdef ALL_VIRTUALS
#   define VIRTUAL virtual
# else
#   define VIRTUAL 
# endif

#define RBASE

typedef enum {DevicePacket, WorkPacket} 
	PacketKind;
typedef enum {Idler, Worker, HandlerA, HandlerB, DeviceA, DeviceB}
	Identity;

#define NTASKS 6                        /* # elements of Identity */
				 	/* = # of tasks		  */
#define NoWork 0 // NULL
#define NoTask 0 // NULL

#endif
