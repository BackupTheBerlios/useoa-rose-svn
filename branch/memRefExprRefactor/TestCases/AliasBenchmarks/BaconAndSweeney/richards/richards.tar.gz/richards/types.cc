/* types.c */

#include "types.h"

/*
// AddToList - list utility (append elem at end of list, return head)
*/
Packet* Packet::AddToList(Packet *elem)
{   Packet *p, *next;

    elem->SetLink(NoWork);
    if (this != NoWork) {
      p = this;
      while((next = p->Link()) != NoWork) p = next;
      p->SetLink(elem);
      return this;
    } else {
      return elem;
    }
}

Packet::Packet(Packet *l, Identity id, PacketKind k)
{
    link = l;
    ident = id;
    kind = k;
    datum = 1;
    for(int i = 0; i < 4; i++) data[i] = 0;
}
