/* richards.h */
/* Richards benchmark in C++, translated from Smalltalk */
/* uh 2/2/89  */

#include "rbase.h" 
#include "tasks.h"

/*
// RBench class definition
*/

class RBench {
    private:
         TaskControlBlock *taskList, *currentTask;
         Identity currentTaskIdent;
         TaskControlBlock *taskTable[NTASKS];
         int layout;
         int holdCount, queuePacketCount;

         /* creation */
         VIRTUAL void CreateDevice (Identity id, int prio,  Packet *work,
                           TaskState *state);
         VIRTUAL void CreateHandler(Identity id, int prio,  Packet *work,
                           TaskState *state);
         VIRTUAL void CreateIdler  (Identity id, int prio,  Packet *work,
                           TaskState *state);
         VIRTUAL void CreateWorker (Identity id, int prio,  Packet *work,
                           TaskState *state);
         VIRTUAL void EnterTask(Identity id, TaskControlBlock *t);

         /* scheduling */
         VIRTUAL void Schedule();

         /* initializing */
         VIRTUAL void InitScheduler();
         VIRTUAL void InitTrace();

         BOOLEAN _tracing;
    public:
         /* task management */
         VIRTUAL TaskControlBlock *FindTask(Identity id);
         VIRTUAL TaskControlBlock *HoldSelf();
         VIRTUAL TaskControlBlock *QueuePacket(Packet *p);
         VIRTUAL TaskControlBlock *Release(Identity id);
         VIRTUAL TaskControlBlock *Wait();
         /* tracing */
	 VIRTUAL BOOLEAN tracing() { return _tracing; }
         VIRTUAL void Trace(Identity id);

         VIRTUAL void Start(BOOLEAN askTrace);
};

extern RBench* bm;		// benchmark currently executing
