/* tasks.h - definitions of TaskState, TaskControlBlock and xxxTCB 
 * The subclasses of TaskControlBlock differ only in their
 * implementation of the action function 				  */

#ifndef TASKS

#define TASKS

#include "types.h"

/*
// TaskState
*/

class TaskState {
    protected:
        BOOLEAN packetPending, taskWaiting, taskHolding;
	
    public:
        /* initializing */
	TaskState() {
	  packetPending = TRUE; taskWaiting = taskHolding = FALSE;}
	VIRTUAL void PacketPending() {
	  packetPending = TRUE; taskHolding = taskWaiting = FALSE;}
	VIRTUAL void Waiting() {
	  packetPending = taskHolding = FALSE; taskWaiting = TRUE;}
	VIRTUAL void Running() {
	  packetPending = taskWaiting = taskHolding = FALSE;}
	VIRTUAL void WaitingWithPacket() {
	  packetPending = taskWaiting = TRUE; taskHolding = FALSE;}
	/* accessing */
	VIRTUAL BOOLEAN IsPacketPending() {return packetPending;}
	VIRTUAL BOOLEAN IsTaskWaiting() {return taskWaiting;}
	VIRTUAL BOOLEAN IsTaskHolding() {return taskHolding;}
	VIRTUAL void SetTaskHolding(BOOLEAN state) {taskHolding = state;}
	VIRTUAL void SetTaskWaiting(BOOLEAN state) {taskWaiting = state;}
	/* testing */
	VIRTUAL BOOLEAN IsRunning() {
	  return !packetPending && !taskWaiting && !taskHolding;}
	VIRTUAL BOOLEAN IsTaskHoldingOrWaiting() {
	  return taskHolding || !packetPending && taskWaiting;}
	VIRTUAL BOOLEAN IsWaiting() {
	  return !packetPending && taskWaiting && !taskHolding;}
	VIRTUAL BOOLEAN IsWaitingWithPacket() {
	  return packetPending && taskWaiting && !taskHolding;}
};

/*
// TaskControlBlock
*/

class TaskControlBlock : public TaskState {

    protected:
        TaskControlBlock *link;
	Identity ident;
	int priority;
	Packet *input;
	void *handle;
	
    public:
        /* initializing */
        TaskControlBlock(TaskControlBlock *l, Identity id, int prio,
                         Packet *initialWork, TaskState *initialState,
                         void *privateData);
	/* accessing */
        VIRTUAL Identity Ident() {return ident;}
        VIRTUAL int Priority() {return priority;}
        VIRTUAL TaskControlBlock* Link() {return link;}
	/* scheduling */
        VIRTUAL TaskControlBlock* AddPacket(Packet *p, TaskControlBlock *old);
        virtual TaskControlBlock* ActionFunc(Packet *p, void *handle);
        VIRTUAL TaskControlBlock* RunTask();
};

/*
// DeviceTCB 
*/

class DeviceTCB : public TaskControlBlock {
    public:
        DeviceTCB(TaskControlBlock *l, Identity id, int prio,
                  Packet *initialWork, TaskState *initialState,
                  void *privateData) 
	  : TaskControlBlock(l, id, prio, initialWork, initialState, privateData){}
	TaskControlBlock* ActionFunc(Packet *p, void *handle);
};


/*
// HandlerTCB
*/

class HandlerTCB : public TaskControlBlock {
    public:
        HandlerTCB(TaskControlBlock *l, Identity id, int prio,
                   Packet *initialWork, TaskState *initialState,
                   void *privateData)
	  : TaskControlBlock(l, id, prio, initialWork, initialState, privateData){}
        TaskControlBlock* ActionFunc(Packet *p, void *handle);
};


/*
// IdlerTCB
*/

class IdlerTCB : public TaskControlBlock {
    public:
        IdlerTCB(TaskControlBlock *l, Identity id, int prio,
                 Packet *initialWork, TaskState *initialState,
                 void *privateData)
	  : TaskControlBlock(l, id, prio, initialWork, initialState, privateData){}
        TaskControlBlock* ActionFunc(Packet *p, void *handle);
};


/*
// WorkerTCB
*/

class WorkerTCB : public TaskControlBlock {
    public:
        WorkerTCB(TaskControlBlock *l, Identity id, int prio,
                  Packet *initialWork, TaskState *initialState,
                  void *privateData) 
	  : TaskControlBlock(l, id, prio, initialWork, initialState, privateData){}
        TaskControlBlock* ActionFunc(Packet *p, void *handle);
};

#endif
