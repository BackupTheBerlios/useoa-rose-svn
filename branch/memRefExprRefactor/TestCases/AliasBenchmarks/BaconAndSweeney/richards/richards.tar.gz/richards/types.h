/* types.h -- basic classes (Packet, {Device,Idle,...}TaskRec)	*/

#include "cbase.h"
#include "rbase.h"

/*
// Packet
*/

class Packet {
    private:
        Packet *link;		// next packet in queue
	Identity ident;		// Idle, Worker, DeviceA, ...
	PacketKind kind;	// DevicePacket or WorkPacket
	int datum;
	char data[4];
    public:
        Packet(Packet *l, Identity id, PacketKind k);
	VIRTUAL char *Data() {return data;}
	VIRTUAL void SetData(char d[4]) {
	  for(int i=0; i < 4; i++) data[i] = d[i];}
        VIRTUAL int Datum() {return datum;}
        VIRTUAL void SetDatum(int n) {datum = n;}
	VIRTUAL Identity Ident() {return ident;}
	VIRTUAL void SetIdent(Identity i) {ident = i;}
	VIRTUAL PacketKind Kind() {return kind;}
	VIRTUAL void SetKind(PacketKind k) {kind = k;}
	VIRTUAL Packet *Link() {return link;}
	VIRTUAL void SetLink(Packet *l) {link = l;}

	// list utility (append elem at end of rcvr list, return head)
	Packet *AddToList(Packet *elem);
};


/*
// DeviceTaskRec
*/

class DeviceTaskRec {
    private:
        Packet *pending;
    public:
        DeviceTaskRec() {pending = NoWork;}
	VIRTUAL Packet *Pending() {return pending;}
	VIRTUAL void SetPending(Packet *p) {pending = p;}
};



/*
// IdleTaskRec 
*/

class IdleTaskRec {
    private:
        int control, count;
    public:
        IdleTaskRec() {control = 1; count = 10000;}
        VIRTUAL int Control() {return control;}
        VIRTUAL void SetControl(int n) {control = n;}
        VIRTUAL int Count() {return count;}
        VIRTUAL void SetCount(int n) {count = n;}
};


/*
// HandlerTaskRec
*/

class HandlerTaskRec {
    private:
        Packet *workIn, *deviceIn;
    public:
        HandlerTaskRec() {workIn = deviceIn = NoWork;}
        VIRTUAL Packet *WorkIn() {return workIn;}
        VIRTUAL void SetWorkIn(Packet *p) {workIn = p;}
        VIRTUAL Packet *WorkInAdd(Packet *p) {
	  return workIn = workIn->AddToList(p);}
        VIRTUAL Packet *DeviceIn() {return deviceIn;}
        VIRTUAL void SetDeviceIn(Packet *p) {deviceIn = p;}
        VIRTUAL Packet *DeviceInAdd(Packet *p) {
	  return deviceIn = deviceIn->AddToList(p);}
};


/*
// WorkerTaskRec
*/

class WorkerTaskRec {
    private:
        Identity destination;
	int count;
    public:
        WorkerTaskRec() {destination = HandlerA; count = 0;}
        VIRTUAL int Count() {return count;}
        VIRTUAL void SetCount(int n) {count = n;}
        VIRTUAL Identity Destination() {return destination;}
        VIRTUAL void SetDestination(Identity d) {destination = d;}
};

