/*
 * Copyright (c) 1992-1993 Silicon Graphics, Inc.
 * Copyright (c) 1993 Fujitsu, Ltd.
 *
 * Permission to use, copy, modify, distribute, and sell this software and 
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names of
 * Silicon Graphics and Fujitsu may not be used in any advertising or
 * publicity relating to the software without the specific, prior written
 * permission of Silicon Graphics and Fujitsu.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * IN NO EVENT SHALL SILICON GRAPHICS OR FUJITSU BE LIABLE FOR
 * ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF 
 * LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE 
 * OF THIS SOFTWARE.
 */

//
// Generate code
//

#include "generator.h"
#include "tokendefs.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

implementPtrList(StringList,String)

//
// Generate a random initial symbol id
//

#include <math.h>
#include <time.h>
#include <sys/types.h>

#ifdef WIN32
#include <search.h>
#endif

#if !defined(__sgi)
#define srandom srand
#define random rand
#endif

static char default_start_id[9];
static char default_end_id[9];

static void create_random_ids() {
    srandom((int)time(0));
    long r = (random() & 0x00ffff00) | 0x11000000;
    sprintf(default_start_id, "%08x", r);
    sprintf(default_end_id, "%08x", r + 0xff);
}

static char tab[] = "    ";
static const long right_margin = 65;

Generator::Generator(ExprKit*, ErrorHandler* h, const ConfigInfo& i) {
    handler_ = h;
    out_ = stdout;
    mask_ = 0;
    generate_include_ = true;
    symbols_ = i.symbols;
    new_symbols_ = new ExprList;
    symbol_id_start_ = new StringList;
    symbol_id_end_ = new StringList;
    inclpath_ = i.inclpath;
    inclpath_length_ = length(inclpath_);
    inclext_ = i.inclext;
    inclext_length_ = length(inclext_);
    includes_ = i.includes;
    stub_includes_ = i.stub_includes;
    server_includes_ = i.stub_includes;
    filename_ = i.filename;
    stubfile_ = open_output(i.stubfile);
    serverfile_ = open_output(i.serverfile);
    schemafile_ = open_output(i.schemafile);
    serverinitfile_ = open_output(i.serverinitfile);
    prefix_ = i.prefix;
    prefix_length_ = length(prefix_);
    dii_ = i.dii;
    stubclass_ = i.stubclass;
    pass_env_ = i.pass_env;
    copy_outs_ = i.copy_outs;
    reply_ = i.reply;
    cdecls_ = i.cdecls;
    cstubs_ = i.cstubs;
    filtering_ = i.filtering;
    source_ = true;
    was_source_ = true;
    need_ifndef_ = true;
    qualify_ = true;
    concat_ = false;
    ref_ = true;
    need_sep_ = false;
    body_ = true;
    subscripts_ = true;
    formals_ = true;
    counter_ = 0;
    indent_ = 0;
    column_ = 0;
    include_newline_ = false;
    unused_params_ = nil;
    declarator_ident_space_ = false;
    scope_ = nil;
    impl_is_from_ = nil;
    prefixes_ = new StringList;
    files_ = new StringList;
    id_table_.info = static_info_;
    id_table_.cur = id_table_.info;
    id_table_.size = sizeof(static_info_) / sizeof(static_info_[0]);
    id_table_.free = id_table_.size;
}

Generator::~Generator() {
    delete prefixes_;
    delete files_;
}

long Generator::length(const char* s) {
    return s == nil ? 0 : strlen(s);
}

FILE* Generator::open_output(const char* name) {
    FILE* f = nil;
    if (name != nil) {
	f = fopen(name, "w");
	if (f == nil) {
	    handler_->begin_unrecoverable();
	    handler_->put_chars("Can't write output file '");
	    handler_->put_chars(name);
	    handler_->put_chars("'");
	    handler_->end();
	}
    }
    return f;
}

SymbolTable* Generator::symbol_table() { return symbols_; }

Boolean Generator::set_source(SourcePosition* p) {
    if (filename_ != nil) {
	was_source_ = source_;
	source_ = (p == nil || *p->filename() == filename_);
    }
    return source_;
}

Boolean Generator::begin_file(FILE* f) {
    if (f != nil) {
	fflush(out_);
	out_ = f;
	if (out_ == stubfile_) {
	    mask_ = 1;
	} else if (out_ == serverfile_) {
	    mask_ = 2;
	} else if (out_ == serverinitfile_) {
	    mask_ = 3;
	}
	save_indent_ = indent_;
	save_column_ = column_;
	indent_ = 0;
	column_ = 0;
	return true;
    }
    return false;
}

void Generator::end_file() {
    fflush(out_);
    out_ = stdout;
    mask_ = 0;
    indent_ = save_indent_;
    column_ = save_column_;
}

Boolean Generator::interface_is_ref(Boolean b) {
    Boolean prev = ref_;
    ref_ = b;
    return prev;
}

Boolean Generator::need_sep(Boolean b) {
    Boolean prev = need_sep_;
    need_sep_ = b;
    return prev;
}

Boolean Generator::op_body(Boolean b) {
    Boolean prev = body_;
    body_ = b;
    return prev;
}

Boolean Generator::is_op_body() { return body_; }

Boolean Generator::array_decl(Boolean b) {
    Boolean prev = subscripts_;
    subscripts_ = b;
    return prev;
}

Boolean Generator::is_array_decl() { return subscripts_; }

void Generator::push_prefix(String* s) {
    prefixes_->prepend(s);
}

void Generator::pop_prefix() {
    if (prefixes_->count() > 0) {
	prefixes_->remove(0);
    }
}

String* Generator::prefix() {
    String* s = nil;
    if (prefixes_->count() > 0) {
	s = prefixes_->item(0);
    }
    return s;
}

void Generator::enter_scope(Scope* s) {
    scope_ = s;
}

void Generator::leave_scope() {
    scope_ = scope_->outer;
}

//
// These operations manage symbol ids during generation.
//
// We assume that string comparison is sufficient to detect
// an id is in the proper range, as well as efficient enough
// for our purposes here.
//

void Generator::add_symbol_id_range(String* start, String* end) {
    if (*end < *start) {
	handler_->unrecoverable("Bad symbol id range");
    } else {
	symbol_id_start_->append(start);
	symbol_id_end_->append(end);
    }
}

void Generator::check_symbol_id_range() {
    if (symbol_id_start_->count() == 0) {
	handler_->warning("Picking random number for first symbol id");
	create_random_ids();
	symbol_id_start_->append(new String(default_start_id));
	symbol_id_end_->append(new String(default_end_id));
    }
}

void Generator::cur_symbol_id(String* cur) {
    cur_symbol_id_ = cur;
}

String* Generator::allocate_symbol_id() {
    String* cur = nil;
    if (cur_symbol_id_ == nil) {
	check_symbol_id_range();
	cur = new CopyString(*symbol_id_start_->item(0));
    } else {
	for (long i = symbol_id_start_->count() - 1; i >= 0; i--) {
	    String* start = symbol_id_start_->item(i);
	    String* end = symbol_id_end_->item(i);
	    if (*cur_symbol_id_ == *end) {
		long n = i + 1;
		if (n == symbol_id_start_->count() - 1) {
		    handler_->unrecoverable("Not enough symbol ids");
		    // not reached
		    return nil;
		}
		cur = symbol_id_start_->item(n);
		break;
	    } else if (*cur_symbol_id_ >= *start && *cur_symbol_id_ < *end) {
		break;
	    }
	}
    }
    if (cur == nil) {
	cur = next_symbol_id();
    }
    cur_symbol_id_ = cur;
    return cur;
}

//
// This implementation assumes the symbol id size is fixed--that is,
// if all ids for the current length string are used then we fault
// with an overflow.
//

String* Generator::next_symbol_id() {
    String::Index n = cur_symbol_id_->length();
    char* str = new char[n + 1];
    strncpy(str, cur_symbol_id_->string(), (unsigned int)n);
    str[n] = '\0';
    for (char* p = str + n - 1; ; p--) {
	if (p < str) {
	    handler_->unrecoverable("Symbol id overflow");
	    // not reached
	    return nil;
	}
	if (*p == 'f' || *p == 'F') {
	    *p = '0';
	} else {
	    if (*p == '9') {
		*p = 'a';
	    } else {
		*p += 1;
	    }
	    break;
	}
    }
    return new String(str, n);
}

//
// Emit schema information for an expression if the dii flag is set.
// Turn off interface suffixes (_ptr) during schema generation.
//

void Generator::emit_schema(Expr* e) {
    if (dii_) {
	Boolean b = ref_;
	ref_ = false;
	e->generate_schema(this);
	ref_ = b;
    }
}

//
// Write out the definition of a symbol id.
// This is a little complicated because the id is variable length and
// given as a string, and what we want to generate is an array of longs.
//

void Generator::emit_id_def(Expr* name, String* id) {
    if (id != nil) {
	Boolean r = ref_;
	ref_ = false;
	add_id_to_table(name, id);
	emit("ULong _Ix__tid(%Y)[] = { ", nil, name);
	const char* p = id->string();
	long n = id->length();
	long remaining = n;
	for (; remaining > 8; p += 8, remaining -= 8) {
	    emit("0x");
	    emit_substr(p, 8);
	    emit(", ");
	}
	emit("0x");
	emit_substr(p, remaining);
	emit(" };\n");
	ref_ = r;
    }
}

//
// Add an id to a table for later generation as part of schema initialization.
//

void Generator::add_id_to_table(Expr* name, String* id) {
    Generator::IdTable* t = &id_table_;
    if (t->free == 0) {
	long n = t->size + 100;
	Generator::IdInfo* new_info = new Generator::IdInfo[n];
	for (long i = t->size - 1; i >= 0; i--) {
	    new_info[i] = t->info[i];
	}
	if (t->info != static_info_) {
	    delete [] t->info;
	}
	t->info = new_info;
	t->cur = t->info + t->size;
	t->free = n - t->size;
	t->size = n;
    }
    Generator::IdInfo* i = t->cur;
    i->name = name;
    i->id = id;
    t->cur = i + 1;
    t->free -= 1;
}

//
// Write out the id table.  Make it sorted by id so that id lookup can use
// a binary search.
//

static int cmp_id_info(const void* i1, const void* i2) {
    return strcmp(
	((Generator::IdInfo*)i1)->id->string(),
	((Generator::IdInfo*)i2)->id->string()
    );
}

void Generator::emit_schema_id_table() {
    Generator::IdTable* t = &id_table_;
    long used = t->size - t->free;
    qsort(t->info, int(used), sizeof(Generator::IdInfo), &cmp_id_info);

    if (used > 0) {
	Generator::IdInfo* info = t->info;
	emit("_Ix_BeginSchemaList()\n%i");
	emit("_Ix_SchemaEntry(%Y)", nil, info->name);
	++info;
	for (long i = used - 1; i > 0; i--, info++) {
	    emit(",\n_Ix_SchemaEntry(%Y)", nil, info->name);
	}
	emit("\n%u_Ix_EndSchemaList()\n");
    }
}

void Generator::emit_server_id_table() {
    Generator::IdTable* t = &id_table_;
    long used = t->size - t->free;
    Generator::IdInfo* info;

    info = t->info;
    for (long i = used; i > 0; i--, info++) {
	if (server_table_entry(info->name)) {
	    emit("_Ix_extern_server(%Y);\n", nil, info->name);
	}
    }
    emit("\n");

    if (used > 0) {
	info = t->info;
	emit_file_tag("__r");
	emit("_Ix_BeginServerList()\n%i");
	need_sep(false);
	for (i = used; i != 0; i--, info++) {
	    if (server_table_entry(info->name)) {
		if (need_sep(true)) {
		    emit(",\n");
		}
		emit("_Ix_ServerEntry(%Y)", nil, info->name);
	    }
	}
	emit("\n%u_Ix_EndServerList()\n");
    }
}

Boolean Generator::server_table_entry(Expr* e) {
    InterfaceDef* i = e->symbol()->interface();
    return i != nil && i->info()->op_index > 0;
}

//
// The "impl_is_from" attribute controls the string used
// for delegation.  E.g., impl(interf::op=impl_is_from).
//

void Generator::impl_is_from(String* s) { impl_is_from_ = s; }
String* Generator::impl_is_from() { return impl_is_from_; }

Symbol* Generator::actual_type(Expr* e) {
    Symbol* s = e->symbol();
    if (s != nil) {
	s = s->actual_type();
    }
    return s;
}

Boolean Generator::addr_type(Expr* e) {
    Symbol* s = actual_type(e);
    Boolean b = false;
    if (s != nil) {
	switch (s->tag()) {
	case Symbol::sym_string:
	case Symbol::sym_struct:
	case Symbol::sym_sequence:
	case Symbol::sym_union:
	    b = true;
	    break;
	}
    }
    return b;
}

Boolean Generator::void_type(Expr* e) {
    return actual_type(e) == symbols_->void_type();
}

Boolean Generator::string_type(Expr* e) {
    return actual_type(e) == symbols_->string_type();
}

Boolean Generator::interface_type(Expr* e) {
    Symbol* s = actual_type(e);
    return s != nil && s->tag() == Symbol::sym_interface;
}

//
// Check if the given expression is the declaration of an aggregate type,
// i.e., a StructDecl, UnionDecl, SequenceDecl, or array declarator.
// Since we don't have runtime type information on the expressions
// themselves, the way we do this is get the symbol for the expression and
// check if it's expression is the same as the given one (and therefore
// not a typedef).
//

Boolean Generator::aggr_decl(Expr* t) {
    Expr* e;
    Symbol* s = t->symbol();
    switch (s->tag()) {
    case Symbol::sym_array:
	e = s->array();
	break;
    case Symbol::sym_struct:
	e = s->struct_tag();
	break;
    case Symbol::sym_union:
	e = s->union_tag();
	break;
    case Symbol::sym_sequence:
	e = t;
	break;
    default:
	e = nil;
	break;
    }
    return e == t;
}

Boolean Generator::need_extern(Expr* e) {
    Boolean b = true;
    Symbol* s = e->symbol();
    if (s != nil) {
	if (s->declared()) {
	    b = false;
	} else {
	    s->declared(true);
	}
    }
    return b;
}

Boolean Generator::emit_extern_type(Expr* e) {
    Boolean b = false;
    Symbol* s = e->symbol();
    if (s != nil && !s->declared()) {
	s->declared(true);
	const char* name = "Type";
	switch (s->tag()) {
	case Symbol::sym_interface:
	    name = "Interface";
	    break;
	case Symbol::sym_typedef:
	    name = s->type_name()->seq() ? "Sequence" : "Typedef";
	    break;
	case Symbol::sym_struct:
	    name = "Struct";
	    break;
	case Symbol::sym_union:
	    name = "Union";
	    break;
	case Symbol::sym_sequence:
	    name = "Sequence";
	    break;
	case Symbol::sym_array:
	    name = "Array";
	    break;
	case Symbol::sym_enum:
	    name = "Enum";
	    break;
	}
	emit("extern import OxSchema::");
	emit_str(name, strlen(name));
	emit("Descriptor _Ix__type(%Y);\n", nil, e);
    }
    return b;
}

void Generator::emit(const char* format, String* s, Expr* e) {
    const char* start = format;
    for (const char* p = start; *p != '\0'; p++) {
	if (*p == '\n') {
	    if (p > start) {
		emit_substr(start, p - start);
	    }
	    putc('\n', out_);
	    column_ = 0;
	    start = p + 1;
	} else if (*p == '%') {
	    if (p > start) {
		emit_substr(start, p - start);
	    }
	    ++p;
	    emit_format(*p, s, e);
	    start = p + 1;
	}
    }
    if (p > start) {
	emit_substr(start, p - start);
    }
}

void Generator::emit_str(const char* s, long length) {
    if (column_ == 0) {
	emit_include_newline();
	emit_tab(indent_);
    }
    fputs(s, out_);
    column_ += length;
}

void Generator::emit_substr(const char* s, long length) {
    if (column_ == 0) {
	emit_include_newline();
	emit_tab(indent_);
    }
    fprintf(out_, "%.*s", length, s);
    column_ += length;
}

void Generator::emit_tab(long n) {
    for (long i = 0; i < n; i++) {
	fputs(tab, out_);
	column_ += sizeof(tab) - 1;
    }
}

//
// Emit a newline if one is pending, such as from a recent #include.
//

void Generator::emit_include_newline() {
    if (include_newline_) {
	putc('\n', out_);
	include_newline_ = false;
    }
}

void Generator::emit_flush(const char* p, const char* start) {
    long n = p - start;
    if (n != 0) {
	emit_substr(start, n);
    }
}

//
// Interpret a format specification, potentially using
// a given string and expression for substitution.
//
// Formats:
//
//    %^ - name prefix if defined
//    %p - suffix for an object pointer type
//    %r - suffix for a managed object pointer type
//    %i - increment tab indentation level
//    %u - decrement tab indentation level
//    %b - discretionary line break
//    %o - white space if in the body of an operation
//    %I - given string
//    %P - given string, adding ptr suffix if top-level interface type
//    %R - given string as object reference, adding ptr suffix
//    %Q - short-hand for %:%I
//    %E - generate given expression
//    %D - generate declarator expression
//    %; - scope of expression using ::
//    %- - scope of expression using _
//    %X - fully-qualified expression
//    %Y - fully-qualified expression using _ instead of ::
//    %T - like %Y except void emits void instead of CORBA_void
//    %N - generate type expression's name
//    %F - generate type expression's fully-qualified name
//    %A - attribute parameter name for given (type) expression
//    %c - client stub class create function (or "0" when no stubs)
//    %B - marshal buffer type
//    %x - exception type
//    %U - user exception type
//    %* - emit "*" if the expression type should be a pointer result
//    %, - emit ", " if envclass is defined
//    %e - environment formal parameter (if envclass is defined)
//    %f - environment formal parameter for body (if envclass is defined)
//    %a - environment actual parameter (if envclass is defined)
//    %~ - name of current scope
//    %: - current scope with :: as separator and trailer
//    %_ - current scope with _ as separator and trailer
//    %? - scope operator (::) or name separator (_)
//    %. - scope specification (scope::) if prefix is defined
//    %= - pure virtual if stubclass is not defined
//    %# - put # in column 1 and then tab
//

void Generator::emit_format(int ch, String* s, Expr* e) {
    String* str;
    Symbol* sym;
    const char* fmt;
    Boolean b;
    switch (ch) {
    case '^':
	if (prefix_ != nil) {
	    emit_substr(prefix_, prefix_length_);
	}
	break;
    case 'p':
	emit_str("_ptr", 4);
	break;
    case 'P':
	if (ref_ && interface_type(e)) {
	    Symbol* sym = e->symbol();
	    if (sym != nil && sym->is_top_level()) {
		emit("%^");
	    }
	    emit("%I""%p", s);
	} else {
	    emit("%I", s);
	}
	break;
    case 'r':
	emit_str("_var", 4);
	break;
    case 'i':
	++indent_;
	break;
    case 'u':
	--indent_;
	break;
    case 'b':
	if (column_ > right_margin) {
	    putc('\n', out_);
	    column_ = 0;
	}
	break;
    case 'o':
	declarator_ident_space_ = true;
	break;
    case 'I':
	emit_substr(s->string(), s->length());
	break;
    case 'R':
	if (prefix_ != nil) {
	    emit("_Ix_T_ptr(%I)", s);
	} else {
	    emit("%I""%p", s);
	}
	break;
    case 'Q':
	emit("%:%I", s);
	break;
    case 'E':
	e->generate(this);
	break;
    case 'D':
	if (cdecls_ && e->symbol() != symbols_->string_type()) {
	    emit("%Y", nil, e);
	} else {
	    e->generate(this);
	}
	break;
    case ';':
	emit_expr_scope(e);
	break;
    case '-':
	b = concat_;
	concat_ = true;
	emit_expr_scope(e);
	concat_ = b;
	break;
    case 'X':
	emit_expr_scope(e);
	b = qualify_;
	qualify_ = false;
	e->generate(this);
	qualify_ = b;
	break;
    case 'Y':
	b = concat_;
	concat_ = true;
	sym = e->symbol();
	if (sym != nil && sym->is_builtin_type()) {
	    fmt = "CORBA_%F";
	} else {
	    fmt = "%^%F";
	}
	emit(fmt, nil, e);
	concat_ = b;
	break;
    case 'T':
	b = concat_;
	concat_ = true;
	sym = e->symbol();
	if (sym == symbols_->void_type()) {
	    fmt = "%F";
	} else if (sym != nil && sym->is_builtin_type()) {
	    fmt = "CORBA_%F";
	} else {
	    fmt = "%^%F";
	}
	emit(fmt, nil, e);
	concat_ = b;
	break;
    case 'N':
	e->generate_name(this);
	break;
    case 'F':
	emit_expr_scope(e);
	b = qualify_;
	qualify_ = false;
	e->generate_name(this);
	qualify_ = b;
	break;
    case 'A':
	emit_str("p_", 2);
	e->generate(this);
	break;
    case 'c':
	emit(has_stub() ? "&_Ix_CreateProxy(%_%I)" : "0", s);
	break;
    case 'B':
	emit("_Ix_MarshalBuffer");
	break;
    case 'x':
	emit("_Ix_Exception");
	break;
    case 'U':
	emit("_Ix_UserException");
	break;
    case '*':
	if (!copy_outs_ && e->varying()) {
	    sym = actual_type(e);
	    if (sym != nil && sym != symbols_->string_type() &&
		sym->tag() != Symbol::sym_interface
	    ) {
		emit_str("*", 1);
	    }
	}
	break;
    case ',':
	if (has_env()) {
	    emit(", ");
	}
	break;
    case 'e':
	if (has_env()) {
	    if (impl_is_from() != nil) {
		emit("%f");
	    } else {
		emit_param_decls(nil, emit_env_formals);
	    }
	}
	break;
    case 'f':
	if (has_env()) {
	    emit_param_decls(nil, emit_env_formals_body);
	}
	break;
    case 'a':
	if (has_env()) {
	    emit_param_decls(nil, emit_env_actuals);
	}
	break;
    case '~':
	emit_scope(scope_);
	break;
    case ':':
	if (emit_scope(scope_)) {
	    emit("%?");
	}
	break;
    case '_':
	b = concat_;
	concat_ = true;
	emit("%^%:");
	concat_ = b;
	break;
    case '?':
	if (concat_ || cdecls_) {
	    emit_str("_", 1);
	} else {
	    emit_str("::", 2);
	}
	break;
    case '.':
	str = prefix();
	if (str != nil) {
	    emit_substr(str->string(), str->length());
	    emit_str("::", 2);
	}
	break;
    case '=':
	if (!has_stub() && !cdecls()) {
	    emit(" = 0");
	}
	break;
    case '#':
	if (column_ != 0) {
	    emit_str("#", 1);
	} else {
	    emit_include_newline();
	    putc('#', out_);
	    if (indent_ != 0) {
		fprintf(out_, "%.*s", sizeof(tab) - 2, tab);
		column_ = sizeof(tab) - 1;
		emit_tab(indent_ - 1);
	    }
	}
	break;
    case '%':
	emit_str("%", 1);
	break;
    default:
	emit_str("%", 1);
	putc(ch, out_);
	column_ += 1;
	break;
    }
}

void Generator::emit_expr_scope(Expr* e) {
    Symbol* sym = e->symbol();
    if (sym != nil && emit_scope(sym->scope())) {
	emit("%?");
    }
}

void Generator::copy(const char* s) {
    fputs(s, out_);
    column_ = 0;
}

void Generator::emit_char(long c) {
    putc((int) c, out_);
}

void Generator::emit_chars_length(const char* s, long length) {
    emit_substr(s, length);
}

void Generator::emit_integer(long n) {
    char buf[100];
    sprintf(buf, "%d", n);
    emit_str(buf, strlen(buf));
}

void Generator::emit_float(double d) {
    char buf[100];
    sprintf(buf, "%g", d);
    emit_str(buf, strlen(buf));
}

void Generator::emit_declarator_ident(Identifier* i) {
    if (i != nil && body_) {
	String* s = i->string();
	if (is_unused_param(s->string(), s->length())) {
	    return;
	}
	if (declarator_ident_space_) {
	    emit(" ");
	    declarator_ident_space_ = false;
	}
	emit("%I", s);
    }
}

void Generator::emit_op(Opcode op) {
    char single_char_op[2];
    const char* opname;
    switch (op) {
    case LSHIFT:
	opname = "<<";
	break;
    case RSHIFT:
	opname = ">>";
	break;
    default:
	if (op >= ' ' && op <= '~') {
	    single_char_op[0] = char(op);
	    single_char_op[1] = '\0';
	    opname = single_char_op;
	} else {
	    opname = "???";
	}
	break;
    }
    copy(opname);
}

//
// Convert /A/B/.../C/D.idl to C_D_h
//

void Generator::emit_filename(String* s) {
    const char* start = s->string();
    String::Index n = s->length();
    const char* p;
    const char* end = start + n - 1;
    for (p = end; p > start; p--) {
	if (*p == '.') {
	    end = p;
	    break;
	}
    }
    long slash = 0;
    for (; p > start; p--) {
	if (*p == '/') {
	    if (slash == 1) {
		++p;
		break;
	    }
	    ++slash;
	}
    }
    emit_tr_filename(p, end);
    emit_tr_filename(inclext_, inclext_ + inclext_length_);
}

void Generator::emit_tr_filename(const char* start, const char* end) {
    for (const char* p = start; p < end; p++) {
	int ch = *p;
	if (!isalnum(ch)) {
	    ch = '_';
	}
	putc(ch, out_);
    }
}

void Generator::emit_ifndef(String* filename) {
    emit("#ifndef ");
    emit_filename(filename);
    emit("\n#define ");
    emit_filename(filename);
    emit("\n\n");
    files_->prepend(new CopyString(*filename));
    need_ifndef_ = false;
}

void Generator::emit_endif(String* filename) {
    if (files_->count() > 0) {
	String* current = files_->item(0);
	if (*current != *filename) {
	    emit("#endif\n\n");
	    delete current;
	    files_->remove(0);
	}
    }
}

//
// Generate a global definition for cfront so that
// it generates unique per-file symbols.
//

void Generator::emit_file_tag(const char* s) {
    emit("_Ix_FileId(");
    emit(s);
    emit("%I)\n\n", symbol_id_start_->item(0));
}

void Generator::emit_include(String* name) {
    if (inclpath_ != nil) {
	include_newline_ = false;
	emit("#include \"");
	const char* start = name->string();
	String::Index n = name->length();
	// assume n > 0 ==> end >= start
	const char* end = start + n - 1;
	const char* p;
	for (p = start; ; p++) {
	    if (p > end) {
		for (; p > start; p--) {
		    if (*p == '/') {
			start = p + 1;
			break;
		    }
		}
		emit_str(inclpath_, inclpath_length_);
		break;
	    }
	    const char* s1, * s2;
	    for (s1 = p, s2 = inclpath_; *s1 == *s2; s1++, s2++);
	    if (*s2 == '\0') {
		start = p;
		break;
	    }
	}
	for (p = end; ; p--) {
	    if (p == start) {
		emit_str(start, end - start);
		break;
	    }
	    if (*p == '.') {
		emit_substr(start, p - start);
		emit_str(inclext_, inclext_length_);
		break;
	    }
	}
	emit("\"\n");
	include_newline_ = true;
    }
}

void Generator::emit_includes() {
    if (generate_include_) {
	StringList* list = includes_;
	if (list != nil && list->count() > 0) {
	    emit_include_list(list);
	} else {
	    const char* name = "Ox/object";
	    emit_include_substr(true, name, strlen(name));
	}
	generate_include_ = false;
    }
}

void Generator::emit_stub_includes(String* s) {
    emit_edit_warning(s);
    StringList* list = stub_includes_;
    if (list != nil && list->count() > 0) {
	emit_include_list(list);
    } else {
	emit_include_filename();
	const char* name = "Ox/stub";
	emit_include_substr(true, name, strlen(name));
	include_newline_ = false;
	emit("\n");
    }
}

void Generator::emit_server_includes(String* s) {
    emit_edit_warning(s);
    StringList* list = server_includes_;
    if (list != nil && list->count() > 0) {
	emit_include_list(list);
    } else {
	emit_include_filename();
	const char* name = "Ox/server";
	emit_include_substr(true, name, strlen(name));
	include_newline_ = false;
	emit("\n");
    }
}

void Generator::emit_include_list(StringList* list) {
    include_newline_ = false;
    for (ListItr(StringList) i(*list); i.more(); i.next()) {
	emit("#include %I\n", i.cur());
    }
    include_newline_ = true;
}

void Generator::emit_include_filename() {
    if (filename_ != nil && filename_[0] != '\0') {
	const char* p;
	for (p = filename_; *p != '\0'; p++);
	for (const char* q = p - 1; q > filename_; q--) {
	    if (*q == '.') {
		p = q;
		break;
	    }
	}
	emit_include_substr(false, filename_, p - filename_);
    }
}

void Generator::emit_include_substr(Boolean path, const char* s, long length) {
    include_newline_ = false;
    emit("#include \"");
    if (path && inclpath_ != nil) {
	emit_str(inclpath_, inclpath_length_);
    }
    emit_substr(s, length);
    emit_str(inclext_, inclext_length_);
    emit("\"\n");
    include_newline_ = true;
}

void Generator::emit_param_list(ExprList* params, ParamFlags flags) {
    emit("(");
    emit_param_decls(params, flags);
    emit(")");
}

void Generator::emit_param_decls(ExprList* params, ParamFlags flags) {
    Boolean env = has_env() && (flags & emit_env) != 0;
    Boolean formals = (flags & emit_formals) != 0;
    if (env && cdecls()) {
	emit_env_param(flags);
	if (params != nil) {
	    emit(", ");
	}
    }
    if (params != nil) {
	Boolean b = formals_;
	formals_ = formals;
	ExprImpl::generate_list(params, &Expr::generate, this, ", ");
	formals_ = b;
    }
    if (env && !cdecls()) {
	if (params != nil) {
	    emit(", ");
	}
	emit_env_param(flags);
	if (formals && (flags & emit_body) == 0) {
	    emit(" = 0");
	}
    }
}

void Generator::emit_env_param(ParamFlags flags) {
    Boolean space = false;
    if ((flags & emit_formals) != 0) {
	emit("_Ix_Env*");
	space = true;
    }
    if (!is_unused_param("_env", 4)) {
	emit(space ? " _env" : "_env");
    }
}

void Generator::unused_params(char* p) {
    delete unused_params_;
    unused_params_ = (p == nil) ? nil : new CopyString(p);
}

Boolean Generator::is_unused_param(const char* str, long length) {
    if (unused_params_ != nil) {
	const char* p = unused_params_->string();
	const char* start;
	while (*p != '\0') {
	    for (; *p != '\0' && !isalpha(*p) && *p != '_'; p++);
	    start = p;
	    for (; isalnum(*p) || *p == '_'; p++);
	    if (p - start == length && strncmp(start, str, int(length)) == 0) {
		return true;
	    }
	}
    }
    return false;
}

void Generator::emit_type_info(
    String* s, ExprList* parents, Boolean dii, Boolean excepts
) {
    if (parents != nil) {
	emit_parent_type_info(s, parents);
    }
    if (excepts) {
	emit("_Ix_ExternExceptionTable(%_%I);\n", s);
    }
    emit(dii ? "_Ix_InterfaceDescriptorDII" : "_Ix_InterfaceDescriptor");
    emit("(%_%I,\"%I\",", s);
    emit_opt_info(parents != nil, "parents", s, ",");
    emit_opt_info(excepts, "excepts", s, ");\n\n");
}

void Generator::emit_parent_type_info(String* name, ExprList* parents) {
    Boolean b = interface_is_ref(false);
    long nparents = parents->count();
    for (ListItr(ExprList) p1(*parents); p1.more(); p1.next()) {
      emit("_Ix_ExternParent(%Y);\n", nil, p1.cur());
    }
    emit("_Ix_BeginParentList(%_%I)\n%i", name);
    for (ListItr(ExprList) p2(*parents); p2.more(); p2.next()) {
      emit("_Ix_ParentEntry(%Y),\n", nil, p2.cur());
    }
    emit("%u_Ix_EndParentList()\n");
    interface_is_ref(b);
}

void Generator::emit_opt_info(
    Boolean b, const char* tag, String* name, const char* trail
) {
    if (b) {
	emit("_Ix__");
	emit(tag);
	emit("(%_%I)", name);
    } else {
	emit("nil");
    }
    emit(trail);
}

void Generator::emit_type_funcs(
    InterfaceDef* i, String* name, Boolean is_interface, ExprList* parents
) {
    const char* ptr = is_interface ? "%R" : "%I*";

    //
    // Don't generate references to stub classes for implementation types.
    //
    Boolean prev_stub = stubclass_;
    if (!is_interface) {
	stubclass_ = false;
    }

    emit("_Ix_extern__tid(%_%I);\n", name);

    if (has_stub()) {
	emit("_Ix_ExternProxy(%_%I);\n", name);
    }

    // type id
    emit("_Ix_ImplementGetTid(%Q,_Ix__tid(%_%I))\n", name);

    // narrow
    emit("_Ix_ImplementNarrow(");
    emit("%:");
    emit(ptr, name);
    emit(",%Q,", name);
    Boolean cast = false;
    if (i != nil) {
 	if (!is_interface && parents != nil && parents->count() > 1) {
	    emit("(%R)", i->ident()->string());
	    cast = true;
	}
	if (i->put_cast_up(this)) {
	    cast = true;
	}
    }
    if (!cast) {
	emit("_Ix_NullParameter");
    }
    emit(",%_%I,%c)\n", name);

    // duplicate
    emit("_Ix_ImplementDuplicate(%:");
    emit(ptr, name);
    emit(",%Q,", name);
    cast = false;
    if (i != nil) {
 	if (!is_interface && parents != nil && parents->count() > 1) {
	    emit("(%R)", i->ident()->string());
	    cast = true;
	}
	if (i->put_cast_up(this)) {
	    cast = true;
	}
    }
    if (!cast) {
	emit("_Ix_NullParameter");
    }
    emit(",_Ix__tid(%_%I),%c)\n", name);

    stubclass_ = prev_stub;
}

//
// Emit constructor and destructor definitions.
// If possible, use a macro that may allow a more efficient implementation.
//

void Generator::emit_ctdt(String* name) {
#if defined(sgi)
    long depth = 0;
    for (Scope* i = scope_; i != nil && i->name != nil; i = i->outer) {
	++depth;
    }
    if (depth < 2) {
	long n = (prefix_ == nil) ? 0 : prefix_length_;
	emit("_Ix_ctdt_");
	emit_integer(depth);
	emit("(");
	if (n != 0) {
	    emit("%^");
	}
	if (depth == 1) {
	    String* s = scope_->name;
	    emit("%I,", s);
	    emit_integer(s->length() + n);
	    emit(",");
	    n = 0;
	}
	emit("%I,", name);
	emit_integer(name->length() + n);
	emit(")\n");
	return;
    }
#endif
    emit("%:%I::%I() { }\n", name);
    emit("%:%I::~%I() { }\n", name);
}

Boolean Generator::emit_scope(Scope* s) {
    Boolean b = false;
    if (s != nil) {
	if (s->outer != nil && s->outer->name != nil) {
	    emit_scope(s->outer);
	    emit("%?");
	    b = true;
	}
	if (s->name != nil) {
	    emit("%I", s->name);
	    b = true;
	}
    }
    return b;
}

Boolean Generator::emit_extern_stubs(Expr* type) {
    Boolean b = false;
    long f = file_mask();
    Symbol* s = type->symbol();
    switch (s->tag()) {
    case Symbol::sym_array:
	if (!s->declared_stub(f)) {
	    b = s->array()->generate_extern_stubs(this);
	    s->declare_stub(f);
	}
	break;
    case Symbol::sym_typedef:
	if (!s->declared_stub(f)) {
	    b = s->type_name()->generate_extern_stubs(this);
	    s->declare_stub(f);
	}
	break;
    case Symbol::sym_enum:
    case Symbol::sym_string:
	break;
    case Symbol::sym_interface:
	if (has_stub()) {
	    InterfaceInfo* i = s->interface()->info();
	    if (!i->declared_stub) {
		Boolean prev = ref_;
		ref_ = false;
		emit("_Ix_ExternProxy(%Y);\n", nil, type);
		i->declared_stub = true;
		ref_ = prev;
	    }
	}
	break;
    case Symbol::sym_sequence:
	if (string_type(s->sequence_type()->type())) {
	    break;
	}
	/* else fall-through to default */
    default:
	if (!s->declared_stub(f)) {
	    type->generate_extern_stubs(this);
	    emit("extern import void _%Y_put(\n%i%B&, %b", nil, type);
	    emit("const %F", nil, type);
	    if (addr_type(type)) {
		emit("&");
	    }
	    emit("\n%u);\n");
	    emit("extern import void _%Y_get(\n%i%B&, %b", nil, type);
	    emit("%F", nil, type);
	    if (s->array() == nil) {
		emit("&");
	    }
	    emit("\n%u);\n");
	    s->declare_stub(f);
	    b = true;
	}
	break;
    }
    return b;
}

void Generator::emit_put(Expr* type, const char* format, Expr* value) {
    Boolean b;
    Symbol* s = actual_type(value);
    switch (s->tag()) {
    case Symbol::sym_array:
	b = array_decl(false);
	emit("_%Y_put(_b, ", nil, s->array());
	emit(format, nil, value);
	emit(");\n");
	array_decl(b);
	return;
    case Symbol::sym_enum:
	emit("_b.put_long(");
	break;
    case Symbol::sym_interface:
	emit("_b.put_object(");
	break;
    case Symbol::sym_sequence:
	if (string_type(s->sequence_type()->type())) {
	    emit("_Ix_StringSeq_put(_b, ");
	} else {
	    emit("_%Y_put(_b, ", nil, s->sequence_type());
	}
	break;
    case Symbol::sym_string:
	emit("_b.put_string(");
	break;
    case Symbol::sym_typedef:
	// builtin type
	emit("_b.put_%I(", s->type_name()->str());
	break;
    default:
	emit("_%Y_put(_b, ", nil, type);
	break;
    }
    emit(format, nil, value);
    emit(");\n");
}

void Generator::emit_array_setup(Declarator* d, Expr* t, Boolean is_put) {
    ExprList* subs = d->subscripts();
    emit_array_loop_start(subs);
    if (is_put) {
	emit("const ");
    }
    emit("%F& _tmp = _array", nil, t);
    emit_array_loop_indices(subs->count());
    emit(";\n");
}

void Generator::emit_array_loop_start(ExprList* subscripts) {
    long index = 0;
    for (ListItr(ExprList) e(*subscripts); e.more(); e.next()) {
	emit("for (int _i");
	emit_integer(index);
	emit(" = 0; _i");
	emit_integer(index);
	emit(" < %E; _i", nil, e.cur());
	emit_integer(index);
	emit("++) {\n%i");
	++index;
    }
}

void Generator::emit_array_loop_indices(long nsubscripts) {
    for (long index = 0; index < nsubscripts; index++) {
	emit("[_i");
	emit_integer(index);
	emit("]");
    }
}

void Generator::emit_array_loop_finish(long nsubscripts) {
    for (long index = 0; index < nsubscripts; index++) {
	emit("%u}\n");
    }
}

void Generator::emit_get(Expr* type, const char* format, Expr* value) {
    Boolean b;
    Symbol* s = actual_type(value);
    switch (s->tag()) {
    case Symbol::sym_array:
	b = array_decl(false);
	emit("_%Y_get(_b, ", nil, s->array());
	emit(format, nil, value);
	emit(");\n");
	array_decl(b);
	return;
    case Symbol::sym_enum:
	emit(format, nil, value);
	emit(" = %F(_b.get_long());\n", nil, type);
	break;
    case Symbol::sym_interface:
	emit(format, nil, value);
	b = interface_is_ref(false);
	emit(" = (%F""%p)_b.get_object(", nil, type);
	emit(has_stub() ? "&_Ix_CreateProxy(%Y)" : "0", nil, s->interface());
	emit(");\n");
	interface_is_ref(b);
	break;
    case Symbol::sym_sequence: {
	SequenceDecl* seq = s->sequence_type();
	if (string_type(seq->type())) {
	    emit("_Ix_StringSeq_get(_b, ");
	} else {
	    emit("_%Y_get(_b, ", nil, seq);
	}
	emit(format, nil, value);
	emit(");\n");
	break;
    }
    case Symbol::sym_string:
	emit(format, nil, value);
	emit(" = _b.get_string();\n");
	break;
    case Symbol::sym_typedef:
	// builtin type
	emit(format, nil, value);
	emit(" = _b.get_%I();\n", s->type_name()->str());
	break;
    default:
	emit("_%Y_get(_b, ", nil, type);
	emit(format, nil, value);
	emit(");\n");
	break;
    }
}

void Generator::emit_edit_warning(String* s) {
    emit("/* DO NOT EDIT -- Automatically generated");
    if (s != nil) {
	emit(" from %I", s);
    }
    emit(" */\n\n");
}

void Generator::flush() {
    long n = files_->count();
    for (long i = 0; i < n; i++) {
	fprintf(out_, "\n#endif\n");
    }
    fflush(out_);
    if (stubfile_ != nil) {
	fclose(stubfile_);
    }
    if (serverfile_ != nil) {
	fclose(serverfile_);
    }
}

//
// Create generator.
//

Generator* ExprKit::generator(const ConfigInfo& info) {
    return new Generator(this, impl_->handler_, info);
}
