/*
 * Copyright (c) 1992-1993 Silicon Graphics, Inc.
 * Copyright (c) 1993 Fujitsu, Ltd.
 *
 * Permission to use, copy, modify, distribute, and sell this software and 
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names of
 * Silicon Graphics and Fujitsu may not be used in any advertising or
 * publicity relating to the software without the specific, prior written
 * permission of Silicon Graphics and Fujitsu.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * IN NO EVENT SHALL SILICON GRAPHICS OR FUJITSU BE LIABLE FOR
 * ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF 
 * LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE 
 * OF THIS SOFTWARE.
 */

//
// Expr implementations
//

#ifndef expr_impl_h
#define expr_impl_h

#include "expr.h"
#include "list.h"

class HashCode {
public:
    void init();
    void copy(const HashCode&);
    void copy_string(String*);
    void copy_ident(Identifier*);
    void add(const HashCode&);
    void add_string(String*);
    void add_type(Expr*);
    void add_list(ExprList*);

    Boolean match(String*);
    void generate(Generator*);
private:
    unsigned long hash_[2];
};

class ExprImpl : public Expr {
public:
    ExprImpl(SourcePosition*);
    ~ExprImpl();

    Symbol* symbol();
    Declarator* declarator();
    void resolve(Resolver*);
    Boolean set_source(Generator*);
    Boolean generate(Generator*);
    Boolean generate_inlines(Generator*);
    Boolean generate_name(Generator*);
    Boolean generate_def(Generator*);
    Boolean generate_impl(Generator*);
    Boolean generate_schema(Generator*);
    Boolean generate_extern_types(Generator*);
    Boolean generate_method(Generator*);
    Boolean generate_params(Generator*);
    Boolean generate_request(Generator*);
    Boolean generate_stub(Generator*);
    Boolean generate_extern_stubs(Generator*);
    Boolean generate_types(Generator*);
    Boolean generate_marshal(Generator*);
    Boolean generate_unmarshal(Generator*);
    Boolean generate_receive(Generator*);
    Boolean varying();
    SourcePosition* position();
    void set_source_position(ErrorHandler*);

    static void resolve_list(ExprList*, Resolver*);
    static Boolean generate_list(
	ExprList*, Boolean (Expr::*func)(Generator*), Generator*,
	const char* sep = nil, const char* trail = nil
    );
    static Boolean put_except_list(ExprList*, Generator*);
protected:
    Symbol* symbol_;
    enum { unknown, fixed, varies } varying_;

    virtual Boolean compute_varying();
private:
    SourcePosition* position_;
};

class Module;
class InterfaceDef;
class TypeName;
class Declarator;
class Constant;
class Operation;
class AttrOp;
class Parameter;
class StructDecl;
class StructMember;
class UnionDecl;
class UnionMember;
class EnumDecl;
class Enumerator;
class ExceptDecl;
class SequenceDecl;
class StringDecl;
class Schema;
class SymbolDef;
class SymbolIdSet;

struct Scope {
    String* name;
    Scope* outer;
    long id;
    long except_index;
};

class Symbol {
public:
    enum Tag {
	sym_unknown,
	sym_module, sym_interface, sym_typedef, sym_constant,
	sym_operation, sym_parameter, sym_attribute, sym_exception,
	sym_array, sym_struct, sym_member, sym_union, sym_union_member,
	sym_enum, sym_enum_value, sym_sequence, sym_string,
	sym_symids, sym_schema, sym_symdef
    };

    Symbol(Scope*);
    Symbol(const Symbol&);
    virtual ~Symbol();

    Tag tag() { return tag_; }
    void scope(Scope*);
    Scope* scope() { return scope_; }
    Scope* inner_scope();
    Boolean is_top_level() { return scope_->name == nil; }
    Boolean is_builtin_type();

    Symbol* actual_type();
    Boolean varying();
    void declared(Boolean b) { declared_ = b; }
    Boolean declared() { return declared_; }
    void declare_stub(long n) { declared_stub_ |= n; }
    Boolean declared_stub(long n) { return (declared_stub_ & n) != 0; }

    HashCode* hash() { return &hash_; }

    void copy_value(Symbol*);

    void module(Module*);
    Module* module();

    void interface(InterfaceDef*);
    InterfaceDef* interface();

    void type_name(TypeName*);
    TypeName* type_name();

    void constant(Constant*);
    Constant* constant();

    void operation(Operation*);
    Operation* operation();

    void parameter(Parameter*);
    Parameter* parameter();

    void attribute(AttrOp*);
    AttrOp* attribute();

    void array(Declarator*);
    Declarator* array();

    void struct_tag(StructDecl*);
    StructDecl* struct_tag();

    void struct_member(StructMember*);
    StructMember* struct_member();

    void union_tag(UnionDecl*);
    UnionDecl* union_tag();

    void union_member(UnionMember*);
    UnionMember* union_member();

    void enum_tag(EnumDecl*);
    EnumDecl* enum_tag();

    void enum_value_tag(Enumerator*);
    Enumerator* enum_value_tag();

    void except_type(ExceptDecl*);
    ExceptDecl* except_type();

    void sequence_type(SequenceDecl*);
    SequenceDecl* sequence_type();

    void string_type(StringDecl*);
    StringDecl* string_type();

    void symbol_id_set(SymbolIdSet*);
    SymbolIdSet* symbol_id_set();

    void schema(Schema*);
    Schema* schema();

    void symbol_def(SymbolDef*);
    SymbolDef* symbol_def();
protected:
    Tag tag_;
    Scope* scope_;
    Boolean declared_;
    long declared_stub_;
    HashCode hash_;
    union {
	Module* module_;
	InterfaceDef* interface_;
	TypeName* type_;
	Constant* constant_;
	Operation* operation_;
	AttrOp* attribute_;
	Parameter* parameter_;
	Declarator* array_;
	StructDecl* struct_tag_;
	StructMember* struct_member_;
	UnionDecl* union_tag_;
	UnionMember* union_member_;
	EnumDecl* enum_tag_;
	Enumerator* enum_value_tag_;
	ExceptDecl* except_type_;
	SequenceDecl* sequence_type_;
	StringDecl* string_type_;
	Schema* schema_;
	SymbolIdSet* symbol_id_set_;
	SymbolDef* symbol_def_;
    } value_;
};

class SymbolMap;

class SymbolTable {
public:
    SymbolTable();
    ~SymbolTable();

    Scope* enter_scope(String* name);
    Scope* scope();
    void leave_scope();

    void bind(IdentString*, Symbol*);
    void bind_in_scope(Scope*, IdentString*, Symbol*);
    Symbol* resolve(IdentString*);
    Symbol* resolve_in_scope(Scope*, IdentString*);

    Symbol* void_type();
    Symbol* oneway_type();
    Symbol* boolean_type();
    Symbol* char_type();
    Symbol* octet_type();
    Symbol* short_type();
    Symbol* ushort_type();
    Symbol* long_type();
    Symbol* ulong_type();
    Symbol* longlong_type();
    Symbol* ulonglong_type();
    Symbol* float_type();
    Symbol* double_type();
    Symbol* string_type();
protected:
    friend class Resolver;

    Scope* scope_;
    SymbolMap* map_;
    Symbol* void_;
    Symbol* oneway_;
    Symbol* boolean_;
    Symbol* char_;
    Symbol* octet_;
    Symbol* short_;
    Symbol* ushort_;
    Symbol* long_;
    Symbol* ulong_;
    Symbol* longlong_;
    Symbol* ulonglong_;
    Symbol* float_;
    Symbol* double_;
    Symbol* string_;
};

inline Symbol* SymbolTable::void_type() { return void_; }
inline Symbol* SymbolTable::oneway_type() { return oneway_; }
inline Symbol* SymbolTable::boolean_type() { return boolean_; }
inline Symbol* SymbolTable::char_type() { return char_; }
inline Symbol* SymbolTable::octet_type() { return octet_; }
inline Symbol* SymbolTable::short_type() { return short_; }
inline Symbol* SymbolTable::ushort_type() { return ushort_; }
inline Symbol* SymbolTable::long_type() { return long_; }
inline Symbol* SymbolTable::ulong_type() { return ulong_; }
inline Symbol* SymbolTable::longlong_type() { return longlong_; }
inline Symbol* SymbolTable::ulonglong_type() { return ulonglong_; }
inline Symbol* SymbolTable::float_type() { return float_; }
inline Symbol* SymbolTable::double_type() { return double_; }
inline Symbol* SymbolTable::string_type() { return string_; }

class IdentifierImpl : public Identifier {
public:
    IdentifierImpl(IdentString*, SourcePosition*);
    ~IdentifierImpl();

    Symbol* symbol();
    Declarator* declarator();
    void resolve(Resolver*);
    Boolean set_source(Generator*);
    Boolean generate(Generator*);
    Boolean generate_inlines(Generator*);
    Boolean generate_name(Generator*);
    Boolean generate_def(Generator*);
    Boolean generate_impl(Generator*);
    Boolean generate_schema(Generator*);
    Boolean generate_extern_types(Generator*);
    Boolean generate_method(Generator*);
    Boolean generate_params(Generator*);
    Boolean generate_request(Generator*);
    Boolean generate_stub(Generator*);
    Boolean generate_extern_stubs(Generator*);
    Boolean generate_types(Generator*);
    Boolean generate_marshal(Generator*);
    Boolean generate_unmarshal(Generator*);
    Boolean generate_receive(Generator*);
    Boolean varying();
    SourcePosition* position();
    void set_source_position(ErrorHandler*);

    IdentString* string();
protected:
    IdentString* value_;
    Symbol* symbol_;
    SourcePosition* position_;

    void check(Resolver*, UnionDecl*, Enumerator*);
};

struct GenSepState;

class ExprKitImpl {
private:
    friend class ExprKit;

    ErrorHandler* handler_;

    SourcePosition* pos() { return handler_->position(); }
};

//
// It is unfortunate to resort to macros here, but expanding and
// possibly changing all the expression classes out by hand is a pain.
// The same is true for the individual operation definitions.
//

#define Expr_class(ClassName) \
class ClassName : public ExprImpl { \
public: \
    ClassName(SourcePosition*); \
    ~ClassName(); \
\
    void resolve(Resolver*); \
    Boolean generate(Generator*); \
private: \
    friend class ExprKit;

Expr_class(RootExpr)
public:
    Boolean generate_impl(Generator*);

    static Boolean put_list(
	ExprList*, Boolean (*)(Generator*, Expr*), Generator*
    );
    static Boolean put_decls(Generator*, Expr*);
    static Boolean put_inlines(Generator*, Expr*);
    static Boolean put_stubs(Generator*, Expr*);
    static Boolean put_server(Generator*, Expr*);
    static Boolean put_schema(Generator*, Expr*);
protected:
    ExprList* defs_;

    void put_file(Boolean (*)(Generator*, Expr*), Generator*);
};

Expr_class(Module)
public:
    Identifier* ident() { return ident_; }
    ExprList* defs() { return defs_; }
    Scope* block() { return block_; }
    void want_schema(Boolean b) { want_schema_ = b; }
    void in_schema(Boolean b) { in_schema_ = b; }

    Boolean generate_name(Generator*);
    Boolean generate_schema(Generator*);
    Boolean generate_types(Generator*);

    void add_schema(Generator*, ExprList*);
protected:
    Identifier* ident_;
    ExprList* defs_;
    Scope* block_;
    Boolean want_schema_;
    Boolean in_schema_;
};

struct InterfaceInfo {
    Scope* block;
    Boolean has_body;
    Boolean has_defs;
    Boolean declared_stub;
    Boolean generated_decl;
    Boolean generated_body;
    Boolean want_schema;
    Boolean in_schema;
    long op_index;
    long max_params;
    HashCode hash;
};

struct InterfaceDefState;

Expr_class(InterfaceDef)
public:
    Identifier* ident() { return ident_; }
    Scope* block() { return info_->block; }
    ExprList* parents() { return supertypes_; }
    InterfaceInfo* info() { return info_; }

    void params(long n) {
	if (n > info_->max_params) {
	    info_->max_params = n;
	}
    }

    //
    // InterfaceDef::kind should be next after string's tag
    //
    long kind() { return 15; }

    void add_schema(Generator*, ExprList*);

    Boolean generate_name(Generator*);
    Boolean generate_impl(Generator*);
    Boolean generate_schema(Generator*);
    Boolean generate_stub(Generator*);
    Boolean generate_extern_stubs(Generator*);
    Boolean generate_types(Generator*);
    Boolean put_members(long count, InterfaceDefState&);
    Boolean put_impl(InterfaceDefState*, Expr*);
    void put_forward_decl(Generator*);
    void put_hdr(Generator*);
    Boolean put_cast_up(Generator*);
    Boolean put_cast_down(Generator*);
    void put_release(Generator*);
    void put_stub_hdr(Generator*);
    void put_managed_hdr(Generator*);
    void put_init(Generator*);
    void put_aux(Generator*, const char*);
    void put_type_info(Generator*);
    void put_type_funcs(Generator*);
    void put_empty_type(Generator*);
    void put_trans_hdr(Generator*);
    void put_client(Generator*);
    void put_extern_stubs(Generator*);
    void put_op_stubs(Generator*);
    void put_type_stubs(Generator*);
    void put_receive(Generator*);
    void put_skeleton(Generator*, String* impl, long count);

    void put_extern_info(Generator*);
    Boolean put_extern_types(InterfaceDefState*, Expr*);
    Boolean put_method_info(Generator*);
    Boolean put_method(InterfaceDefState*, Expr*);
    Boolean put_params(InterfaceDefState*, Expr*);
protected:
    Identifier* ident_;
    Boolean forward_;
    ExprList* supertypes_;
    ExprList* defs_;
    InterfaceInfo* info_;
    long visit_;
};

Expr_class(Accessor)
public:
    Expr* qualifier() { return qualifier_; }
    IdentString* string() { return string_; }
    Boolean generate_name(Generator*);
protected:
    Boolean compute_varying();
protected:
    Expr* qualifier_;
    IdentString* string_;
};

Expr_class(Constant)
public:
    Expr* type() { return type_; }
    Expr* value() { return value_; }

    Boolean generate_name(Generator*);
    Boolean generate_def(Generator*);
protected:
    Identifier* ident_;
    Expr* type_;
    Expr* value_;
};

Expr_class(Unary)
    Opcode op_;
    Expr* expr_;
};

Expr_class(Binary)
    Opcode op_;
    Expr* left_;
    Expr* right_;
};

Expr_class(TypeName)
public:
    String* str() { return str_; }
    String* mapping() { return mapping_; }
    void builtin(String* s, String* m, long k) {
	str_ = s; mapping_ = m; kind_ = k; type_ = nil; declarators_ = nil;
    }
    long kind() { return kind_; }
    Expr* type() { return type_; }
    ExprList* declarators() { return declarators_; }
    Boolean seq() { return seq_; }

    Boolean generate_name(Generator*);
    Boolean generate_def(Generator*);
    Boolean generate_schema(Generator*);
    Boolean generate_extern_stubs(Generator*);
    Boolean generate_types(Generator*);
protected:
    Boolean compute_varying();
protected:
    String* str_;
    String* mapping_;
    long kind_;
    Expr* type_;
    ExprList* declarators_;
    Boolean seq_;

    void put_extra_types(Generator*);
};

Expr_class(UnsignedType)
public:
    Boolean generate_name(Generator*);
protected:
    Expr* type_;
};

Expr_class(Declarator)
public:
    Identifier* ident() { return ident_; }
    Expr* element_type() { return element_type_; }
    ExprList* subscripts() { return subscripts_; }

    Declarator* declarator();
    Boolean generate_name(Generator*);
    Boolean generate_method(Generator*);
    Boolean generate_params(Generator*);
    Boolean generate_request(Generator*);
    Boolean generate_extern_stubs(Generator*);
    Boolean generate_types(Generator*);

    void put_type_descriptor(Generator*);
    void put_type_name(Generator*);
protected:
    Identifier* ident_;
    Expr* element_type_;
    ExprList* subscripts_;
};

Expr_class(StructDecl)
public:
    Identifier* ident() { return ident_; }

    Boolean generate_name(Generator*);
    Boolean generate_def(Generator*);
    Boolean generate_schema(Generator*);
    Boolean generate_extern_stubs(Generator*);
    Boolean generate_types(Generator*);
protected:
    Boolean compute_varying();
protected:
    Identifier* ident_;
    ExprList* members_;
    Scope* block_;

    long put_member_list(
	Generator*, void (StructDecl::*func)(Generator*, Expr* type, Expr* e),
	const char* sep = nil
    );
    void put_ctor_member(Generator*, Expr* type, Expr* e);
    void put_copy_ctor_hdr_member(Generator*, Expr* type, Expr* e);
    void put_copy_ctor_body_member(Generator*, Expr* type, Expr* e);
    void put_dtor_member(Generator*, Expr* type, Expr* e);
    void put_asg_member(Generator*, Expr* type, Expr* e);

    Boolean put_schema(Generator*, const char* label);
    void put_member_extern_type(Generator*, Expr* type, Expr* e);
};

Expr_class(StructMember)
public:
    Expr* type() { return type_; }
    ExprList* declarators() { return declarators_; }

    Boolean generate_def(Generator*);
    Boolean generate_schema(Generator*);
    Boolean generate_extern_stubs(Generator*);
    Boolean generate_types(Generator*);
    Boolean generate_marshal(Generator*);
    Boolean generate_unmarshal(Generator*);

    Boolean put_member_type(Generator*, const char*& sep);
protected:
    Boolean compute_varying();

    Expr* type_;
    ExprList* declarators_;
};

class CaseTable;

Expr_class(UnionDecl)
public:
    Symbol* switch_type() { return switch_type_; }
    CaseTable* cases() { return case_table_; }
    Boolean default_label() { return default_label_ != nil; }
    void default_label(Expr* e) { default_label_ = e; }

    Boolean generate_name(Generator*);
    Boolean generate_def(Generator*);
    Boolean generate_schema(Generator*);
    Boolean generate_extern_stubs(Generator*);
    Boolean generate_types(Generator*);
protected:
    Boolean compute_varying();

    Identifier* ident_;
    Expr* type_;
    CaseList* cases_;
    Scope* block_;
    Symbol* switch_type_;
    CaseTable* case_table_;
    Expr* default_label_;

    Symbol* switch_type(Resolver*);
    void check_cases(Resolver*);
    void generate_access_hdr(Generator*, CaseElement*);
    void generate_access_impl(Generator*, CaseElement*);
    void generate_set_tag(Generator*, CaseElement*);
    void generate_free(Generator*, CaseElement*);
    void generate_assign(Generator*, CaseElement*);
    void put_extern_types(Generator*);
    void put_cases(Generator*);
    void put_members(Generator*);
};

Expr_class(CaseElement)
public:
    ExprList* labels() { return labels_; }
    UnionMember* element() { return element_; }
    Boolean generate_copy(Boolean (Expr::*func)(Generator*), Generator*);
protected:
    Boolean compute_varying();

    ExprList* labels_;
    UnionMember* element_;
};

Expr_class(DefaultLabel)
public:
    Boolean generate_marshal(Generator*);
    Boolean generate_unmarshal(Generator*);
protected:
    virtual Boolean label(Generator*);
};

class CaseLabel : public DefaultLabel {
public:
    CaseLabel(SourcePosition*);
    ~CaseLabel();

    void resolve(Resolver*);
    Boolean generate(Generator*);
    Boolean generate_name(Generator*);
protected:
    friend class ExprKit;

    Expr* value_;

    Boolean label(Generator*);
};

class UnionMember : public StructMember {
public:
    UnionMember(SourcePosition*);
    ~UnionMember();

    Boolean generate(Generator*);
    Boolean generate_marshal(Generator*);
    Boolean generate_unmarshal(Generator*);
};

Expr_class(EnumDecl)
public:
    Boolean generate_name(Generator*);
    Boolean generate_schema(Generator*);

    long assign_value() { return enums_++; }
    long enums() { return enums_; }
protected:
    Identifier* ident_;
    ExprList* members_;
    long enums_;
};

Expr_class(Enumerator)
public:
    long value() { return value_; }
    EnumDecl* decl() { return decl_; }

    Boolean generate_name(Generator*);
protected:
    Identifier* ident_;
    EnumDecl* decl_;
    long value_;
};

Expr_class(SequenceDecl)
public:
    void name(Expr* e) { name_ = e; }
    Expr* name() { return name_; }
    Expr* type() { return type_; }

    Boolean generate_name(Generator*);
    Boolean generate_def(Generator*);
    Boolean generate_schema(Generator*);
    Boolean generate_extern_stubs(Generator*);
    Boolean generate_types(Generator*);
    Boolean generate_marshal(Generator*);
    Boolean generate_unmarshal(Generator*);
protected:
    Boolean compute_varying();

    Expr* name_;
    Expr* type_;
    Expr* length_;
    long id_;
};

Expr_class(StringDecl)
public:
    Boolean generate_name(Generator*);
protected:
    Boolean compute_varying();

    Expr* length_;
};

class ExceptDecl : public StructDecl {
public:
    ExceptDecl(SourcePosition*);
    ~ExceptDecl();

    void resolve(Resolver*);
    Boolean generate(Generator*);
    Boolean generate_def(Generator*);
    Boolean generate_schema(Generator*);
    Boolean generate_types(Generator*);
protected:
    friend class ExprKit;

    long index_;

    void put_init_list(Generator*, Boolean decl);
};

Expr_class(Operation)
public:
    Identifier* ident() { return ident_; }
    long index() { return index_; }

    Boolean generate_name(Generator*);
    Boolean generate_impl(Generator*);
    Boolean generate_extern_types(Generator*);
    Boolean generate_method(Generator*);
    Boolean generate_params(Generator*);
    Boolean generate_request(Generator*);
    Boolean generate_stub(Generator*);
    Boolean generate_extern_stubs(Generator*);
    Boolean generate_types(Generator*);
    Boolean generate_receive(Generator*);
    void put_skeleton(Generator*, String* impl);

    static long type_desc(Generator*, Expr*);
    static Boolean generate_marshal_func(Generator*, Expr*);
    static Boolean has_marshal(Generator*, Expr*);
    static void generate_return_value(Generator*, Expr*);
    static void generate_receive_addr(Generator*, long arg, Parameter*);
    static void generate_receive_asg(Generator*, Expr* type);
    static void generate_arg(Generator*, long, const char*);

    void set_index(Resolver*, String* id);
    void add_schema(Generator*, ExprList*);
protected:
    Identifier* ident_;
    long index_;
    Expr* type_;
    ExprList* params_;
    ExprList* exceptions_;
    ExprList* attributes_;
    ExprList* context_;
    InterfaceDef* interface_;
    Scope* block_;
    Boolean oneway_;
    Boolean in_schema_;

    void check_oneway(Resolver*);
    void compute_index(Resolver*);
    Boolean has_marshal_funcs(Generator*);
    void generate_param_desc(Generator*);
    void generate_param_marshal(Generator*);
    void generate_param_value(Generator*);
};

class AttrOp : public Operation {
public:
    AttrOp(SourcePosition*);
    ~AttrOp();

    void resolve(Resolver*);
    Boolean generate_name(Generator*);
    void put_individual_attr(Generator*, char* param);
protected:
    friend class ExprKit;

    Boolean readonly_;
};

Expr_class(Parameter)
public:
    ParamTag attr() { return attr_; }
    Expr* type() { return type_; }
    Declarator* declarator() { return declarator_; }

    Boolean generate_extern_types(Generator*);
    Boolean generate_params(Generator*);
    Boolean generate_request(Generator*);
    Boolean generate_stub(Generator*);
    Boolean generate_extern_stubs(Generator*);
    Boolean generate_types(Generator*);
protected:
    ParamTag attr_;
    Expr* type_;
    Declarator* declarator_;

    void put_array_param(Generator*, Boolean cxx, const char* tfmt);
    void put_string_param(
	Generator*, Boolean cxx, const char* tfmt, const char* pfmt
    );
    void put_c_param(Generator*);
    void put_objref_param(Generator*);
    void put_param(Generator*);
};

Expr_class(BooleanLiteral)
    Boolean value_;
};

Expr_class(IntegerLiteral)
    long value_;

    void check(Resolver*, Symbol* switch_type);
};

Expr_class(FloatLiteral)
    double value_;
};

Expr_class(StringLiteral)
    String* value_;
};

Expr_class(CharLiteral)
    long value_;
};

Expr_class(SrcPos)
public:
    Boolean set_source(Generator*);
};

Expr_class(SymbolIdSet)
    ExprList* ranges_;
};

class SymbolIdRange : public ExprImpl {
public:
    SymbolIdRange(SourcePosition*);
    ~SymbolIdRange();

    Boolean generate(Generator*);
protected:
    friend class ExprKit;

    String* start_;
    String* end_;
};

Expr_class(Schema)
    String* cur_id_;
    ExprList* symbols_;
};

Expr_class(SymbolId)
public:
    SymbolId(Expr* name);

    Boolean generate_impl(Generator*);
protected:
    Expr* name_;
    String* hash_;
    String* id_;

    void put_id_def(Generator*);
};

Expr_class(SymbolDef)
    Expr* name_;
};

inline Boolean Symbol::is_builtin_type() {
    return tag_ == Symbol::sym_typedef && value_.type_->type() == nil;
}

#endif
