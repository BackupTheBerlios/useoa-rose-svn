/*
 * Copyright (c) 1992-1993 Silicon Graphics, Inc.
 * Copyright (c) 1993 Fujitsu, Ltd.
 *
 * Permission to use, copy, modify, distribute, and sell this software and 
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names of
 * Silicon Graphics and Fujitsu may not be used in any advertising or
 * publicity relating to the software without the specific, prior written
 * permission of Silicon Graphics and Fujitsu.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * IN NO EVENT SHALL SILICON GRAPHICS OR FUJITSU BE LIABLE FOR
 * ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF 
 * LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE 
 * OF THIS SOFTWARE.
 */

//
// Generate header file
//

#include "generator.h"

Boolean ExprImpl::generate(Generator*) { return false; }

//
// Generate a list of expressions using the given function
// on each expression.  Return true if any of the functions
// return true.
//

Boolean ExprImpl::generate_list(
    ExprList* list, Boolean (Expr::*func)(Generator*), Generator* g,
    const char* sep, const char* trail
) {
    Boolean b = false;
    if (list != nil) {
	long n = g->counter();
	g->counter(0);
	Boolean need_sep = false;
	Expr* e;
	for (ListItr(ExprList) i(*list); i.more(); i.next()) {
	    if (need_sep && sep != nil) {
		g->emit(sep);
	    }
	    e = i.cur();
	    need_sep = (e->*func)(g);
	    b |= need_sep;
	    g->count(+1);
	}
	if (need_sep && trail != nil) {
	    g->emit(trail);
	}
    }
    return b;
}

Boolean RootExpr::generate(Generator* g) {
    SourcePosition* p = g->handler()->position();
    String* s = nil;
    if (p != nil) {
	s = p->filename();
    }
    if (g->begin_file(g->schemafile())) {
	g->emit("#ifndef IX_SCHEMA\n");
	g->emit_stub_includes(s);
	put_file(&RootExpr::put_schema, g);
    } else {
	g->emit_edit_warning(s);
	g->need_sep(false);
	put_list(defs_, &RootExpr::put_decls, g);
	if (!g->cdecls()) {
	    put_list(defs_, &RootExpr::put_inlines, g);
	}
	if (g->begin_file(g->stubfile())) {
	    g->emit_stub_includes(s);
	    put_file(&RootExpr::put_stubs, g);
	}
	if (g->begin_file(g->serverfile())) {
	    g->emit_server_includes(s);
	    put_file(&RootExpr::put_server, g);
	}
    }
    g->flush();
    return false;
}

void RootExpr::put_file(Boolean (*func)(Generator*, Expr*), Generator* g) {
    g->need_sep(false);
    put_list(defs_, func, g);
    g->end_file();
}

Boolean RootExpr::put_list(
    ExprList* list, Boolean (*func)(Generator*, Expr*), Generator* g
) {
    Boolean b = false;
    if (list != nil) {
	//
	// The separator semantics are a bit different here
	// than in ExprImpl::generate_list because we must check
	// each expression individually to see if it needs
	// a trailing semi-colon.  The reason is that some
	// declarations (e.g., structs) need semi-colons because
	// they can also be used as types for members, while
	// interfaces don't need trailing semi-colons.
	//
	for (ListItr(ExprList) i(*list); i.more(); i.next()) {
	    if (g->need_sep(false)) {
		g->emit("\n");
	    }
	    Expr* e = i.cur();
	    if (e->set_source(g)) {
		b = (*func)(g, e);
		if (b) {
		    g->emit(";\n");
		    g->need_sep(true);
		}
	    }
	}
    }
    return b;
}

Boolean RootExpr::put_decls(Generator* g, Expr* e) {
    return e->generate(g);
}

Boolean RootExpr::put_inlines(Generator* g, Expr* e) {
    Symbol* s = e->symbol();
    if (s != nil) {
	Module* m = s->module();
	if (m != nil) {
	    g->enter_scope(m->block());
	    put_list(m->defs(), &RootExpr::put_inlines, g);
	    g->leave_scope();
	}
    }
    return /* no semi-colon */ false;
}

Boolean RootExpr::put_stubs(Generator* g, Expr* e) {
    Boolean b = false;
    Symbol* s = e->symbol();
    if (s != nil) {
	InterfaceDef* i;
	TypeName* t;
	Expr* sym_expr = nil;
	switch (s->tag()) {
	case Symbol::sym_module:
	    b = s->module()->generate_types(g);
	    break;
	case Symbol::sym_interface:
	    i = s->interface();
	    if (i == e && i->info()->generated_body) {
		i->put_init(g);
		i->generate_extern_stubs(g);
		g->emit_type_funcs(
		    i, i->ident()->string(), true, i->parents()
		);
		i->generate_stub(g);
		i->generate_types(g);
		g->need_sep(true);
	    }
	    break;
	case Symbol::sym_constant:
	    sym_expr = s->constant();
	    break;
	case Symbol::sym_typedef:
	    t = s->type_name();
	    sym_expr = t->seq() ? t->type() : t;
	    break;
	case Symbol::sym_struct:
	    sym_expr = s->struct_tag();
	    break;
	case Symbol::sym_union:
	    sym_expr = s->union_tag();
	    break;
	case Symbol::sym_sequence:
	    sym_expr = s->sequence_type();
	    break;
	case Symbol::sym_exception:
	    sym_expr = s->except_type();
	    break;
	}
	if (sym_expr != nil) {
	    if (sym_expr->generate_def(g)) {
		g->need_sep(true);
	    }
	    sym_expr->generate_extern_stubs(g);
	    if (sym_expr->generate_types(g)) {
		g->need_sep(true);
	    }
	}
    }
    return b;
}

Boolean RootExpr::put_server(Generator* g, Expr* e) {
    Boolean b = false;
    Symbol* s = e->symbol();
    if (s != nil) {
	Module* m;
	InterfaceDef* i;
	switch (s->tag()) {
	case Symbol::sym_module:
	    m = s->module();
	    g->enter_scope(m->block());
	    b = put_list(m->defs(), &RootExpr::put_server, g);
	    g->leave_scope();
	    break;
	case Symbol::sym_interface:
	    i = s->interface();
	    if (i == e && i->info()->generated_body) {
		i->generate_extern_stubs(g);
		i->put_receive(g);
		g->need_sep(true);
	    }
	    break;
	}
    }
    return b;
}

Boolean RootExpr::put_schema(Generator* g, Expr* e) {
    Symbol* s = e->symbol();
    if (s != nil) {
	InterfaceDef* i;
	ExprList* symbols = g->new_symbols();
	switch (s->tag()) {
	case Symbol::sym_module:
	    s->module()->add_schema(g, symbols);
	    break;
	case Symbol::sym_interface:
	    i = s->interface();
	    // ignore forward declarations
	    if (i == e && i->info()->has_body) {
		i->add_schema(g, symbols);
	    }
	    break;
	case Symbol::sym_operation:
	    s->operation()->add_schema(g, symbols);
	    break;
	case Symbol::sym_attribute:
	    s->attribute()->add_schema(g, symbols);
	    break;
	case Symbol::sym_typedef:
	case Symbol::sym_constant:
	case Symbol::sym_array:
	case Symbol::sym_struct:
	case Symbol::sym_union:
	case Symbol::sym_enum:
	case Symbol::sym_sequence:
	    g->emit_schema(e);
	    break;
	case Symbol::sym_schema:
	case Symbol::sym_symids:
	    e->generate(g);
	    break;
	}
    }
    return false;
}

void Module::add_schema(Generator* g, ExprList* symbols) {
    if (want_schema_ && !in_schema_) {
	symbols->append(new SymbolId(this));
	in_schema_ = true;
    }
    if (in_schema_) {
	g->enter_scope(block_);
	RootExpr::put_list(defs_, &RootExpr::put_schema, g);
	g->leave_scope();
    }
}

void InterfaceDef::add_schema(Generator* g, ExprList* symbols) {
    if (info_ != nil) {
	if (info_->want_schema && !info_->in_schema) {
	    symbols->append(new SymbolId(this));
	    info_->in_schema = true;
	}
	if (info_->in_schema) {
	    g->enter_scope(info_->block);
	    RootExpr::put_list(defs_, &RootExpr::put_schema, g);
	    g->leave_scope();
	}
    }
}

void Operation::add_schema(Generator*, ExprList* symbols) {
    if (!in_schema_) {
	symbols->append(new SymbolId(this));
	in_schema_ = true;
    }
}

//
// Generate header declaration for a module.  Currently, we use
// a class for the scoping.  This should be changed to generate
// C++ namespaces if/when supported by the compiler.
//

Boolean Module::generate(Generator* g) {
    Boolean b = false;
    Boolean cdecls = g->cdecls();
    if (!cdecls) {
	b = true;
	String* s = ident_->string();
	g->emit("// _Ix_SymbolDef %Q\n", s);
	g->emit("class export %I {\npublic:\n%i", s);
    }
    g->enter_scope(block_);
    RootExpr::put_list(defs_, &RootExpr::put_decls, g);
    g->leave_scope();
    if (!cdecls) {
	b = true;
	g->emit("%u}");
	g->need_sep(/* newline separator */ true);
    }
    return b;
}

Boolean InterfaceDef::generate(Generator* g) {
    String* s = ident_->string();
    if (!info_->generated_decl) {
	put_forward_decl(g);
	if (!forward_) {
	    g->emit("\n");
	}
	info_->generated_decl = true;
    }
    if (!forward_) {
	put_hdr(g);
	if (g->has_stub() && !g->cdecls()) {
	    put_stub_hdr(g);
	}
	info_->generated_body = true;
    }
    g->need_sep(/* newline separator */ true);
    return /* no semicolon */ false;
}

void InterfaceDef::put_forward_decl(Generator* g) {
    String* s = ident_->string();
    if (g->cdecls()) {
	g->emit("_Ix_C_Interface(%_%I)\n", s);
    } else {
	g->emit("%#ifndef _interface_%Y\n%#define _interface_%Y\n", nil, this);
	g->emit("_Ix_Forward(%I)\n", s);
	g->emit("%#endif\n");
    }
}

void InterfaceDef::put_hdr(Generator* g) {
    String* s = ident_->string();
    Boolean cdecls = g->cdecls();
    if (!cdecls) {
	g->emit("// _Ix_SymbolDef %Q\n", s);
	if (supertypes_ != nil) {
	    g->emit("class export %I", s);
	    g->emit(" : _Ix_public ");
	    Boolean save = g->interface_is_ref(false);
	    generate_list(supertypes_, &Expr::generate, g, ", _Ix_public ");
	    g->interface_is_ref(save);
	} else {
	    g->emit("_Ix_BaseClass(%I)", s);
	}
	g->emit(" {\npublic:\n%i");
	g->emit("_Ix_InterfaceOps(%R)\n\n", s);
    }
    g->enter_scope(info_->block);
    generate_list(defs_, &Expr::generate, g, ";\n", ";\n");
    g->leave_scope();
    if (!cdecls) {
	g->emit("\n_Ix_MaintOps(%I)\n", s);
	g->emit("%u};\n\n");
	put_managed_hdr(g);
    }
}

//
// Generate a cast up/down the current interface's ancestors.
// The cast does NOT include this interface, as the exact format of
// that may vary depending on the current scope.
//

Boolean InterfaceDef::put_cast_up(Generator* g) {
    Boolean b = false;
    if (supertypes_ != nil) {
	InterfaceDef* p = supertypes_->item(0)->symbol()->interface();
	if (p != nil) {
	    b = p->put_cast_up(g);
	    if (supertypes_->count() > 1) {
		g->emit("(%F""%p)", nil, p);
		b = true;
	    }
	}
    }
    return b;
}

Boolean InterfaceDef::put_cast_down(Generator* g) {
    Boolean b = false;
    InterfaceDef* p;
    for (InterfaceDef* i = this; i->supertypes_ != nil; i = p) {
	p = i->supertypes_->item(0)->symbol()->interface();
	if (p != nil && i->supertypes_->count() > 1) {
	    g->emit("(%F""%p)", nil, p);
	    b = true;
	}
    }
    return b;
}

//
// Generate a call to release an object reference.  Need to cast the
// pointer up to the base type.
//

void InterfaceDef::put_release(Generator* g) {
    g->emit("_Ix_release(");
    put_cast_up(g);
    g->emit("ptr_);");
}

//
// Generate a class that manages an object reference pointer.
//

void InterfaceDef::put_managed_hdr(Generator* g) {
    String* s = ident_->string();
    g->emit("_Ix_Interface(%I)\n", s);
    g->emit("_Ix_ManagedRef(%I,", s);
    if (!put_cast_up(g)) {
	g->emit("_Ix_NullParameter");
    }
    g->emit(")\n");
}

Boolean Accessor::generate(Generator* g) {
    if (g->qualify()) {
	Boolean b = g->interface_is_ref(false);
	g->emit("%E""%?", nil, qualifier_);
	g->interface_is_ref(b);
    }
    g->emit("%P", string_, this);
    return true;
}

//
// To support environments where applications cannot access library data
// directly, we generate _both_ the C #define for a constant and the
// static const member.  In C++, the #define has an extra leading underscore
// to avoid name conflicts.
//
// The C #define doesn't put parentheses around the expression because
// we assume any necessary parentheses will be provided by the expression
// itself.
//

Boolean Constant::generate(Generator* g) {
    String* s = ident_->string();
    if (g->cdecls()) {
	g->emit("%#define %_%I %E\n", s, value_);
	return /* no trailing semi-colon */ false;
    } else {
	Scope* b = symbol_->scope();
	Boolean nested = (b != nil && b->name != nil);
	if (nested) {
	    g->emit("%#define %_%I %E\n", s, value_);
	}
	g->emit("static const %F %I", s, type_);
	if (!nested) {
	    g->emit(" = %E", nil, value_);
	}
    }
    return true;
}

Boolean Unary::generate(Generator* g) {
    g->emit("(");
    g->emit_op(op_);
    expr_->generate(g);
    g->emit(")");
    return true;
}

Boolean Binary::generate(Generator* g) {
    g->emit("(");
    left_->generate(g);
    g->emit_op(op_);
    right_->generate(g);
    g->emit(")");
    return true;
}

Boolean TypeName::generate(Generator* g) {
    if (seq_) {
	return type_->generate(g);
    }
    Boolean ref = g->interface_is_ref(false);
    g->emit(
	g->aggr_decl(type_) ? "%E;\ntypedef %N " : "typedef %D ", nil, type_
    );
    Symbol* s = type_->symbol();
    generate_list(
	declarators_, &Expr::generate, g,
	s == g->symbol_table()->string_type() ? ", * " : ", "
    );
    if (!g->cdecls()) {
	put_extra_types(g);
    }
    g->interface_is_ref(ref);
    return true;
}

//
// Generate the extra names for a typedef where the IDL type
// maps to several C++ types.  For example, if an IDL interface
// defines A, A_ptr, A_var, A_out, then "typedef A B" should define
// B, B_ptr, B_var, and B_out.
//

void TypeName::put_extra_types(Generator* g) {
    const char* macro = nil;
    Symbol* s = g->actual_type(type_);
    if (s == g->symbol_table()->string_type()) {
	Boolean need_typedef = true;
	for (ListItr(ExprList) i(*declarators_); i.more(); i.next()) {
	    Declarator* d = i.cur()->declarator();
	    if (d->subscripts() == nil) {
		if (need_typedef) {
		    need_typedef = false;
		    g->emit(";\ntypedef CORBA::String%r ");
		} else {
		    g->emit(", ");
		}
		g->emit("%I""%r", d->ident()->string());
	    }
	}
    }
    switch (s->tag()) {
    case Symbol::sym_interface:
	macro = "InterfaceTypedef";
	break;
    case Symbol::sym_sequence:
    case Symbol::sym_array:
    case Symbol::sym_struct:
    case Symbol::sym_union:
	if (type_->symbol()->tag() == Symbol::sym_typedef) {
	    macro = "AggrTypedef";
	}
	break;
    }
    if (macro != nil) {
	for (ListItr(ExprList) i(*declarators_); i.more(); i.next()) {
	    g->emit(";\n_Ix_");
	    g->emit(macro);
	    g->emit("(%F,", nil, type_);
	    g->emit("%E)", nil, i.cur());
	}
    }
}

Boolean UnsignedType::generate(Generator* g) {
    Symbol* s = symbol_;
    if (s->tag() == Symbol::sym_typedef) {
	TypeName* t = s->type_name();
	if (t->type() == nil) {
	    // builtin
	    g->emit("%I", t->mapping());
	    return true;
	}
    }
    return false;
}

Boolean Declarator::generate(Generator* g) {
    g->emit_declarator_ident(ident_);
    if (subscripts_ != nil && g->is_array_decl()) {
	g->emit("[");
	generate_list(subscripts_, &Expr::generate, g, "][");
	g->emit("]");
    }
    return true;
}

Boolean StructDecl::generate(Generator* g) {
    String* s = ident_->string();
    Boolean cxx = !g->cdecls();
    g->emit(cxx ? "struct export %I {" : "struct %_%I {", s);
    if (members_ != nil) {
	g->emit("\n%i");
	if (cxx && varying()) {
	    g->emit("%I();\n", s);
	    g->emit("%I(const %I&);\n", s);
	    g->emit("~%I();\n", s);
	    g->emit("%I& operator =(const %I&);\n\n", s);
	}
	generate_list(members_, &Expr::generate, g, ";\n");
	g->emit(";\n%u");
    } else {
	g->emit(" ");
    }
    g->emit("}");
    if (cxx) {
	g->emit(";\n");
	if (varying()) {
	    g->emit("_Ix_Managed(%I)", s);
	} else {
	    g->emit("typedef %I _Ix_T_var(%I)", s);
	}
    }
    return true;
}

Boolean StructMember::generate(Generator* g) {
    const char* sep;
    if (!put_member_type(g, sep)) {
	g->emit(g->aggr_decl(type_) ? "%E;\n%N " : "%D ", nil, type_);
    }
    generate_list(declarators_, &Expr::generate, g, sep);
    return true;
}

Boolean StructMember::put_member_type(Generator* g, const char*& sep) {
    Boolean b = false;
    Boolean cxx = !g->cdecls();
    Boolean is_string = g->string_type(type_);
    sep = ", ";
    if (cxx) {
	if (is_string) {
	    g->emit("_Ix_T_field(CORBA::String) ");
	    b = true;
	} else if (g->interface_type(type_)) {
	    Boolean ref = g->interface_is_ref(false);
	    g->emit("_Ix_T_field(%N) ", nil, type_);
	    g->interface_is_ref(ref);
	    b = true;
	}
    } else if (is_string) {
	g->emit("char *");
	sep = ", *";
	b = true;
    }
    return b;
}

Boolean UnionDecl::generate(Generator* g) {
    String* s = ident_->string();
    Boolean cxx = !g->cdecls();
    if (cxx) {
	g->emit("class export %I {\npublic:\n%i", s);
    } else {
	g->emit("struct export %_%I {\n%i", s);
    }
    g->emit("%E _d", nil, type_);
    if (cxx) {
	g->emit("_");
    }
    g->emit(";\nunion _Ix_union {\n%i");
    for (ListItr(CaseList) c(*cases_); c.more(); c.next()) {
	c.cur()->generate(g);
	g->emit(";\n");
    }
    Boolean v = varying();
    if (v) {
	g->emit("void* __init_;\n");
    }
    g->emit("%u} _u;\n");
    if (cxx) {
	if (v) {
	    g->emit("\nvoid _free();\n\n");
	    g->emit("%I();\n", s);
	    g->emit("%I(const %I& _u) { *this = _u; }\n", s);
	    g->emit("~%I();\n", s);
	    g->emit("%I& operator =(const %I&);\n", s);
	}
	g->emit("\nconst %F _d() const { return _d_; }\n", nil, type_);
	g->emit("void _d(%F);\n", nil, type_);
	for (ListItr(CaseList) i(*cases_); i.more(); i.next()) {
	    g->emit("\n");
	    generate_access_hdr(g, i.cur());
	}
    }
    g->emit("%u}");
    if (cxx) {
	g->emit(";\n");
	if (varying()) {
	    g->emit("_Ix_Managed(%I)", s);
	} else {
	    g->emit("typedef %I _Ix_T_var(%I)", s);
	}
    }
    return true;
}

void UnionDecl::generate_access_hdr(Generator* g, CaseElement* c) {
    UnionMember* u = c->element();
    Expr* t = u->type();
    Expr* e = u->declarators()->item(0);
    Boolean v = t->varying();
    Boolean addr = g->addr_type(t);
    Boolean is_string = !addr && g->string_type(t);

    // const get
    if (addr) {
	g->emit("const ");
    }
    g->emit("%F", nil, t);
    if (addr) {
	g->emit("&");
    }
    g->emit(" %E() const { return ", nil, e);
    if (v && !is_string) {
	g->emit("*");
    }
    g->emit("_u.%E; }\n", nil, e);

    // non-const get (aggregates only)
    if (addr) {
	g->emit("%F&", nil, t);
	g->emit(" %E() { return ", nil, e);
	if (v && !is_string) {
	    g->emit("*");
	}
	g->emit("_u.%E; }\n", nil, e);
    }

    // set
    g->emit("void %E(", nil, e);
    if (addr) {
	g->emit("const ");
    }
    g->emit("%F", nil, t);
    if (addr) {
	g->emit("&");
    }
    g->emit(");\n");
}

Boolean CaseElement::generate(Generator* g) {
    return element_->generate(g);
}

Boolean UnionMember::generate(Generator* g) {
    Expr* e = declarators_->item(0);
    g->emit(g->aggr_decl(type_) ? "%E;\n%N" : "%D", nil, type_);
    if (!g->cdecls() && type_->varying() && !g->string_type(type_)) {
	g->emit("*");
    }
    g->emit(" %E", nil, e);
    return true;
}

Boolean CaseLabel::generate(Generator* g) {
    return value_->generate(g);
}

Boolean DefaultLabel::generate(Generator*) {
    // do not output anything
    return true;
}

Boolean EnumDecl::generate(Generator* g) {
    g->emit("enum %I {\n%i", ident_->string());
    generate_list(members_, &Expr::generate, g, ", %b");
    g->emit("%u\n}");
    return true;
}

Boolean Enumerator::generate(Generator* g) {
    return ident_->generate(g);
}

Boolean SequenceDecl::generate(Generator* g) {
    if (g->cdecls()) {
	g->emit("_Ix_CSeq(%N,", nil, this);
	g->emit("%E)", nil, type_);
    } else {
	if (g->string_type(type_)) {
	    g->emit("_Ix_StringSeq(%N)", nil, this);
	} else {
	    if (g->interface_type(type_)) {
		g->emit("_Ix_InterfaceSeq(%N,", nil, this);
		Boolean ref = g->interface_is_ref(false);
		g->emit("%E)", nil, type_);
		g->emit(";\n_Ix_ManagedSeq(%N,", nil, this);
		g->emit("_Ix_T_field(%E))", nil, type_);
		g->interface_is_ref(ref);
	    } else {
		if (!type_->varying()) {
		    g->emit("_Ix_FixedSeq(%N,", nil, this);
		} else {
		    g->emit("_Ix_NormalSeq(%N,", nil, this);
		}
		g->emit("%E)", nil, type_);
		g->emit(";\n_Ix_ManagedSeq(%N,", nil, this);
		g->emit("%E)", nil, type_);
	    }
	}
    }
    return true;
}

Boolean StringDecl::generate(Generator* g) {
    g->emit("char*");
    return true;
}

Boolean ExceptDecl::generate(Generator* g) {
    String* s = ident_->string();
    g->emit("class export %I : public %U {\npublic:\n%i", s);
    g->emit("enum { _index = ");
    g->emit_integer(index_);
    g->emit(", _code = ");
    long ihash = symbol_->scope()->name->hash();
    g->emit_integer(((ihash & 0xfffff) << 6) + index_);
    g->emit(" };\n");
    g->emit("%I();\n", s);
    if (members_ != nil) {
	g->emit("%I(", s);
	generate_list(members_, &Expr::generate, g, ", ");
	g->emit(");\n", s);
    }
    if (varying()) {
	g->emit("%I(const %I&);\n", s);
	g->emit("%I& operator =(const %I&);\n", s);
    }
    g->emit("~%I();\n\n", s);
    g->emit("_Ix_ExceptCast(%I)\n\n", s);
    g->emit("void _put(%B&) const;\n");
    g->emit("static %x* _get(%B&);\n", s);
    if (members_ != nil) {
	g->emit("\n");
	generate_list(members_, &Expr::generate, g, ";\n");
	g->emit(";\n");
    }
    g->emit("%u}");
    return true;
}

//
// Still need to handle context.
//

Boolean Operation::generate(Generator* g) {
    if (g->cdecls()) {
	g->emit("extern %T %*", nil, type_);
	g->emit("%_%N(%~%p", nil, this);
	if (g->has_env() || params_ != nil) {
	    g->emit(", ");
	}
    } else {
	String* s = ident_->string();
	g->emit("virtual %E""%* %I(", s, type_);
    }
    g->emit_param_decls(params_, Generator::emit_env_formals);
    g->emit(")%=");
    return true;
}

//
// Generate a parameter declaration.  The basic idea for "in" parameters
// is that primitive types (char, short, long) and object pointers
// are passed by value, while structured types (string, sequence, struct)
// are passed by const reference.  For "inout" or "out" parameters,
// everything is passed non-const reference.  Arrays are the strange case,
// as they are passed by "value pointer" meaning the mode looks like
// by-value but is really by-reference.
//

Boolean Parameter::generate(Generator* g) {
    Boolean f = g->formals();
    Boolean a = g->array_decl(f);
    if (f) {
	Boolean ref = g->interface_is_ref(false);
	Boolean cxx = !g->cdecls();
	const char* tfmt = cxx ? "%E" : "%Y";
	const char* pfmt = cxx ? "&" : "*";
	Symbol* t = g->actual_type(type_);
	if (t->tag() == Symbol::sym_array) {
	    put_array_param(g, cxx, tfmt);
	} else if (t == g->symbol_table()->string_type()) {
	    put_string_param(g, cxx, tfmt, pfmt);
	} else if (cxx) {
	    if (t->tag() == Symbol::sym_interface) {
		put_objref_param(g);
	    } else {
		put_param(g);
	    }
	} else {
	    put_c_param(g);
	}
	g->interface_is_ref(ref);
	g->emit("%o");
    }
    declarator_->generate(g);
    g->array_decl(a);
    return true;
}

void Parameter::put_array_param(Generator* g, Boolean cxx, const char* tfmt) {
// Should generate const for in params, but this uncovers
// a strange cfront bug.
//    if (cxx && attr_ == ExprKit::in_param) {
//	g->emit("const ");
//    }
    g->emit(tfmt, nil, type_);
    if (cxx && attr_ == ExprKit::out_param && type_->varying()) {
	g->emit("_slice* ");
    }
}

//
// Generate the parameter type for a string.
// This is complicated by C++ outs, which need to be a class
// so that String_var can know to release the old value, and
// by C inouts, which for no good reason are passed by value
// (making their use "deprecated" according to the CORBA spec).
//

void Parameter::put_string_param(
    Generator* g, Boolean cxx, const char* tfmt, const char* pfmt
) {
    if (cxx && attr_ == ExprKit::out_param) {
	g->emit("CORBA::String_out");
    } else {
	if (cxx && attr_ == ExprKit::in_param) {
	    g->emit("const ");
	}
	g->emit(tfmt, nil, type_);
	if (attr_ == ExprKit::out_param ||
	    (attr_ == ExprKit::inout_param && cxx)
	) {
	    g->emit(pfmt);
	}
    }
}

void Parameter::put_c_param(Generator* g) {
    switch (type_->symbol()->tag()) {
    case Symbol::sym_struct:
    case Symbol::sym_union:
	g->emit("struct ");
	break;
    }
    g->emit("%Y", nil, type_);
    if (g->addr_type(type_) || attr_ != ExprKit::in_param) {
	g->emit("*");
    }
}

static const char* objref_param_suffix[] = { "??", "_ptr", "_out", "_ptr&" };

void Parameter::put_objref_param(Generator* g) {
    Symbol* tsym = type_->symbol();
    InterfaceDef* i = tsym->interface();
    Scope* scope = symbol_->scope()->outer;
    if (i != nil && tsym->is_top_level()) {
	g->emit("%^");
    }
    Boolean in_scope = (
	scope == tsym->scope() || (i != nil && i->block() == scope)
    );
    g->emit(!g->filtering() && in_scope ? "%E" : "%F", nil, type_);
    g->emit(objref_param_suffix[attr_]);
}

void Parameter::put_param(Generator* g) {
    Boolean addr = g->addr_type(type_);
    if (addr && attr_ == ExprKit::in_param) {
	g->emit("const ");
    }
    Boolean t_out = (
	attr_ == ExprKit::out_param && !g->has_copy_outs() && type_->varying()
    );
    if (t_out) {
	g->emit("_Ix_T_out(");
    }
    Scope* tscope = type_->symbol()->scope();
    Scope* opscope = symbol_->scope()->outer;
    Boolean in_scope = (tscope == opscope || tscope == opscope->outer);
    g->emit(!g->filtering() && in_scope ? "%E" : "%F", nil, type_);
    if (t_out) {
	g->emit(")");
    } else {
	//
	// as an alternative to the t_out approach, we could
	// generate T*& here
	// if (attr_ == ExprKit::out_param && type_->varying()) {
	//     g->emit("*");
	// }
	if (addr || attr_ != ExprKit::in_param) {
	    g->emit("&");
	}
    }
}

Boolean IdentifierImpl::generate(Generator* g) {
    Symbol* s = symbol_;
    String* str = value_;
    if (s != nil) {
	switch (s->tag()) {
	case Symbol::sym_typedef:
	    if (s->is_builtin_type()) {
		str = s->type_name()->mapping();
	    }
	    break;
	case Symbol::sym_constant:
	    g->emit("(%E)", nil, s->constant()->value());
	    break;
	}
    }
    g->emit("%P", str, this);
    return true;
}

Boolean BooleanLiteral::generate(Generator* g) {
    g->emit_integer(value_ ? 1 : 0);
    return true;
}

Boolean IntegerLiteral::generate(Generator* g) {
    g->emit_integer(value_);
    return true;
}

Boolean FloatLiteral::generate(Generator* g) {
    g->emit_float(value_);
    return true;
}

Boolean StringLiteral::generate(Generator* g) {
    g->emit("\"%I\"", value_);
    return true;
}

Boolean CharLiteral::generate(Generator* g) {
    g->emit("\'");
    g->emit_char(value_);
    g->emit("\'");
    return true;
}

Boolean ExprImpl::set_source(Generator* g) {
    return g->is_source();
}

Boolean IdentifierImpl::set_source(Generator* g) {
    return g->is_source();
}

Boolean SrcPos::set_source(Generator* g) {
    SourcePosition* p = position();
    if (p == nil) {
	// this shouldn't happen?
	return false;
    }
    g->set_source(p);
    return true;
}

Boolean SrcPos::generate(Generator* g) {
    SourcePosition* p = position();
    FileName name = p->filename();
    LineNumber n = p->lineno();
    if (g->is_source()) {
	if (g->need_ifndef()) {
	    g->emit_ifndef(name);
	    g->emit_includes();
	} else {
	    g->emit_endif(name);
	}
    } else if (n == 1 && g->was_source()) {
	g->emit_include(name);
    }
    return /* no semi-colon */ false;
}

Boolean SymbolIdSet::generate(Generator* g) {
    generate_list(ranges_, &Expr::generate, g);
    g->emit_file_tag("__t");
    return false;
}

Boolean SymbolIdRange::generate(Generator* g) {
    g->add_symbol_id_range(start_, end_);
    return false;
}

Boolean Schema::generate(Generator* g) {
    g->cur_symbol_id(cur_id_);
    ExprList* new_symbols = g->new_symbols();
    generate_list(symbols_, &Expr::generate_impl, g);
    generate_list(new_symbols, &Expr::generate_impl, g);
    Boolean ref = g->interface_is_ref(false);
    g->emit_schema_id_table();
    g->emit("\n%#endif\n\n%#ifdef IX_SCHEMA\n");
    String* cur = g->cur_symbol_id();
    g->emit("%#pragma ix ");
    if (cur != nil) {
	g->emit("\"%I\"", cur);
    }
    g->emit(" {\n%i");
    generate_list(symbols_, &Expr::generate, g);
    generate_list(new_symbols, &Expr::generate, g);
    g->emit("%u}\n%#endif\n");
    if (g->begin_file(g->serverinitfile())) {
	g->emit_stub_includes(nil);
	g->emit_server_id_table();
	g->end_file();
    }
    g->interface_is_ref(ref);
    g->need_sep(false);
    return true;
}

void HashCode::generate(Generator* g) {
    g->emit("\"");
    char buf[20];
    for (int i = sizeof(hash_) / sizeof(hash_[0]) - 1; i >= 0; i--) {
	sprintf(buf, "%08x", hash_[i]);
	g->emit_str(buf, 8);
    }
    g->emit("\"");
}

Boolean SymbolId::generate(Generator* g) {
    Boolean b = false;
    if (symbol_ != nil) {
	g->emit("%F ", nil, name_);
	name_->symbol()->hash()->generate(g);
	Operation* op = nil;
	switch (symbol_->tag()) {
	case Symbol::sym_operation:
	    op = symbol_->operation();
	    break;
	case Symbol::sym_attribute:
	    op = symbol_->attribute();
	    break;
	}
	g->emit(" \"");
	if (op != nil) {
	    g->emit_integer(op->index());
	} else {
	    g->emit("%I", id_);
	}
	g->emit("\"\n");
	b = true;
    }
    return b;
}

Boolean SymbolDef::generate(Generator*) { return false; }

//
// Generate the "name" for an expression, which is for type expressions.
//

Boolean ExprImpl::generate_name(Generator*) { return false; }
Boolean IdentifierImpl::generate_name(Generator* g) { return generate(g); }

Boolean Accessor::generate_name(Generator* g) {
    Symbol* s = g->actual_type(this);
    if (s != nil && s->tag() == Symbol::sym_sequence) {
	return s->sequence_type()->generate_name(g);
    }
    g->emit("%P", string_, this);
    return true;
}

Boolean Constant::generate_name(Generator* g) {
    return value_->generate(g);
}

Boolean Module::generate_name(Generator* g) {
    g->emit("%I", ident_->string());
    return true;
}

Boolean InterfaceDef::generate_name(Generator* g) {
    g->emit("%I", ident_->string());
    return true;
}

Boolean Operation::generate_name(Generator* g) {
    g->emit("%I", ident_->string());
    return true;
}

Boolean AttrOp::generate_name(Generator* g) {
    const char* fmt = (params_ == nil) ? "_get_%I" : "_set_%I";
    g->emit(fmt, ident_->string());
    return true;
}

Boolean TypeName::generate_name(Generator* g) {
    return (type_ == nil) ? generate(g) : type_->generate_name(g);
}

Boolean UnsignedType::generate_name(Generator* g) { return generate(g); }

Boolean StructDecl::generate_name(Generator* g) {
    g->emit("%I", ident_->string());
    return true;
}

Boolean UnionDecl::generate_name(Generator* g) {
    g->emit("%I", ident_->string());
    return true;
}

Boolean CaseLabel::generate_name(Generator* g) {
    return value_->generate(g);
}

Boolean EnumDecl::generate_name(Generator* g) {
    g->emit("%I", ident_->string());
    return true;
}

Boolean Enumerator::generate_name(Generator* g) {
    return generate(g);
}

Boolean SequenceDecl::generate_name(Generator* g) {
    if (name_ != nil) {
	name_->generate_name(g);
    } else {
	g->emit("_%NSeq", nil, type_);
	if (id_ > 1) {
	    g->emit_integer(id_);
	}
    }
    return true;
}

Boolean Declarator::generate_name(Generator* g) {
    g->emit("%I", ident_->string());
    return true;
}

Boolean StringDecl::generate_name(Generator* g) {
    g->emit(g->concat() ? "String" : "char*");
    return true;
}
