/*
 * Copyright (c) 1992-1993 Silicon Graphics, Inc.
 * Copyright (c) 1993 Fujitsu, Ltd.
 *
 * Permission to use, copy, modify, distribute, and sell this software and 
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names of
 * Silicon Graphics and Fujitsu may not be used in any advertising or
 * publicity relating to the software without the specific, prior written
 * permission of Silicon Graphics and Fujitsu.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * IN NO EVENT SHALL SILICON GRAPHICS OR FUJITSU BE LIABLE FOR
 * ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF 
 * LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE 
 * OF THIS SOFTWARE.
 */

#ifndef generator_h
#define generator_h

#include "err.h"
#include "expr-impl.h"
#include "list.h"
#include <stdio.h>

declarePtrList(StringList,String)

struct InterfaceDefState {
    Generator* generator;
    String* impl;
    String* name;
    Boolean (InterfaceDef::*func)(InterfaceDefState*, Expr*);
};

class Generator {
public:
    Generator(ExprKit*, ErrorHandler*, const ConfigInfo&);
    virtual ~Generator();

    enum ParamFlags {
	emit_actuals = 0x1, emit_formals = 0x2,
	emit_env = 0x4, emit_body = 0x8,
	emit_env_actuals = 0x5, emit_env_formals = 0x6,
	emit_env_formals_body = 0xe
    };

    struct IdInfo {
	Expr* name;
	String* id;
    };

    struct IdTable {
	IdInfo* info;
	IdInfo* cur;
	long size;
	long free;
    };

    SymbolTable* symbol_table();
    ErrorHandler* handler();
    Boolean has_request();
    Boolean has_stub();
    Boolean has_env();
    Boolean has_copy_outs();
    Boolean has_reply();
    FILE* stubfile();
    FILE* serverfile();
    FILE* schemafile();
    FILE* serverinitfile();
    long file_mask();
    Boolean cdecls();
    Boolean cstubs();
    Boolean filtering();
    Boolean qualify();
    Boolean formals();
    Boolean concat();
    void counter(long n);
    long counter();
    void count(long delta);

    Boolean set_source(SourcePosition*);
    Boolean is_source();
    Boolean was_source();
    Boolean need_ifndef();

    Boolean begin_file(FILE*);
    void end_file();

    Boolean interface_is_ref(Boolean);
    Boolean need_sep(Boolean);
    Boolean op_body(Boolean);
    Boolean is_op_body();
    Boolean array_decl(Boolean);
    Boolean is_array_decl();

    void push_prefix(String*);
    void pop_prefix();
    String* prefix();

    void enter_scope(Scope*);
    Scope* scope();
    void leave_scope();

    ExprList* new_symbols();
    void add_symbol_id_range(String*, String*);
    void check_symbol_id_range();
    void cur_symbol_id(String*);
    String* cur_symbol_id();
    String* allocate_symbol_id();
    String* next_symbol_id();
    void emit_schema(Expr*);
    void emit_id_def(Expr* name, String* id);
    void add_id_to_table(Expr* name, String* id);
    void emit_schema_id_table();
    void emit_server_id_table();
    Boolean server_table_entry(Expr*);

    void impl_is_from(String*);
    String* impl_is_from();

    Symbol* actual_type(Expr*);
    Boolean addr_type(Expr*);
    Boolean void_type(Expr*);
    Boolean string_type(Expr*);
    Boolean interface_type(Expr*);
    Boolean aggr_decl(Expr*);
    Boolean need_extern(Expr*);
    Boolean emit_extern_type(Expr*);

    void emit(const char* format, String* = nil, Expr* = nil);
    void emit_str(const char*, long length);
    void emit_substr(const char*, long length);
    void emit_tab(long n);
    void emit_include_newline();
    void emit_flush(const char* p, const char* start);
    void emit_format(int ch, String*, Expr*);
    void emit_expr_scope(Expr* e);
    void copy(const char*);

    void emit_char(long);
    void emit_chars_length(const char*, long length);
    void emit_integer(long);
    void emit_float(double);
    void emit_declarator_ident(Identifier*);
    void emit_op(Opcode);
    void emit_filename(String*);
    void emit_ifndef(String*);
    void emit_endif(String*);
    void emit_file_tag(const char*);
    void emit_include(String*);
    void emit_includes();
    void emit_stub_includes(String*);
    void emit_server_includes(String*);
    void emit_param_list(ExprList* params, ParamFlags flags);
    void emit_param_decls(ExprList* params, ParamFlags flags);
    void emit_env_param(ParamFlags flags);
    void unused_params(char*);
    Boolean is_unused_param(const char* str, long length);
    void emit_type_info(
	String* name, ExprList* parents, Boolean dii, Boolean excepts
    );
    void emit_parent_type_info(String* name, ExprList* parents);
    void emit_opt_info(
	Boolean flag, const char* tag, String* name, const char* trail
    );
    void emit_type_funcs(
	InterfaceDef* i, String* name, Boolean is_interface, ExprList* parents
    );
    void emit_ctdt(String* name);
    Boolean emit_scope(Scope*);

    Boolean emit_extern_stubs(Expr* type);
    void emit_put(Expr* type, const char* format, Expr* value);
    void emit_array_setup(Declarator* d, Expr* t, Boolean is_put);
    void emit_array_loop_start(ExprList* subscripts);
    void emit_array_loop_indices(long nsubscripts);
    void emit_array_loop_finish(long nsubscripts);
    void emit_get(Expr* type, const char* format, Expr* value);
    void emit_edit_warning(String*);
    void flush();
private:
    ErrorHandler* handler_;
    FILE* out_;
    long mask_;
    FILE* stubfile_;
    FILE* serverfile_;
    FILE* schemafile_;
    FILE* serverinitfile_;
    SymbolTable* symbols_;
    ExprList* new_symbols_;
    StringList* symbol_id_start_;
    StringList* symbol_id_end_;
    String* cur_symbol_id_;
    Boolean generate_include_;
    const char* inclpath_;
    long inclpath_length_;
    const char* inclext_;
    long inclext_length_;
    StringList* includes_;
    StringList* stub_includes_;
    StringList* server_includes_;
    const char* filename_;
    const char* prefix_;
    long prefix_length_;
    Boolean dii_;
    Boolean stubclass_;
    Boolean pass_env_;
    Boolean copy_outs_;
    Boolean reply_;
    Boolean cdecls_;
    Boolean cstubs_;
    Boolean filtering_;
    Boolean source_;
    Boolean was_source_;
    Boolean need_ifndef_;
    Boolean qualify_;
    Boolean concat_;
    Boolean need_sep_;
    Boolean ref_;
    Boolean body_;
    Boolean subscripts_;
    Boolean formals_;
    long counter_;
    long indent_;
    long save_indent_;
    long column_;
    long save_column_;
    Boolean include_newline_;
    String* unused_params_;
    Boolean declarator_ident_space_;
    Scope* scope_;
    String* impl_is_from_;
    StringList* prefixes_;
    StringList* files_;
    Generator::IdTable id_table_;
    Generator::IdInfo static_info_[100];

    long length(const char*);
    FILE* open_output(const char*);
    void emit_include_list(StringList*);
    void emit_include_filename();
    void emit_include_substr(Boolean path, const char* str, long length);
    void emit_tr_filename(const char* start, const char* end);
};

inline ErrorHandler* Generator::handler() { return handler_; }
inline long Generator::file_mask() { return mask_; }
inline FILE* Generator::stubfile() { return stubfile_; }
inline FILE* Generator::serverfile() { return serverfile_; }
inline FILE* Generator::schemafile() { return schemafile_; }
inline FILE* Generator::serverinitfile() { return serverinitfile_; }
inline Boolean Generator::has_request() { return dii_; }
inline Boolean Generator::has_stub() { return stubclass_; }
inline Boolean Generator::has_env() { return pass_env_; }
inline Boolean Generator::has_copy_outs() { return copy_outs_; }
inline Boolean Generator::has_reply() { return reply_; }
inline Boolean Generator::cdecls() { return cdecls_; }
inline Boolean Generator::cstubs() { return cstubs_; }
inline Boolean Generator::filtering() { return filtering_; }
inline Boolean Generator::qualify() { return qualify_; }
inline Boolean Generator::formals() { return formals_; }
inline Boolean Generator::concat() { return concat_; }
inline void Generator::counter(long n) { counter_ = n; }
inline long Generator::counter() { return counter_; }
inline void Generator::count(long delta) { counter_ += delta; }
inline Boolean Generator::is_source() { return source_; }
inline Boolean Generator::was_source() { return was_source_; }
inline Boolean Generator::need_ifndef() { return need_ifndef_; }
inline Scope* Generator::scope() { return scope_; }
inline ExprList* Generator::new_symbols() { return new_symbols_; }
inline String* Generator::cur_symbol_id() { return cur_symbol_id_; }

#endif
